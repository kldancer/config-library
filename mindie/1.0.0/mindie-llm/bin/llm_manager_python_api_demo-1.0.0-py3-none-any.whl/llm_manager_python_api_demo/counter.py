# coding=utf-8/# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.

import threading


class AtomicCounter:
    def __init__(self, initial=0):
        self._value = initial
        self._lock = threading.Lock()

    @property
    def value(self):
        with self._lock:
            return self._value
        
    def increment(self):
        with self._lock:
            self._value += 1
            return self._value


id_counter = AtomicCounter()