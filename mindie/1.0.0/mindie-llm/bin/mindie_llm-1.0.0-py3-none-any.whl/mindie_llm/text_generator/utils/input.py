# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Optional, List
import numpy as np


class ModelInput:
    def __init__(self,
                 input_ids: np.ndarray,
                 position_ids: np.ndarray | None,
                 block_tables: np.ndarray,
                 slots: np.ndarray,
                 context_length: np.ndarray | List[int],
                 max_seq_len: int,
                 prefill_head_indices: np.ndarray | None,
                 is_prefill: bool,
                 query_length: Optional[np.ndarray] = None,
                 adapter_ids: List[str] = None):
        self.input_ids = input_ids
        self.position_ids = position_ids
        self.block_tables = block_tables
        self.slots = slots
        self.context_length = context_length
        self.max_seq_len = max_seq_len
        self.prefill_head_indices = prefill_head_indices
        self.is_prefill = is_prefill
        self.query_length = query_length
        self.adapter_ids = adapter_ids

    def __repr__(self):
        return (f"Input: \n"
                f"input_ids={self.input_ids},"
                f"position_ids={self.position_ids},"
                f"block_tables={self.block_tables},"
                f"slots={self.slots},"
                f"context_length={self.context_length},"
                f"max_seq_len={self.max_seq_len},"
                f"prefill_head_indices={self.prefill_head_indices},"
                f"is_prefill={self.is_prefill},"
                f"query_length={self.query_length}")
