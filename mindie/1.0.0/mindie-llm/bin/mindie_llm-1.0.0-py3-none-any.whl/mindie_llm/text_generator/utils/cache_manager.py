# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import math
from dataclasses import dataclass

import numpy as np
import acl

from ...modeling.backend_type import BackendType
from ...utils.log.logging import logger
from ...utils.env import ENV

# NZ排布的KVCache做了16位对齐
NZ_KV_CACHE_FORMAT = 16


@dataclass
class NPUSocInfo:
    soc_name: str = ""
    soc_version: int = -1
    need_nz: bool = False

    def __post_init__(self):
        self.soc_name = acl.get_soc_name()
        self.need_nz = self.support_nz()

    def support_nz(self) -> bool:
        nz_name = ("910PremiumA", "910ProA", "910A", "910ProB", "910B")
        for name in nz_name:
            if self.soc_name.upper().endswith(name.upper()):
                return True
        return '310P' in self.soc_name.upper()


def calc_block_mem(model_info, block_size):
    total_head_size = model_info.num_kv_heads * model_info.head_size
    # k_total_head_size和v_total_head_size需成对定义
    if model_info.k_head_size > 0 or model_info.v_head_size > 0:
        k_total_head_size = model_info.num_kv_heads * model_info.k_head_size
        v_total_head_size = model_info.num_kv_heads * model_info.v_head_size
    else:
        k_total_head_size = total_head_size
        v_total_head_size = total_head_size
    model_mem_size = model_info.num_layers * (k_total_head_size + v_total_head_size) * model_info.data_byte_size
    block_mem_size = model_mem_size * block_size
    return block_mem_size


def calc_npu_mem(block_nums, model_info, block_size):
    block_mem_size = calc_block_mem(model_info, block_size)
    npu_mem_size = block_nums * block_mem_size
    return npu_mem_size


class CacheManager:
    def __init__(self, rank, model_info, sepd_worker, cpu_mem, npu_mem, block_size, backend_type):
        self.backend_type = backend_type
        # 读模型配置项
        self.num_layers = model_info.num_layers
        self.num_heads = model_info.num_kv_heads
        self.head_size = model_info.head_size
        # 为适配k head和v head size不等长的场景，新增k_head_size，v_head_size，k_mini_block_bytes，v_mini_block_bytes，
        # k_block_shape和v_block_shape；默认值和head_size，mini_block_bytes和block_shape保持一致。
        # 兼容等长场景，head_size，mini_block_bytes，block_shape属性含义无修改
        self.k_head_size = model_info.k_head_size
        self.v_head_size = model_info.v_head_size
        self.dtype = model_info.dtype
        self.data_byte_size = model_info.data_byte_size

        # cache管理
        self.block_size = block_size
        self.cpu_mem = np.int64(cpu_mem * 1024 * 1024 * 1024)
        self.npu_mem = np.int64(npu_mem * 1024 * 1024 * 1024)
        self.npu_info = NPUSocInfo()
        self.rank = rank

        self.sepd_worker = None
        self.spd_num_tensors = None
        self.spd_num_blocks = None
        self.spd_block_shape = None
        self.spd_num_blocks_cpu = None
        self.sepd_dtype = self.get_sepd_dtype(self.dtype)

        if NZ_KV_CACHE_FORMAT == 0:
            raise ZeroDivisionError('NZ_KV_CACHE_FORMAT should not be 0')
        total_head_size = (math.ceil(self.num_heads * self.head_size / NZ_KV_CACHE_FORMAT) * NZ_KV_CACHE_FORMAT) \
            if self.npu_info.need_nz else (self.num_heads * self.head_size)
        # k_total_head_size和v_total_head_size需成对定义
        if self.k_head_size > 0 or self.v_head_size > 0:
            k_total_head_size = \
                (math.ceil(self.num_heads * self.k_head_size / NZ_KV_CACHE_FORMAT) * NZ_KV_CACHE_FORMAT) \
                if self.npu_info.need_nz else (self.num_heads * self.k_head_size)
            v_total_head_size = \
                (math.ceil(self.num_heads * self.v_head_size / NZ_KV_CACHE_FORMAT) * NZ_KV_CACHE_FORMAT) \
                if self.npu_info.need_nz else (self.num_heads * self.v_head_size)
        else:
            k_total_head_size = total_head_size
            v_total_head_size = total_head_size

        self.mini_block_bytes = self.block_size * self.data_byte_size * total_head_size
        self.k_mini_block_bytes = self.block_size * self.data_byte_size * k_total_head_size
        self.v_mini_block_bytes = self.block_size * self.data_byte_size * v_total_head_size

        self.cache_block_bytes = self.num_layers * (self.k_mini_block_bytes + self.v_mini_block_bytes)
        if self.cache_block_bytes == 0:
            raise ZeroDivisionError('self.cache_block_bytes should not be 0')

        self.num_npu_blocks = self.npu_mem // self.cache_block_bytes
        self.num_cpu_blocks = self.cpu_mem // self.cache_block_bytes
        self.npu_row_bytes = self.num_npu_blocks * (self.k_mini_block_bytes + self.v_mini_block_bytes)
        self.cpu_row_bytes = self.num_cpu_blocks * (self.k_mini_block_bytes + self.v_mini_block_bytes)
        self.slots = np.arange(0, self.num_npu_blocks * self.block_size, dtype=np.int32) \
            .reshape(self.num_npu_blocks, self.block_size)

        self.block_shape = \
            (math.ceil(self.num_heads * self.head_size / NZ_KV_CACHE_FORMAT),  # NZ KVCache排布需要16对齐
             self.block_size, NZ_KV_CACHE_FORMAT) if self.npu_info.need_nz \
                else (self.block_size, self.num_heads, self.head_size)  # ND
        # k_block_shape和v_block_shape需成对定义
        if self.k_head_size > 0 or self.v_head_size > 0:
            self.k_block_shape = \
                (math.ceil(self.num_heads * self.k_head_size / NZ_KV_CACHE_FORMAT),  # NZ KVCache排布需要16对齐
                self.block_size, NZ_KV_CACHE_FORMAT) if self.npu_info.need_nz \
                    else (self.block_size, self.num_heads, self.k_head_size)  # ND
            self.v_block_shape = \
                (math.ceil(self.num_heads * self.v_head_size / NZ_KV_CACHE_FORMAT),  # NZ KVCache排布需要16对齐
                self.block_size, NZ_KV_CACHE_FORMAT) if self.npu_info.need_nz \
                    else (self.block_size, self.num_heads, self.v_head_size)  # ND
        else:
            self.k_block_shape = self.block_shape
            self.v_block_shape = self.block_shape

        logger.debug(f"block_size:{self.block_size},num_heads:{self.num_heads},head_size:{self.head_size},"
                     f"k_head_size:{self.k_head_size},v_head_size:{self.v_head_size},"
                     f"num_layers:{self.num_layers}, "
                     f"cache_block_bytes:{self.cache_block_bytes},"
                     f"k_mini_block_bytes:{self.k_mini_block_bytes},v_mini_block_bytes:{self.v_mini_block_bytes},"
                     f"num_cpu_blocks:{self.num_cpu_blocks}, num_npu_blocks:{self.num_npu_blocks}")

        if sepd_worker:
            if self.spd_num_blocks_cpu is None:
                self.spd_num_blocks_cpu = 0
            self.use_mb_swapper = ENV.use_mb_swapper
            if self.use_mb_swapper:
                self.spd_num_tensors = 1
                self.spd_num_blocks = self.num_npu_blocks
                self.spd_num_blocks_cpu = self.num_cpu_blocks
                self.spd_block_shape = (2 * self.num_layers, self.num_heads, self.head_size)
            else:
                self.spd_num_tensors = 2 * self.num_layers
                self.spd_num_blocks = self.num_npu_blocks
                self.spd_num_blocks_cpu = self.num_cpu_blocks
                self.spd_block_shape = (self.block_size, self.num_heads, self.head_size)
            self.sepd_worker = sepd_worker
            if self.sepd_worker is not None:
                self.sepd_worker.build(num_tensors=self.spd_num_tensors, num_blocks=self.spd_num_blocks,
                    num_blocks_cpu=self.spd_num_blocks_cpu, blockshape=self.spd_block_shape, dtype=self.sepd_dtype)

    def rebuild_sepd_worker(self):
        self.sepd_worker.build(num_tensors=self.spd_num_tensors, num_blocks=self.spd_num_blocks,
                    num_blocks_cpu=self.spd_num_blocks_cpu, blockshape=self.spd_block_shape, dtype=self.sepd_dtype)

    def get_sepd_dtype(self, dtype):
        if self.backend_type == BackendType.ATB:
            import torch
            dtype_map = {
                torch.float16: "float16",
                torch.bfloat16: "bfloat16",
                torch.float: "float",
                torch.int8: "int8"
            }
            if dtype not in dtype_map:
                raise Exception("PD separate engine not support kvcache dtype")
            return dtype_map[dtype]
        else: # mindformer
            import mindspore
            dtype_map = {
                mindspore.float16: "float16",
                mindspore.bfloat16: "bfloat16",
                mindspore.float32: "float",
                mindspore.int8: "int8"
            }
            if dtype not in dtype_map:
                raise Exception("PD separate engine not support kvcache dtype")
            return dtype_map[dtype]