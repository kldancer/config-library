# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import partial
from typing import Optional

import numpy as np

from .config import CacheConfig, DEFAULT_SAMPLING_PARAM
from .input_metadata import InputMetadata, SAMPLING_DTYPE
from .sampling_metadata import SamplingData, SamplingParam
from .stopping_criteria import make_mixed_eos, strings_eos
from ..samplers import Sampler
from ...utils.env import ENV
from ...utils.log.logging import logger


class BatchCache:
    def __init__(self, all_slots: np.ndarray, cache_config: CacheConfig, tokenizer, to_tensor: callable):
        self.all_slots = all_slots  # make sure it is device tensor
        self.cache_config = cache_config
        self.rank = self.cache_config.rank
        self.model_wrapper_config = cache_config.model_wrapper_config
        self.tokenizer = tokenizer
        self.to_tensor = to_tensor
        default_sampling_param = []
        for key, value in DEFAULT_SAMPLING_PARAM.items():
            if getattr(self.model_wrapper_config, key, None) is not None:
                default_sampling_param.append(getattr(self.model_wrapper_config, key))
            else:
                default_sampling_param.append(value)

        self.default_sampling_param = np.array(tuple(default_sampling_param), dtype=SAMPLING_DTYPE)
        logger.debug(f'default_sampling_param: {self.default_sampling_param}')

        self.requests_idx_mapping = {}  # key: request id, value: tensor idx
        self.used_idx = np.zeros(self.cache_config.cache_size, dtype=np.int64)
        self.cached_input_ids = np.zeros(self.cache_config.cache_size, dtype=np.int64)
        self.cached_position_id = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.cached_seq_lens = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.cpu_cached_seq_idx = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.output_len_count = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.used_block_idx = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.used_block_offset = np.zeros(self.cache_config.cache_size, dtype=np.int32)
        self.cached_user_request_ids = {}
        # sampling
        self.pad_token_id = self.cache_config.pad_token_id
        self.cached_all_input_ids = np.full((self.cache_config.cache_size, self.cache_config.max_seq_len),
                                            self.pad_token_id, dtype=np.int32)
        self.cached_out_ids = np.full((self.cache_config.cache_size, self.cache_config.max_gen_len),
                                      self.pad_token_id, dtype=np.int32)
        cached_sampling_param = [self.default_sampling_param for _ in range(self.cache_config.cache_size)]
        self.cached_sampling_param = np.array(cached_sampling_param)
        # stop
        self.cached_ignore_eos = np.zeros(self.cache_config.cache_size, dtype=np.bool_)
        self.cached_include_stop = np.zeros(self.cache_config.cache_size, dtype=np.bool_)
        self.cached_output_texts = {}
        self.cached_skip_special_tokens = np.ones(self.cache_config.cache_size, dtype=np.bool_)
        self.stopping_criteria = {}
        self.string_stopping_criteria = {}

        # lora
        self.lora_adapter_id = {}

        if not ENV.continuous_batching:
            # 结束标志，仅在非CB场景需要
            self.cached_end_flag = np.zeros(self.cache_config.cache_size, dtype=np.int32)

    def append_cache(self):
        pad_args = {
            "pad_width": (0, self.cache_config.cache_size),
            "mode": "constant",
            "constant_values": (0, 0)
        }
        new_used_idx = len(self.used_idx)
        self.used_idx = np.pad(self.used_idx, **pad_args)
        self.cached_input_ids = np.pad(self.cached_input_ids, **pad_args)
        self.cached_position_id = np.pad(self.cached_position_id, **pad_args)
        self.cached_seq_lens = np.pad(self.cached_seq_lens, **pad_args)
        self.cpu_cached_seq_idx = np.pad(self.cpu_cached_seq_idx, **pad_args)
        self.output_len_count = np.pad(self.output_len_count, **pad_args)
        self.used_block_idx = np.pad(self.used_block_idx, **pad_args)
        self.used_block_offset = np.pad(self.used_block_offset, **pad_args)
        self.cached_all_input_ids = np.pad(
            self.cached_all_input_ids, ((0, self.cache_config.cache_size), (0, 0)),
            constant_values=self.pad_token_id)
        self.cached_out_ids = np.pad(
            self.cached_out_ids, ((0, self.cache_config.cache_size), (0, 0)),
            constant_values=self.pad_token_id)
        append_cached_sampling_param = np.array(
            [self.default_sampling_param for _ in range(self.cache_config.cache_size)])
        self.cached_sampling_param = np.concatenate(
            (self.cached_sampling_param, append_cached_sampling_param), axis=0)
        self.cached_ignore_eos = np.pad(self.cached_ignore_eos, **pad_args)
        self.cached_include_stop = np.pad(self.cached_include_stop, **pad_args)
        self.cached_skip_special_tokens = np.pad(self.cached_skip_special_tokens, (0, self.cache_config.cache_size),
                                                 constant_values=True)
        return new_used_idx

    def get_cache_tensor(self, cache_ids: np.ndarray, metadata: InputMetadata):
        input_ids = self.cached_input_ids[cache_ids]
        position_ids = self.cached_position_id[cache_ids]
        input_lengths = self.cached_seq_lens[cache_ids]
        block_tables = metadata.batch_block_tables
        block_idx = metadata.batch_block_tables[range(metadata.batch_size), self.used_block_idx[cache_ids]]
        # make sure the best way
        slots = self.all_slots[block_idx, self.used_block_offset[cache_ids]]
        max_seq_len = self.cached_seq_lens[cache_ids].max()
        max_out_len = self.output_len_count[cache_ids].max()
        cu_seqlen_prefill = None
        prefill_head_indices = None
        adapter_ids = []
        for idx in cache_ids:
            adapter_ids.append(self.lora_adapter_id.get(idx))
        res = (
            input_ids,
            position_ids,
            cu_seqlen_prefill,
            block_tables,
            slots,
            input_lengths,
            max_seq_len,
            max_out_len,
            prefill_head_indices,
            adapter_ids,
        )
        return res

    def build_sampling_data(self,
                            has_penalty: bool,
                            cache_ids: np.ndarray,
                            max_seq_len: int,
                            max_out_len: int,
                            is_prefill: bool,
                            request_ids: np.ndarray
                            ) -> "SamplingData":
        if has_penalty:
            sampling_data = SamplingData.from_numpy(
                all_input_ids=self.cached_all_input_ids[cache_ids, :max_seq_len],
                output_ids=self.cached_out_ids[cache_ids, :max_out_len],
                to_tensor=self.to_tensor,
                is_prefill=is_prefill,
                request_ids=request_ids
            )
        else:
            sampling_data = SamplingData.from_numpy(is_prefill=is_prefill, request_ids=request_ids)
        return sampling_data

    def preprocess_sampling_params(self, sampling_params: np.ndarray) -> np.ndarray:
        """process post-processing params according to their special combinations.

        This method accomplishes three things:
        1. For requests where the do_sample parameter is not provided, if any of temperature, top_k, or top_p are passed
            in, it will set do_sample to True.
        2. Any missing parameters will be filled with their default values.
        3. When temperature is set to 0, do_sample will be forcibly set to False, and temperature will be set to 1, to
            prevent potential issues in subsequent processing.

        Args:
            sampling_params: A numpy array containing the post-processing params of the current batch with the
                structural dtype of `SAMPLING_DTYPE`.

        Returns:
            np.ndarray: Processed `sampling_params` with the same dtype as the input `sampling_params`.
        """
        temperature_key = 'temperature'
        do_sample_key = 'do_sample'
        t1_nan_indices = np.isnan(sampling_params[temperature_key])
        t2_nan_indices = np.isnan(sampling_params['top_k'])
        t3_nan_indices = np.isnan(sampling_params['top_p'])
        t4_nan_indices = np.isnan(sampling_params[do_sample_key])
        not_nan_indices = (~t1_nan_indices | ~t2_nan_indices | ~t3_nan_indices) & t4_nan_indices
        sampling_params[do_sample_key][not_nan_indices] = True

        for name in sampling_params.dtype.names:
            nan_mask = np.isnan(sampling_params[name])
            sampling_params[name][nan_mask] = self.default_sampling_param[name]

        temperature_zero_indices = sampling_params[temperature_key] == 0
        sampling_params[do_sample_key][temperature_zero_indices] = False
        sampling_params[temperature_key][temperature_zero_indices] = 1
        return sampling_params

    def build_sampling_param_from_prefill(self, cache_ids: np.ndarray, metadata: InputMetadata) -> "SamplingParam":
        start = 0
        for i, length in enumerate(metadata.batch_seq_len):
            self.cached_all_input_ids[cache_ids[i], :length] = metadata.input_ids_list[start: start + length]
            start += length
        batch_sampling_param = self.preprocess_sampling_params(metadata.batch_sampling_param)
        self.cached_sampling_param[cache_ids] = batch_sampling_param
        # temperature, topk, topp, typicalp, do_sample, seeds, repetition, frequency, presence, watermark, length
        sampling_param = SamplingParam.from_numpy(
            temperature=batch_sampling_param['temperature'].astype(np.float32),
            top_k=batch_sampling_param['top_k'].astype(np.int_),
            top_p=batch_sampling_param['top_p'].astype(np.float32),
            do_sample=batch_sampling_param['do_sample'].astype(np.bool_),
            seed=batch_sampling_param['seed'],
            repetition_penalty=batch_sampling_param['repetition_penalty'].astype(np.float32),
            frequency_penalty=batch_sampling_param['frequency_penalty'].astype(np.float32),
            presence_penalty=batch_sampling_param['presence_penalty'].astype(np.float32),
            to_tensor=self.to_tensor
        )
        return sampling_param

    def build_sampling_param_from_cache(self, cache_ids: np.ndarray) -> "SamplingParam":
        batch_sampling_param = self.cached_sampling_param[cache_ids]
        # temperature, topk, topp, typicalp, do_sample, seeds, repetition, frequency, presence, watermark
        sampling_param = SamplingParam.from_numpy(
            temperature=batch_sampling_param['temperature'].astype(np.float32),
            top_k=batch_sampling_param['top_k'].astype(np.int_),
            top_p=batch_sampling_param['top_p'].astype(np.float32),
            do_sample=batch_sampling_param['do_sample'].astype(np.bool_),
            seed=batch_sampling_param['seed'],
            repetition_penalty=batch_sampling_param['repetition_penalty'].astype(np.float32),
            frequency_penalty=batch_sampling_param['frequency_penalty'].astype(np.float32),
            presence_penalty=batch_sampling_param['presence_penalty'].astype(np.float32),
            to_tensor=self.to_tensor
        )
        return sampling_param

    def update_cache(self, cache_ids: np.ndarray, new_tokens: Optional[np.ndarray] = None):
        if new_tokens is not None:
            self.cached_input_ids[cache_ids] = new_tokens
            self.cached_out_ids[cache_ids, self.output_len_count[cache_ids]] = new_tokens
        self.output_len_count[cache_ids] += 1
        self.cached_seq_lens[cache_ids] += 1
        self.cpu_cached_seq_idx[cache_ids] += 1
        self.cached_position_id[cache_ids] += 1
        tmp_used_block_idx = self.cpu_cached_seq_idx[cache_ids] // self.cache_config.max_block_size
        need_append_block = not np.all(np.equal(tmp_used_block_idx, self.used_block_idx[cache_ids]))

        self.used_block_idx[cache_ids] = tmp_used_block_idx
        self.used_block_offset[cache_ids] = (self.cpu_cached_seq_idx[cache_ids]) % self.cache_config.max_block_size
        return need_append_block

    def update_sampling_cache(self, cache_ids: np.ndarray, token_array: Optional[np.ndarray]):
        self.cached_all_input_ids[cache_ids, self.cached_position_id[cache_ids] + 1] = token_array

    def recover_default_cache(self, cache_idx: np.ndarray):
        self.used_idx[cache_idx] = 0
        self.output_len_count[cache_idx] = 0
        self.cached_position_id[cache_idx] = 0
        self.cached_seq_lens[cache_idx] = 0
        self.cpu_cached_seq_idx[cache_idx] = 0
        self.used_block_idx[cache_idx] = 0
        self.used_block_offset[cache_idx] = 0
        self.cached_all_input_ids[cache_idx, :] = self.pad_token_id
        self.cached_ignore_eos[cache_idx] = False
        self.cached_include_stop[cache_idx] = False
        self.cached_skip_special_tokens[cache_idx] = True

    def clear_batch_cache(self, cache_ids, filter_ids_arr, metadata, sampler: Sampler = None):
        filter_out_ids = cache_ids[filter_ids_arr]
        self.recover_default_cache(filter_out_ids)
        if metadata.has_sampling:
            self.cached_out_ids[filter_out_ids, :] = self.pad_token_id
            self.cached_sampling_param[filter_out_ids] = self.default_sampling_param
        for cache_id in filter_out_ids:
            if self.cached_output_texts.get(cache_id) is not None:
                self.cached_output_texts.pop(cache_id)
            if self.stopping_criteria.get(cache_id):
                self.stopping_criteria.pop(cache_id)
            if self.string_stopping_criteria.get(cache_id):
                self.string_stopping_criteria.pop(cache_id)
            if self.lora_adapter_id.get(cache_id):
                self.lora_adapter_id.pop(cache_id)
            if self.cached_user_request_ids.get(cache_id):
                self.cached_user_request_ids.pop(cache_id)
        filtered_request_ids = metadata.batch_request_ids[filter_ids_arr]
        if sampler is not None:
            sampler.clear_cache(filtered_request_ids)
        for filtered_request_id in filtered_request_ids:
            self.requests_idx_mapping.pop(filtered_request_id)

    def clear_cache(self, request_id: int, sampler: Sampler = None):
        # 单请求级别，最好组batch
        if request_id in self.requests_idx_mapping:
            idx = self.requests_idx_mapping[request_id]
            self.recover_default_cache(idx)
            self.cached_out_ids[idx, :] = self.pad_token_id
            self.cached_sampling_param[idx] = self.default_sampling_param
            if self.cached_output_texts.get(idx) is not None:
                self.cached_output_texts.pop(idx)
            if self.stopping_criteria.get(idx):
                self.stopping_criteria.pop(idx)
            if self.string_stopping_criteria.get(idx):
                self.string_stopping_criteria.pop(idx)
            if self.lora_adapter_id.get(idx):
                self.lora_adapter_id.pop(idx)
            if self.cached_user_request_ids.get(idx):
                self.cached_user_request_ids.pop(idx)
            self.requests_idx_mapping.pop(request_id)
            if sampler is not None:
                sampler.clear_cache(np.asarray([request_id]))
            return 0
        else:
            return 1

    def update_cache_after_prefill(self,
                                   cache_ids: np.ndarray,
                                   position_ids: np.ndarray,
                                   input_lengths: np.ndarray,
                                   **kwargs):
        batch_ignore_eos = kwargs.get('batch_ignore_eos')
        batch_include_stop = kwargs.get('batch_include_stop')
        batch_skip_special_tokens = kwargs.get('batch_skip_special_tokens')
        batch_stop_strings = kwargs.get('batch_stop_strings')
        batch_stop_token_ids = kwargs.get('batch_stop_token_ids')
        batch_adapter_ids = kwargs.get('batch_adapter_ids')
        user_request_ids = kwargs.get('user_request_ids')
        batch_request_ids = kwargs.get('batch_request_ids')

        new_tokens = kwargs.get('new_tokens')
        block_size = kwargs.get('block_size', 128)
        is_pd_separate = kwargs.get('is_pd_separate', False)

        self.cached_position_id[cache_ids] = position_ids
        self.cached_seq_lens[cache_ids] = input_lengths
        self.cpu_cached_seq_idx[cache_ids] = input_lengths - 1

        if batch_ignore_eos is not None:
            self.cached_ignore_eos[cache_ids] = batch_ignore_eos
        if batch_skip_special_tokens is not None:
            batch_skip_special_tokens[np.vectorize(lambda x: x is None)(batch_skip_special_tokens)] = True
            self.cached_skip_special_tokens[cache_ids] = batch_skip_special_tokens
        if batch_include_stop is not None:
            self.cached_include_stop[cache_ids] = batch_include_stop

        if batch_stop_strings:
            for i, idx in enumerate(cache_ids):
                stop_strings = batch_stop_strings[i]
                if stop_strings:
                    self.cached_output_texts[idx] = ''
                    self.string_stopping_criteria[idx] = partial(strings_eos, stop_strings=stop_strings)
        if batch_stop_token_ids:
            for i, idx in enumerate(cache_ids):
                stop_token_ids = batch_stop_token_ids[i]
                if stop_token_ids:
                    self.cached_output_texts[idx] = ''
                    self.stopping_criteria[idx] = make_mixed_eos(stop_token_ids)

        if is_pd_separate is True:
            self.cached_input_ids[cache_ids] = new_tokens
            self.used_block_idx[cache_ids] = self.cpu_cached_seq_idx[cache_ids] // block_size
            self.used_block_offset[cache_ids] = self.cpu_cached_seq_idx[cache_ids] % block_size

        if batch_adapter_ids:
            for i, idx in enumerate(cache_ids):
                adapter_id = batch_adapter_ids[i]
                if adapter_id:
                    self.lora_adapter_id[idx] = adapter_id

        if user_request_ids:
            for i, idx in enumerate(cache_ids):
                user_request_id = user_request_ids[i]
                if not user_request_id:
                    user_request_id = batch_request_ids[i]
                self.cached_user_request_ids[idx] = user_request_id
