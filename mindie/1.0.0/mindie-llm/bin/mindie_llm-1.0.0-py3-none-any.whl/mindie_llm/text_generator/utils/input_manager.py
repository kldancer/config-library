# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Optional

import numpy as np

from .batch import BatchCache
from .input import ModelInput
from .input_metadata import InputMetadata
from .output_filter import OutputFilter
from .request_sampling_cache import RequestsSamplingCache
from ..samplers import Sampler
from ...utils.log.error_code import ErrorCode
from ...utils.log.logging import logger


class InputManager:
    def __init__(self,
                 model_wrapper,
                 cache_config,
                 cache_manager,
                 tokenizer,
                 to_tensor):
        self.model_wrapper = model_wrapper
        self.cache_config = cache_config

        self.all_slots = cache_manager.slots
        self.cache = BatchCache(self.all_slots, self.cache_config, tokenizer, to_tensor)
        self.output_filter = OutputFilter(self.cache, tokenizer)
        self.sampling_cache = RequestsSamplingCache()

        self.block_size = cache_config.max_block_size
        self.decoder_map = {}
        self.device = model_wrapper.model_info.device

    def save_input_cache(self, metadata: InputMetadata) -> np.ndarray:
        cached_idx = np.zeros(len(metadata.batch_request_ids), np.int32)
        for i, request_id in enumerate(metadata.batch_request_ids):
            if request_id not in self.cache.requests_idx_mapping:
                # 缓存没命中
                if not metadata.is_prefill:
                    message = (f'There is no cached data for request {request_id}. This could be due to one of the '
                               f'following reasons: 1. It has not gone through the prefilling stage. 2. The request was'
                               f' determined to have stopped but was still passed into the decoding process.')
                    logger.error(message,
                                 ErrorCode.TEXT_GENERATOR_MISSING_PREFILL_OR_INVALID_DECODE_REQ)
                    raise RuntimeError(f"req {request_id} not prefill before decoder")
                available_idx = np.flatnonzero(self.cache.used_idx == 0)
                if available_idx.shape[0] == 0:
                    append_idx = self.cache.append_cache()
                    self.cache.used_idx[append_idx] = 1
                    cached_idx[i] = append_idx
                    self.cache.requests_idx_mapping[request_id] = append_idx
                else:
                    unused_idx = available_idx[0]
                    self.cache.used_idx[unused_idx] = 1
                    cached_idx[i] = unused_idx
                    self.cache.requests_idx_mapping[request_id] = unused_idx
            else:
                # 缓存命中
                cached_idx[i] = self.cache.requests_idx_mapping[request_id]
        return cached_idx

    def concatenate(self, metadata: InputMetadata, cached_idx: Optional[np.ndarray],
                    is_warmup: bool, is_pd_separate=False, dummy=False):
        sampling_param = None
        sampling_data = None
        request_ids = None
        if metadata.is_prefill:
            # prefill阶段无法使用缓存
            position_ids = np.zeros(metadata.total_seq_num, dtype=np.int32)
            slots = np.zeros(metadata.total_seq_num, dtype=np.int32)
            input_lengths = np.zeros(metadata.batch_size, dtype=np.int32)
            last_position_ids = np.zeros(metadata.batch_size, dtype=np.int32)
            prefill_head_indices = np.zeros(metadata.batch_size, dtype=np.int64)
            cu_seqlen_prefill = np.zeros(metadata.batch_size + 1, dtype=np.int64)  # 无用数据
            cumulative_seq_len = 0
            input_ids = metadata.input_ids_list
            prefill_new_tokens = np.zeros(metadata.batch_size, dtype=np.int32)
            for i in range(metadata.batch_size):
                seq_len = metadata.batch_seq_len[i]
                start_idx = cumulative_seq_len
                end_idx = cumulative_seq_len + seq_len
                position_ids[start_idx:end_idx] = self.model_wrapper.generate_position_ids(input_ids[start_idx:end_idx])
                last_position_ids[i] = position_ids[end_idx - 1]
                if not dummy:
                    slots[start_idx:end_idx] = self.all_slots[metadata.batch_block_tables[i]].reshape(-1)[:seq_len]
                else:
                    if start_idx == 0:
                        slots[0] = 0
                        slots[1:end_idx] = -1
                    else:
                        slots[start_idx:end_idx] = -1
                input_lengths[i] = seq_len
                cumulative_seq_len += seq_len
                prefill_head_indices[i] = cumulative_seq_len - 1
                cu_seqlen_prefill[i + 1] = cumulative_seq_len
                if is_pd_separate:
                    prefill_new_tokens[i] = input_ids[cumulative_seq_len - 1]
            max_seq_len = metadata.max_seq_len
            block_tables = metadata.batch_block_tables
            adapter_ids = metadata.adapter_ids
            if not is_warmup:
                self.cache.update_cache_after_prefill(cached_idx, last_position_ids, input_lengths,
                                                      batch_ignore_eos=metadata.batch_ignore_eos,
                                                      batch_include_stop=metadata.batch_include_stop,
                                                      batch_skip_special_tokens=metadata.batch_skip_special_tokens,
                                                      batch_stop_strings=metadata.batch_stop_strings,
                                                      batch_stop_token_ids=metadata.batch_stop_token_ids,
                                                      new_tokens=prefill_new_tokens,
                                                      block_size=self.block_size,
                                                      is_pd_separate=is_pd_separate,
                                                      batch_adapter_ids=metadata.adapter_ids,
                                                      user_request_ids=metadata.user_request_ids,
                                                      batch_request_ids=metadata.batch_request_ids
                                                      )
                if metadata.has_sampling:
                    sampling_param = self.cache.build_sampling_param_from_prefill(cached_idx, metadata)
                    sampling_data = self.cache.build_sampling_data(sampling_param.penalty_meta.has_penalty,
                                                                   cache_ids=cached_idx,
                                                                   max_seq_len=max_seq_len,
                                                                   max_out_len=0,
                                                                   is_prefill=True,
                                                                   request_ids=metadata.batch_request_ids)
                    self.sampling_cache.add_to_cache(request_ids=metadata.batch_request_ids,
                                                     sampling_param=sampling_param)
        else:
            (input_ids,
             position_ids,
             cu_seqlen_prefill,
             block_tables,
             slots,
             input_lengths,
             max_seq_len,
             max_out_len,
             prefill_head_indices,
             adapter_ids,
             ) = self.cache.get_cache_tensor(cached_idx, metadata)

            if metadata.has_sampling:
                sampling_param = self.sampling_cache.get_from_cache(request_ids=metadata.batch_request_ids)
                if sampling_param is None:
                    sampling_param = self.cache.build_sampling_param_from_cache(cached_idx)
                    self.sampling_cache.add_to_cache(request_ids=metadata.batch_request_ids,
                                                     sampling_param=sampling_param)
                sampling_data = self.cache.build_sampling_data(sampling_param.penalty_meta.has_penalty,
                                                               cache_ids=cached_idx,
                                                               max_seq_len=max_seq_len,
                                                               max_out_len=max_out_len,
                                                               is_prefill=False,
                                                               request_ids=metadata.batch_request_ids)
        if cached_idx is not None:
            request_ids = [self.cache.cached_user_request_ids.get(cache_id) for cache_id in cached_idx]

        model_inputs = ModelInput(input_ids=input_ids,
                                  position_ids=position_ids,
                                  block_tables=block_tables,
                                  slots=slots,
                                  context_length=input_lengths,
                                  max_seq_len=max_seq_len,
                                  prefill_head_indices=prefill_head_indices,
                                  is_prefill=metadata.is_prefill,
                                  adapter_ids=adapter_ids,
                                  )
        res = (model_inputs, sampling_param, sampling_data, request_ids)
        return res

    def update_input(self, cached_idx: np.ndarray, new_tokens: Optional[np.ndarray], sampling: bool) -> bool:
        if sampling:
            self.cache.update_sampling_cache(cached_idx, new_tokens)
        return self.cache.update_cache(cached_idx, new_tokens)

    def filter_eos_request(
        self,
        metadata: InputMetadata,
        cached_idx: np.ndarray,
        next_tokens: list,
        sampler: Sampler = None
    ) -> (bool, np.ndarray, np.ndarray, np.ndarray):
        return self.output_filter.filter_output(metadata, cached_idx, next_tokens, sampler)

    def clear_cache(self, req_id: int, sampler: Sampler = None):
        return self.cache.clear_cache(req_id, sampler)
