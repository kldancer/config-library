# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np
from .sampling_metadata import SamplingParam


class RequestsSamplingCache:
    def __init__(self):
        self.cached_request_ids = None
        self.sampling_param = None

    def __repr__(self):
        return (f"SamplingCache:\n"
                f"cached_request_ids: {self.cached_request_ids},"
                f"sampling_param: {self.sampling_param},"
                )

    def get_from_cache(self,
                       request_ids,
                       ):
        if (self.cached_request_ids is None or
                len(self.cached_request_ids) != len(request_ids) or
                not np.all(self.cached_request_ids == request_ids)):
            return None
        else:
            return self.sampling_param

    def add_to_cache(self,
                     request_ids,
                     sampling_param: SamplingParam,
                     ):
        self.cached_request_ids = np.array(request_ids, dtype=np.int_)
        self.sampling_param = sampling_param

    def clear(self):
        self.cached_request_ids = None
        self.sampling_param = None
