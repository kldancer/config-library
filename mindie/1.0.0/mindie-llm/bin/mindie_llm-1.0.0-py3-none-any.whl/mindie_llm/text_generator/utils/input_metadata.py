# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import math
from dataclasses import dataclass, fields
from typing import List, Optional, Union

import numpy as np

from .request import Request
from ...utils.log.error_code import ErrorCode
from ...utils.log.logging import logger

SAMPLING_DTYPE = np.dtype([
    ('temperature', np.float64),
    ('top_k', np.float64),
    ('top_p', np.float64),
    ('typical_p', np.float64),
    ('do_sample', np.float64),
    ('seed', np.int64),
    ('repetition_penalty', np.float64),
    ('frequency_penalty', np.float64),
    ('presence_penalty', np.float64),
    ('watermark', np.float64),
    ('length_penalty', np.float64)])


def get_batch_size(is_prefill_pre_batch, requests):
    first_batch_is_prefill = is_prefill_pre_batch[0]
    last_batch_is_prefill = is_prefill_pre_batch[-1]
    if first_batch_is_prefill != last_batch_is_prefill:
        is_mix = True
        is_prefill = True
    elif first_batch_is_prefill:
        is_mix = False
        is_prefill = True
    else:
        is_mix = False
        is_prefill = False

    if is_mix:
        total_bs = len(requests)
        prefill_bs = np.sum(is_prefill_pre_batch)
        decode_bs = total_bs - prefill_bs
    else:
        total_bs = len(requests)
        prefill_bs = 0
        decode_bs = 0
        if is_prefill:
            prefill_bs = total_bs
        else:
            decode_bs = total_bs
    return is_prefill, is_mix, decode_bs


@dataclass
class InputMetadata:
    batch_size: int
    batch_request_ids: np.ndarray
    batch_max_output_lens: np.ndarray
    block_tables: np.ndarray

    has_sampling: bool = True
    is_prefill: bool = False
    max_block_size: int = 128
    is_mix: bool = None

    adapter_ids: Optional[List[Optional[str]]] = None
    batch_ignore_eos: Optional[np.ndarray] = None
    batch_include_stop: Optional[np.ndarray] = None
    batch_sampling_param: Optional[np.ndarray] = None
    batch_seq_len: Optional[np.ndarray] = None
    batch_skip_special_tokens: Optional[np.ndarray] = None
    batch_stop_strings: Optional[List[Optional[List[str]]]] = None
    batch_stop_token_ids: Optional[List[Optional[List[Union[int, List[int]]]]]] = None
    computed_blocks: Optional[np.ndarray] = None
    input_ids_list: Optional[np.ndarray] = None
    total_seq_num: Optional[int] = None
    user_request_ids: Optional[np.ndarray] = None

    mix_decode_bs: int = 0
    split_start_position: Optional[np.ndarray] = None
    split_end_position: Optional[np.ndarray] = None
    batch_last_prompt: Optional[np.ndarray] = None
    batch_is_prefill: Optional[np.ndarray] = None

    def __init__(self, *args, **kwargs):
        field_names = [field.name for field in fields(self)]

        for i, value in enumerate(args):
            if i < len(field_names):
                setattr(self, field_names[i], value)

        for field in fields(self):
            if field.name in kwargs:
                setattr(self, field.name, kwargs.pop(field.name))
            elif not hasattr(self, field.name):
                setattr(self, field.name, field.default)

        for key, value in kwargs.items():
            setattr(self, key, value)

        if self.is_prefill:
            self.max_seq_len = max(self.batch_seq_len) if self.batch_seq_len is not None else 0
            if self.max_block_size == 0:
                message = ('It has been detected that `max_block_size` is set to 0, but `max_block_size` must be '
                           'greater than 0 to ensure the program runs correctly. If you are unsure of an appropriate '
                           'value, you can simply omit this parameter.')
                logger.error(message, ErrorCode.TEXT_GENERATOR_MAX_BLOCK_SIZE_INVALID)
                raise ZeroDivisionError('self.max_block_size should not be 0')
            max_block_num = math.ceil(self.max_seq_len / self.max_block_size)
        else:
            max_block_num = np.count_nonzero(self.block_tables > -1, axis=-1).max()
        self.batch_block_tables = self.block_tables[:, :max_block_num].astype(np.int32)

        if self.is_mix is not None:
            self.max_seq_len = max(self.split_end_position)
            max_block_num = np.count_nonzero(self.block_tables > -1, axis=-1).max()
            self.batch_block_tables = self.block_tables[:, :max_block_num].astype(np.int32)

    @classmethod
    def from_requests(cls, llm_requests: List[Request], block_tables: np.ndarray, is_prefill=False, max_block_size=128):
        batch_size = len(llm_requests)
        batch_request_ids = []
        batch_ignore_eos = None
        batch_include_stop = None
        batch_max_output_lens = np.zeros(batch_size, dtype=np.int64)
        batch_skip_special_tokens = None
        batch_stop_strings = None
        batch_stop_token_ids = None
        has_sampling = False
        adapter_ids = None

        input_ids_list = []
        total_seq_num = 0
        batch_sampling_param = None
        batch_seq_len = None

        if is_prefill:
            batch_seq_len = []
            total_seq_num = 0
            batch_ignore_eos = []
            batch_include_stop = []
            batch_skip_special_tokens = []
            batch_stop_strings = []
            batch_stop_token_ids = []
            adapter_ids = []
            for i, llm_request in enumerate(llm_requests):
                batch_request_ids.append(llm_request.req_id)
                input_ids_list.extend(llm_request.input_ids)
                seq_num = llm_request.input_ids.shape[0]
                batch_seq_len.append(seq_num)
                total_seq_num += seq_num
                batch_ignore_eos.append(llm_request.ignore_eos)
                batch_include_stop.append(llm_request.include_stop_str_in_output)
                batch_skip_special_tokens.append(llm_request.skip_special_tokens)
                batch_max_output_lens[i] = llm_request.max_new_tokens
                batch_stop_strings.append(llm_request.stop_strings)
                batch_stop_token_ids.append(llm_request.stop_token_ids)
                adapter_ids.append(llm_request.adapter_id)
                if not has_sampling and llm_request.has_sampling:
                    has_sampling = True
            if all(e is None for e in batch_stop_strings):
                batch_stop_strings = None
            if all(e is None for e in batch_stop_token_ids):
                batch_stop_token_ids = None
            if has_sampling:
                batch_sampling_param = []
                for _, llm_request in enumerate(llm_requests):
                    batch_sampling_param.append(llm_request.sampling_param[0])
                batch_sampling_param = np.array(batch_sampling_param, SAMPLING_DTYPE)
        else:
            for i, llm_request in enumerate(llm_requests):
                batch_request_ids.append(llm_request.req_id)
                batch_max_output_lens[i] = llm_request.max_new_tokens
                if not has_sampling and llm_request.has_sampling:
                    has_sampling = True
        batch_request_ids = np.asarray(batch_request_ids)
        return cls(batch_size, batch_request_ids, batch_max_output_lens, block_tables,
                   input_ids_list=np.asarray(input_ids_list, dtype=np.int64),
                   total_seq_num=total_seq_num,
                   batch_sampling_param=batch_sampling_param,
                   batch_seq_len=np.asarray(batch_seq_len),
                   max_block_size=max_block_size,
                   is_prefill=is_prefill,
                   has_sampling=has_sampling,
                   batch_ignore_eos=np.asarray(batch_ignore_eos),
                   batch_include_stop=np.asarray(batch_include_stop),
                   batch_skip_special_tokens=np.asarray(batch_skip_special_tokens),
                   batch_stop_strings=batch_stop_strings,
                   batch_stop_token_ids=batch_stop_token_ids,
                   adapter_ids=adapter_ids)

    @classmethod
    def from_requests_mix(cls, llm_requests: List[Request],
                          block_tables: np.ndarray,
                          is_prefill_batch: np.ndarray,
                          max_block_size=128):
        is_prefill, is_mix, decode_bs = get_batch_size(is_prefill_batch, llm_requests)
        batch_req_ids = np.asarray([request.req_id for request in llm_requests])
        split_start_pos = np.asarray([request.split_start_position for request in llm_requests])
        split_end_pos = np.asarray([request.split_end_position for request in llm_requests])
        batch_last_prompt = np.asarray([request.last_prompt for request in llm_requests])
        max_output_lens = np.asarray([request.max_new_tokens for request in llm_requests])

        has_sampling = False

        batch_stop_strings = None
        batch_stop_token_ids = None

        batch_input_ids = []
        total_seq_len = 0
        batch_sampling_param = None
        batch_seq_len = None

        if is_prefill:
            batch_stop_strings = []
            batch_stop_token_ids = []
            for _, llm_request in enumerate(llm_requests):
                batch_input_ids.extend(llm_request.input_ids)
                batch_stop_strings.append(llm_request.stop_strings)
                batch_stop_token_ids.append(llm_request.stop_token_ids)
                if not has_sampling and llm_request.has_sampling:
                    has_sampling = True
            if all(e is None for e in batch_stop_strings):
                batch_stop_strings = None
            if all(e is None for e in batch_stop_token_ids):
                batch_stop_token_ids = None

            batch_seq_len = split_end_pos - split_start_pos
            total_seq_len = sum(batch_seq_len)

            if has_sampling:
                sampling_param_num = llm_requests[0].sampling_param.shape[0]
                batch_sampling_param = np.empty((len(llm_requests), sampling_param_num), dtype=np.float32)
                for i, llm_request in enumerate(llm_requests):
                    batch_sampling_param[i, :] = llm_request.sampling_param
        else:
            for _, llm_request in enumerate(llm_requests):
                if not has_sampling and llm_request.has_sampling:
                    has_sampling = True

        return cls(
            batch_size=len(llm_requests),
            batch_request_ids=batch_req_ids,
            batch_max_output_lens=max_output_lens,
            block_tables=block_tables,
            max_block_size=max_block_size,
            has_sampling=has_sampling,
            batch_stop_strings=batch_stop_strings,
            batch_stop_token_ids=batch_stop_token_ids,
            is_prefill=is_prefill,
            input_ids_list=np.asarray(batch_input_ids, dtype=np.int64),
            batch_seq_len=batch_seq_len,
            total_seq_num=total_seq_len,
            batch_sampling_param=batch_sampling_param,
            is_mix=is_mix,
            mix_decode_bs=decode_bs,
            split_start_position=split_start_pos,
            split_end_position=split_end_pos,
            batch_last_prompt=batch_last_prompt,
            batch_is_prefill=is_prefill_batch
        )
