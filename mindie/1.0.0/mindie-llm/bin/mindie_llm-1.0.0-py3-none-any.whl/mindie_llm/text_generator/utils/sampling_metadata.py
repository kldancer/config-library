# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from dataclasses import dataclass
from typing import Any, Optional

import numpy as np

from ...utils.validation import (UPPER_SAFE_BATCH_SIZE, LOWER_SAFE_BATCH_SIZE, UPPER_SAFE_SEQUENCE_LENGTH,
                                 LOWER_SAFE_REPETITION_PENALTY, LOWER_SAFE_TEMPERATURE, UPPER_SAFE_SEED,
                                 LOWER_SAFE_SEED, SAFE_TOP_K, UPPER_SAFE_TOP_P, LOWER_SAFE_TOP_P,
                                 InconsistencyError, OutOfBoundsError, UnsupportedTypeError)


def validate_1d_batch(param_key: str, param_value: np.ndarray) -> None:
    if not isinstance(param_value, np.ndarray):
        raise UnsupportedTypeError(param_key, 'numpy.ndarray')
    if len(param_value.shape) != 1:
        raise InconsistencyError(param_key, f'dimension of `{param_key}', '1')
    batch_size = len(param_value)
    if batch_size > UPPER_SAFE_BATCH_SIZE or batch_size < LOWER_SAFE_BATCH_SIZE:
        raise OutOfBoundsError(param_key, 'SAFE_BATCH_SIZE', f'[{LOWER_SAFE_BATCH_SIZE}, {UPPER_SAFE_BATCH_SIZE}]')


def validate_2d_batch(param_key: str, param_value: np.ndarray) -> None:
    if not isinstance(param_value, np.ndarray):
        raise UnsupportedTypeError(param_key, 'numpy.ndarray')
    if len(param_value.shape) != 2:
        raise InconsistencyError(param_key, f'dimension of `{param_key}', '2')
    batch_size = len(param_value)
    if batch_size > UPPER_SAFE_BATCH_SIZE or batch_size < LOWER_SAFE_BATCH_SIZE:
        raise OutOfBoundsError(param_key, 'SAFE_BATCH_SIZE', f'[{LOWER_SAFE_BATCH_SIZE}, {UPPER_SAFE_BATCH_SIZE}]')
    if len(param_value[0]) > UPPER_SAFE_SEQUENCE_LENGTH:
        raise OutOfBoundsError(param_key, 'UPPER_SAFE_SEQUENCE_LENGTH', UPPER_SAFE_SEQUENCE_LENGTH)


class PenaltyMetadata:
    def __init__(self,
                 has_penalty: bool,
                 repetition_penalty_tensor,
                 frequency_penalty_tensor,
                 presence_penalty_tensor
                 ):
        self.has_penalty = has_penalty
        self.repetition_penalty = repetition_penalty_tensor
        self.frequency_penalty = frequency_penalty_tensor
        self.presence_penalty = presence_penalty_tensor

    def __repr__(self):
        return (f"PenaltyMetadata:\n"
                f"has_penalty: {self.has_penalty},"
                f"repetition_penalty: {self.repetition_penalty},"
                f"frequency_penalty: {self.frequency_penalty},"
                f"presence_penalty: {self.presence_penalty},"
                )


class TopKMetadata:
    def __init__(self,
                 top_k_tensor,
                 top_k_array: np.ndarray,
                 top_k_max: int,
                 top_k_disabled_mask_tensor):
        self.top_k_tensor = top_k_tensor
        self.top_k_array = top_k_array
        self.max_top_k = top_k_max
        self.top_k_disabled_mask_tensor = top_k_disabled_mask_tensor

    def __repr__(self):
        return (f"TopKMetadata:\n"
                f"top_k_tensor: {self.top_k_tensor},"
                f"max_top_k: {self.max_top_k},"
                f"top_k_disabled_mask_tensor: {self.top_k_disabled_mask_tensor},"
                )


@dataclass
class TopPMetadata:
    def __init__(self,
                 top_p_tensor,
                 top_p_array: np.ndarray):
        self.top_p_tensor = top_p_tensor
        self.top_p_array = top_p_array

    def __repr__(self):
        return (f"TopPMetadata:\n"
                f"top_p_tensor: {self.top_p_tensor},"
                f"top_p_array: {self.top_p_array},"
                )


@dataclass
class SeedMetadata:
    def __init__(self,
                 seed_array: np.ndarray):
        self.seed_array = seed_array

    def __repr__(self):
        return (f"SeedMetadata:\n"
                f"seed_array: {self.seed_array}"
                )


@dataclass
class DoSampleMetadata:
    def __init__(self,
                 do_sample_tensor,
                 do_sample_array: np.ndarray):
        self.do_sample_tensor = do_sample_tensor
        self.do_sample_array = do_sample_array

    def __repr__(self):
        return (f"DoSampleMetadata:\n"
                f"do_sample_tensor: {self.do_sample_tensor},"
                f"do_sample_array: {self.do_sample_array},"
                )


@dataclass
class SamplingData:
    """
    The data class containing some metadata for sampling. It must be instantiated by `from_numpy` method, otherwise the
    safety validation will be skipped.
    """

    def __init__(
        self,
        all_input_ids: Any,
        output_ids: Any,
        is_prefill: bool = True,
        request_ids: Optional[np.ndarray] = None
    ):
        self.all_input_ids = all_input_ids
        self.output_ids = output_ids
        self.is_prefill = is_prefill
        self.request_ids = request_ids

    def __repr__(self):
        return (f"SamplingMetadata:\n"
                f"all_input_ids: {self.all_input_ids},"
                f"output_ids: {self.output_ids},"
                f"is_prefill: {self.is_prefill},"
                f"request_ids: {self.request_ids},"
                )

    @classmethod
    def from_numpy(
        cls,
        all_input_ids: Optional[np.ndarray] = None,
        output_ids: Optional[np.ndarray] = None,
        to_tensor: Optional[callable] = None,
        is_prefill: bool = True,
        request_ids: Optional[np.ndarray] = None
    ):
        if request_ids is not None:
            validate_1d_batch('request_ids', request_ids)
            if all_input_ids is not None and len(all_input_ids) != len(request_ids):
                raise InconsistencyError('all_input_ids', 'length of `all_input_ids`', 'length of `request_ids`')
            if output_ids is not None and len(output_ids) != len(request_ids):
                raise InconsistencyError('output_ids', 'length of `output_ids`', 'length of `request_ids`')
        else:
            validate_2d_batch('all_input_ids', all_input_ids) if all_input_ids is not None else None
            validate_2d_batch('output_ids', output_ids) if output_ids is not None else None
        if not isinstance(is_prefill, bool):
            raise UnsupportedTypeError('is_prefill', 'bool')

        # The user must guarantee the `to_tensor` function returning correct Tensor type for the backend used.
        all_input_ids_tensor = to_tensor(all_input_ids) if all_input_ids is not None else None
        output_ids_tensor = to_tensor(output_ids) if output_ids is not None else None
        return SamplingData(
            all_input_ids=all_input_ids_tensor,
            output_ids=output_ids_tensor,
            is_prefill=is_prefill,
            request_ids=request_ids
        )


class SamplingParam:
    """
    The data class containing some parameters for sampling. It must be instantiated by `from_numpy` method, otherwise
    the safety validation will be skipped.
    """

    def __init__(
        self,
        penalty_meta: PenaltyMetadata,
        temperature,
        top_k_meta: TopKMetadata,
        top_p_meta: TopPMetadata,
        seed_meta: SeedMetadata,
        do_sample_meta: DoSampleMetadata,
    ):
        self.penalty_meta = penalty_meta
        self.temperature = temperature
        self.top_k_meta = top_k_meta
        self.top_p_meta = top_p_meta
        self.seed_meta = seed_meta
        self.do_sample_meta = do_sample_meta

    def __repr__(self):
        return (f"SamplingMetadata:\n"
                f"penalty_meta: {self.penalty_meta},"
                f"temperature: {self.temperature},"
                f"top_k_meta: {self.top_k_meta},"
                f"top_p: {self.top_p_meta},"
                f"seed: {self.seed_meta},"
                f"do_sample: {self.do_sample_meta},")

    @classmethod
    def from_numpy(
        cls,
        repetition_penalty: Optional[np.ndarray] = None,
        frequency_penalty: Optional[np.ndarray] = None,
        presence_penalty: Optional[np.ndarray] = None,
        temperature: Optional[np.ndarray] = None,
        top_k: Optional[np.ndarray] = None,
        top_p: Optional[np.ndarray] = None,
        seed: Optional[np.ndarray] = None,
        do_sample: Optional[np.ndarray] = None,
        to_tensor: Optional[callable] = None
    ) -> "SamplingParam":
        has_penalty = False
        rp_tensor = None
        if repetition_penalty is not None:
            validate_1d_batch('repetition_penalty', repetition_penalty)
            if np.asarray(repetition_penalty != 1.0).any():
                if np.asarray(repetition_penalty <= LOWER_SAFE_REPETITION_PENALTY).any():
                    raise OutOfBoundsError('repetition_penalty', 'LOWER_SAFE_REPETITION_PENALTY',
                                           LOWER_SAFE_REPETITION_PENALTY)
                rp_tensor = to_tensor(repetition_penalty).unsqueeze(1)
                has_penalty = True
        fp_tensor = None
        if frequency_penalty is not None:
            validate_1d_batch('frequency_penalty', frequency_penalty)
            if np.asarray(frequency_penalty != 0.0).any():
                fp_tensor = to_tensor(frequency_penalty).unsqueeze(1)
                has_penalty = True
        pp_tensor = None
        if presence_penalty is not None:
            validate_1d_batch('presence_penalty', presence_penalty)
            if np.asarray(presence_penalty != 0.0).any():
                pp_tensor = to_tensor(presence_penalty).unsqueeze(1)
                has_penalty = True
        penalty_meta = PenaltyMetadata(has_penalty=has_penalty,
                                       repetition_penalty_tensor=rp_tensor,
                                       frequency_penalty_tensor=fp_tensor,
                                       presence_penalty_tensor=pp_tensor)

        do_sample_tensor = None
        tem_tensor = None
        top_k_meta = None
        top_p_meta = None
        seed_meta = None
        if do_sample is not None:
            validate_1d_batch('do_sample', do_sample)
            if any(do_sample):

                if temperature is not None:
                    validate_1d_batch('temperature', temperature)
                    if np.asarray(temperature != 1.0).any():
                        if np.asarray(temperature < LOWER_SAFE_TEMPERATURE).any():
                            raise OutOfBoundsError('temperature', 'LOWER_SAFE_TEMPERATURE', LOWER_SAFE_TEMPERATURE)
                        t0_mask = np.asarray(temperature == 0)
                        do_sample[t0_mask] = False
                        temperature[t0_mask] = 1.0
                        tem_tensor = to_tensor(temperature).unsqueeze(1)

                do_sample_tensor = to_tensor(do_sample)

                max_top_k = 0
                top_k_tensor = None
                top_k_disabled_mask = None
                if top_k is not None:
                    validate_1d_batch('top_k', top_k)
                    if np.asarray(top_k < SAFE_TOP_K).any():
                        raise OutOfBoundsError('top_k', 'SAFE_TOP_K', SAFE_TOP_K)
                    if top_k.dtype != np.int_:
                        top_k = top_k.astype(np.int_)
                    if np.asarray(top_k != 0).any():
                        top_k_tmp = np.maximum(top_k - 1, 0)
                        max_top_k = top_k.max()
                        top_k_tensor = to_tensor(top_k_tmp).unsqueeze(1)
                        disabled = top_k == 0
                        top_k_disabled_mask = None
                        if np.asarray(disabled).any():
                            top_k_disabled_mask = to_tensor(disabled).view(-1, 1)
                top_k_meta = TopKMetadata(top_k_tensor=top_k_tensor,
                                          top_k_array=top_k,
                                          top_k_max=max_top_k,
                                          top_k_disabled_mask_tensor=top_k_disabled_mask)

                top_p_tensor = None
                if top_p is not None:
                    validate_1d_batch('top_p', top_p)
                    if np.asarray(top_p < LOWER_SAFE_TOP_P).any() or np.asarray(top_p > UPPER_SAFE_TOP_P).any():
                        raise OutOfBoundsError('top_p', 'SAFE_TOP_P', f'[{LOWER_SAFE_TOP_P}, {UPPER_SAFE_TOP_P}]')
                    if np.asarray(top_p != 1).any():
                        top_p_tensor = to_tensor(top_p).unsqueeze(1)
                top_p_meta = TopPMetadata(top_p_tensor, top_p)

                if seed is not None:
                    validate_1d_batch('seed', seed)
                    if np.asarray(seed < LOWER_SAFE_SEED).any() or np.asarray(seed > UPPER_SAFE_SEED).any():
                        raise OutOfBoundsError('seed', 'SAFE_SEED', f'[{LOWER_SAFE_SEED}, {UPPER_SAFE_SEED}]')
                    if seed.dtype != np.int64:
                        seed = seed.astype(np.int64)
                seed_meta = SeedMetadata(seed)

        do_sample_meta = DoSampleMetadata(do_sample_tensor, do_sample)
        return SamplingParam(
            penalty_meta=penalty_meta,
            temperature=tem_tensor,
            top_k_meta=top_k_meta,
            top_p_meta=top_p_meta,
            seed_meta=seed_meta,
            do_sample_meta=do_sample_meta,
        )
