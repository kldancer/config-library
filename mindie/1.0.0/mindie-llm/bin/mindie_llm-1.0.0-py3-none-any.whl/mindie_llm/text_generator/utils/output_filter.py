# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import partial
from typing import Any, List, Union

import numpy as np

from .batch import BatchCache
from .config import ResponseConfig
from .input_metadata import InputMetadata
from .stopping_criteria import batch_single_eos, make_batch_mixed_eos
from ..samplers import Sampler
from ...utils.env import ENV
from ...utils.log.error_code import ErrorCode
from ...utils.log.logging import logger, print_log


class OutputFilter:
    def __init__(self, cache: BatchCache, tokenizer: Any):
        self.cache = cache
        self.cache_config = self.cache.cache_config
        self.tokenizer = tokenizer

        self.eos_token_id = self.cache_config.eos_token_id
        self.ignore_eos = self.cache_config.ignore_eos
        self.rank = self.cache_config.rank
        print_log(self.rank, logger.info, f'The effective eos_token_id is `{self.eos_token_id}`.')
        self.tokenizer_sliding_window_size = self.cache_config.tokenizer_sliding_window_size

        self.default_stopping_criterion = self._make_batch_stopping_criterion(self.eos_token_id)
        self.cached_output_texts = self.cache.cached_output_texts
        self.stopping_criteria = self.cache.stopping_criteria
        self.string_stopping_criteria = self.cache.string_stopping_criteria

    @staticmethod
    def _make_batch_stopping_criterion(eos_token_id: Union[int, List[Union[int, List[int]]]]):
        if isinstance(eos_token_id, int):
            stopping_criterion = partial(batch_single_eos, eos_token_id=eos_token_id)
        elif isinstance(eos_token_id, list) and eos_token_id:
            stopping_criterion = make_batch_mixed_eos(eos_token_id)
        else:
            message = ('The configured `eos_token_id` has an incorrect format. It must be an integer or a list of '
                       'integers. You can modify the `eos_token_id` in the `generation_config.json` file of the model '
                       'weights.')
            logger.error(message, ErrorCode.TEXT_GENERATOR_EOS_TOKEN_ID_TYPE_INVALID)
            raise ValueError('eos_token_id must be int or list')
        return stopping_criterion

    def decode_one(self, input_tokens, skip_special_tokens):
        pre_index = len(input_tokens) - 1
        start_index = max(pre_index - self.tokenizer_sliding_window_size, 0)
        window_text = self.tokenizer.decode(input_tokens[start_index:], skip_special_tokens=skip_special_tokens)
        if pre_index == 0:
            pre_text = ''
        else:
            pre_text = self.tokenizer.decode(input_tokens[start_index:pre_index],
                                             skip_special_tokens=skip_special_tokens)
            pre_text = pre_text.rstrip('�')

        if len(window_text) > len(pre_text) and not window_text.endswith('�'):
            return window_text[len(pre_text):]
        else:
            return ''

    def filter_by_eos(self, cache_ids, filter_ids_arr, end_reason):
        checked = self.default_stopping_criterion(self.cache.cached_out_ids[cache_ids],
                                                  self.cache.output_len_count[cache_ids] - 1)
        checked[self.cache.cached_ignore_eos[cache_ids]] = False
        eos_idx = np.nonzero(checked)[0]
        if eos_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, eos_idx)
        end_reason[eos_idx] = ResponseConfig.EOS
        return filter_ids_arr

    def filter_by_length(self, cache_ids, metadata, filter_ids_arr, end_reason):
        exceed_seq_limit_idx = np.nonzero(self.cache.cached_seq_lens[cache_ids] >= self.cache_config.max_seq_len)[0]
        exceed_user_output_limit_idx = np.nonzero(
            self.cache.output_len_count[cache_ids] >= metadata.batch_max_output_lens)[0]
        exceed_global_output_limit_idx = np.nonzero(
            self.cache.output_len_count[cache_ids] >= self.cache_config.max_gen_len)[0]

        if exceed_seq_limit_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, exceed_seq_limit_idx)
        if exceed_user_output_limit_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, exceed_user_output_limit_idx)
        if exceed_global_output_limit_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, exceed_global_output_limit_idx)

        end_reason[exceed_seq_limit_idx] = ResponseConfig.REACH_MAX_SEQ_LEN
        end_reason[exceed_user_output_limit_idx] = ResponseConfig.REACH_MAX_OUTPUT_LEN
        end_reason[exceed_global_output_limit_idx] = ResponseConfig.REACH_MAX_OUTPUT_LEN
        return filter_ids_arr

    def filter_by_stop(self, cache_ids, filter_ids_arr, end_reason, next_tokens):
        checked_strings = np.zeros(len(cache_ids), dtype=np.bool_)
        checked_ids = np.zeros(len(cache_ids), dtype=np.bool_)
        truncation_indices = np.zeros(len(cache_ids), dtype=np.int_)
        for i, idx in enumerate(cache_ids):
            new_token_len = len(next_tokens[i])
            string_stopping_criterion = self.string_stopping_criteria.get(idx)
            stopping_criterion = self.stopping_criteria.get(idx)
            switch_stop_string = string_stopping_criterion is not None
            switch_stop_id = stopping_criterion is not None

            if switch_stop_string or switch_stop_id:
                cur_len = 0
                for len_tmp in range(new_token_len):
                    total_len = self.cache.output_len_count[idx]
                    cur_len = len_tmp + 1
                    new_token = self.decode_one(
                        self.cache.cached_out_ids[idx, :total_len - (new_token_len - cur_len)],
                        bool(self.cache.cached_skip_special_tokens[idx])
                    )
                    self.cached_output_texts[idx] += new_token

                    if switch_stop_string:
                        truncation_idx = string_stopping_criterion(self.cached_output_texts[idx], new_token,
                                                                include_stop=self.cache.cached_include_stop[idx])
                        if truncation_idx is not None:
                            checked_strings[i] = True
                            truncation_indices[i] = truncation_idx
                            break

                    if switch_stop_id:
                        checked_ids[i] = stopping_criterion(self.cache.cached_out_ids[idx,
                                                            :total_len - (new_token_len - cur_len)])
                        if checked_ids[i]:
                            if not self.cache.cached_include_stop[idx]: 
                                truncation_indices[i] = -len(new_token)
                            break
                if cur_len == 0:
                    raise RuntimeError('Empty `token_ids` generated!')
                next_tokens[i] = next_tokens[i][:cur_len]
        stop_strings_idx = np.nonzero(checked_strings)[0]
        stop_ids_idx = np.nonzero(checked_ids)[0]
        if stop_ids_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, stop_ids_idx)
        if stop_strings_idx.size != 0:
            filter_ids_arr = np.union1d(filter_ids_arr, stop_strings_idx)
        end_reason[stop_ids_idx] = ResponseConfig.STOP_TOKEN_IDS
        end_reason[stop_strings_idx] = ResponseConfig.STOP_STRINGS
        return filter_ids_arr, truncation_indices.reshape(-1, 1)

    def filter_output(self, metadata: InputMetadata, cache_ids: np.ndarray, next_tokens: list, sampler: Sampler = None):
        filter_ids_arr = np.array([], dtype=np.int32)
        end_reason = np.zeros_like(cache_ids)
        if not self.ignore_eos:
            filter_ids_arr = self.filter_by_eos(cache_ids, filter_ids_arr, end_reason)
        filter_ids_arr, truncation_indices = self.filter_by_stop(cache_ids, filter_ids_arr, end_reason, next_tokens)
        filter_ids_arr = self.filter_by_length(cache_ids, metadata, filter_ids_arr, end_reason)

        # 对于没有完成prefill的req，不可以清除后处理参数
        if metadata.is_mix is not None:
            idx = np.where(metadata.batch_last_prompt == 0)[0]
            unfinished_idx = np.isin(filter_ids_arr, idx)
            filter_ids_arr = filter_ids_arr[~unfinished_idx]

        if filter_ids_arr.shape[0] == 0:
            res_and_stop = (False, end_reason, None, truncation_indices)
        elif not ENV.continuous_batching:  # 非CB场景，batch中所有请求都结束才结束
            filter_out_ids = cache_ids[filter_ids_arr]
            self.cache.cached_end_flag[filter_out_ids] = 1  # 更新结束标志
            if np.all(self.cache.cached_end_flag[cache_ids]):
                self.cache.cached_end_flag[cache_ids] = 0
                # batch中的请求全部结束，清理缓存
                self.cache.clear_batch_cache(cache_ids, filter_ids_arr, metadata, sampler)
                res_and_stop = (True, end_reason, np.arange(cache_ids.shape[0], dtype=np.int32), truncation_indices)
            else:
                res_and_stop = (False, end_reason, None, truncation_indices)
        else:
            self.cache.clear_batch_cache(cache_ids, filter_ids_arr, metadata, sampler)
            res_and_stop = (True, end_reason, filter_ids_arr, truncation_indices)
        return res_and_stop
