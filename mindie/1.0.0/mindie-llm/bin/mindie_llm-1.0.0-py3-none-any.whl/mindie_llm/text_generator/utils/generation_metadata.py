# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from dataclasses import dataclass
from typing import List, Optional, Union


@dataclass
class GenerationParams:
    ignore_eos: Optional[bool] = None
    include_stop_str_in_output: Optional[bool] = None
    max_new_tokens: Optional[int] = None
    skip_special_tokens: Optional[bool] = None
    stop_strings: Optional[List[str]] = None
    stop_token_ids: Optional[List[Union[int, List[int]]]] = None
    adapter_id: Optional[str] = None
