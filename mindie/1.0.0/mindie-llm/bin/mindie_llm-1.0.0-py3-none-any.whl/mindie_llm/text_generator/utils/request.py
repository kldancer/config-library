# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Optional

import numpy as np

from .generation_metadata import GenerationParams

MAX_GEN_LEN = 512


class Request:
    def __init__(self,
                 req_id: int,
                 input_ids: np.ndarray,
                 generation_params: GenerationParams,
                 has_sampling: bool = False,
                 sampling_param: Optional[np.ndarray] = None,
                 split_start_position: int = 0,
                 split_end_position: int = 0,
                 last_prompt: bool = True):
        self.req_id = req_id
        self.input_ids = input_ids
        self.ignore_eos = generation_params.ignore_eos
        self.include_stop_str_in_output = generation_params.include_stop_str_in_output
        self.max_new_tokens = generation_params.max_new_tokens
        self.skip_special_tokens = generation_params.skip_special_tokens
        self.stop_strings = generation_params.stop_strings
        self.stop_token_ids = generation_params.stop_token_ids
        self.adapter_id = generation_params.adapter_id
        self.has_sampling = has_sampling
        self.sampling_param = sampling_param
        self.block_tables = None
        self.input_length = np.size(self.input_ids)
        self.out_token_list = []

        # mix 
        self.split_start_position = split_start_position
        self.split_end_position = split_end_position
        self.last_prompt = last_prompt

    @classmethod
    def from_warmup(cls, input_len: int, max_output_len: int):
        req_id = 0
        input_ids = np.ones(input_len, dtype=np.int64)

        return cls(req_id, input_ids, GenerationParams(max_new_tokens=max_output_len),
                   split_start_position=0, split_end_position=0)

    @classmethod
    def from_request(cls, request, is_prefill=False):
        req_id = 0
        max_output_len = MAX_GEN_LEN
        has_sampling = False
        sampling_param = None
        input_ids = None

        input_tensors = request.inputs()
        for input_tensor in input_tensors:
            if input_tensor.name() == "IBIS_ATTR":
                req_id = np.array(input_tensor, copy=False)[0][0]
                max_output_len = np.array(input_tensor, copy=False)[0][3]
            elif input_tensor.name() == "SAMPLING":
                has_sampling = True
                if is_prefill:
                    sampling_param = np.array(input_tensor, copy=False)[0]
            elif is_prefill and input_tensor.name() == "INPUT_IDS":
                input_ids = np.array(input_tensor, copy=False)[0]

        return cls(req_id, input_ids, GenerationParams(max_new_tokens=max_output_len), has_sampling, sampling_param)

    @classmethod
    def request_from_token(cls, input_ids, sampling_param, generation_params=None, req_idx=0):
        input_ids = np.array(input_ids, dtype=np.int64)
        has_sampling = True if sampling_param is not None else False
        return cls(req_idx, input_ids, generation_params, has_sampling, sampling_param)
