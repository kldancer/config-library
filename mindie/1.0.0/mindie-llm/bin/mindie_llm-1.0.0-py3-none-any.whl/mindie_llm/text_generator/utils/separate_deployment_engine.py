# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import List, Union, Tuple
import ipaddress
from llm_datadist import LLMRole, LLMClusterInfo, BlocksCacheKey, LLMStatusCode
from llm_datadist import CacheDesc, DataType, KvCache, LLMException, Placement
from llm_datadist import LLMDataDist
from mindie_llm.utils.log.logging import logger
from mindie_llm.utils.error import MindieLlmErrorCode

STR_DTYPE_TO_DTYPE = {
    "float16": DataType.DT_FLOAT16,
    "bfloat16": DataType.DT_BF16,
    "float": DataType.DT_FLOAT,
    "int8": DataType.DT_INT8,
}

WORKSPACE_SIZE = 500 * 1024 * 1024


class ClusterInfo:
    def __init__(self, remote_cluster_id):
        self.remote_cluster_id = remote_cluster_id
        self._remote_cluster_info: List[Tuple(str, int)] = None
        self._local_cluster_info: List[Tuple(str, int)] = None

    @classmethod
    def ip_port(cls, ip_port):
        ip_str = ip_port.split(':')[0]
        port_str = ip_port.split(':')[1]
        return (ip_str, int(port_str))

    def get_remote_cluster_info(self):
        return self._remote_cluster_info

    def set_remote_cluster_info(self, value: List[str]):
        self._remote_cluster_info = []
        for ip_port in value:
            self._remote_cluster_info.append(self.ip_port(ip_port))

    def get_local_cluster_info(self):
        return self._local_cluster_info

    def set_local_cluster_info(self, value: List[str]):
        self._local_cluster_info = []
        for ip_port in value:
            self._local_cluster_info.append(self.ip_port(ip_port))


class SeparateDeploymentEngine:
    def __init__(self, role='decoder', npu_size=0, enable_switch_role=True,
                 local_cluster_id=0, device_id=0, device_ip_port='192.168.1.1:1234'):
        if role == 'prefill':
            engine_role = LLMRole.PROMPT
        elif role == 'decoder':
            engine_role = LLMRole.DECODER
        else:
            raise Exception("SeparateDeploymentEngine: only support: prefill, decoder")

        self.separate_deployment_engine = LLMDataDist(engine_role, local_cluster_id)
        self.role = role

        options = {
            "ge.exec.deviceId": str(device_id),
            "ge.flowGraphMemMaxSize": str(int(npu_size) + WORKSPACE_SIZE),
            "llm.BufPoolCfg": '{"buf_cfg":[{"total_size":4194304,"blk_size":256,"max_buf_size":2097152}]}',
            'ge.session_device_id': str(device_id)
        }
        if engine_role == LLMRole.PROMPT:
            options["llm.listenIpInfo"] = device_ip_port
        if enable_switch_role:
            options["llm.EnableSwitchRole"] = '1'
        self.enable_switch_role = enable_switch_role
        self.separate_deployment_engine.init(options)
        self.kv_cache = None
        self.cpu_kv_cache = None
        self.kv_cache_key = None
    
    @staticmethod
    def construct_llm_clusters_info(clusters):
        res = []
        for cluster in clusters:
            clusters_info = LLMClusterInfo()
            clusters_info.remote_cluster_id = cluster.remote_cluster_id
            for remote_cluster_info in cluster.get_remote_cluster_info():
                clusters_info.append_remote_ip_info(*remote_cluster_info)
            for local_cluster_info in cluster.get_local_cluster_info():
                clusters_info.append_local_ip_info(*local_cluster_info)
            res.append(clusters_info)
        return res
    
    @staticmethod
    def is_valid_ip(address):
        try:
            ipaddress.ip_address(address)
            return True
        except ValueError:
            return False
    
    def link_clusters(self, clusters: Union[List[ClusterInfo], Tuple[ClusterInfo]], timeout=-1):
        inputs = self.construct_llm_clusters_info(clusters)
        return self.separate_deployment_engine.link_clusters(inputs, timeout)

    def unlink_clusters(self, clusters: Union[List[ClusterInfo], Tuple[ClusterInfo]], timeout=-1):
        inputs = self.construct_llm_clusters_info(clusters)
        return self.separate_deployment_engine.unlink_clusters(inputs, timeout)

    # trans those addrs to torchTensor or mindsporeTensor
    def alloc_npu_cache(self, num_tensors: int, num_blocks: int, blockshape: Tuple, dtype: str) -> List[int]:
        block_shape = tuple(map(int, blockshape))
        kv_cache_desc = CacheDesc(num_tensors=int(num_tensors),
                                  shape=(int(num_blocks), *block_shape), data_type=STR_DTYPE_TO_DTYPE[dtype])
        if self.role == 'prefill':
            self.kv_cache_key = BlocksCacheKey(prompt_cluster_id=self.separate_deployment_engine.cluster_id,
                                            model_id=0)
        self.kv_cache = self.separate_deployment_engine.kv_cache_manager.allocate_blocks_cache(kv_cache_desc,
                                                                                               self.kv_cache_key)
        return self.kv_cache.per_device_tensor_addrs[0]

    def set_cpu_cache(self, cpu_cache):
        self.cpu_kv_cache = cpu_cache

    def release_npu_cache(self):
        self.separate_deployment_engine.kv_cache_manager.deallocate_cache(self.kv_cache)

    def pull_kv(self, src_block_table: List[int], dst_block_table: List[int], prompt_cluster_id: int):
        prompt_cache_key = BlocksCacheKey(prompt_cluster_id=prompt_cluster_id, model_id=0)
        try:
            self.separate_deployment_engine.kv_cache_manager.pull_blocks(prompt_cache_key, self.kv_cache,
                                                                        src_block_table, dst_block_table)
            return MindieLlmErrorCode.SUCCESS
        except LLMException as e:
            logger.error(e.status_code)
            if e.status_code == LLMStatusCode.LLM_UNKNOWN_ERROR or e.status_code == LLMStatusCode.LLM_FAILED:
                return MindieLlmErrorCode.PD_UNKNOW_ERROR
            else:
                return MindieLlmErrorCode.PD_LLM_ENGINE_ERROR

    def swap_in(self, src_to_dst: dict[int, int]):
        cpu_cache = self.cpu_kv_cache
        npu_cache = self.kv_cache
        self.separate_deployment_engine.kv_cache_manager.swap_blocks(cpu_cache, npu_cache, src_to_dst)

    def swap_out(self, src_to_dst: dict[int, int]):
        cpu_cache = self.cpu_kv_cache
        npu_cache = self.kv_cache
        self.separate_deployment_engine.kv_cache_manager.swap_blocks(npu_cache, cpu_cache, src_to_dst)

    def finalize(self):
        self.separate_deployment_engine.finalize()


class SeparateDeploymentWorker:
    def __init__(self, role: str, npu_size: int, local_device_id: int,
                 local_cluster_id: int, local_device_ip: str,
                 remote_cluster_ids: List[int],
                 remote_device_ips: List[str],
                 pd_sepd_npu_port: str,
                 enable_switch_role=True, time_out=6000):
        self.role = role
        self.local_device_ip = local_device_ip
        self.remote_device_ips = remote_device_ips
        self.pd_sepd_npu_port = pd_sepd_npu_port
        self.local_device_ip_port = self.local_device_ip + ':' + self.pd_sepd_npu_port
        self.remote_device_ip_ports = []
        if self.remote_device_ips != []:
            for ips in self.remote_device_ips:
                self.remote_device_ip_ports.append(ips + ':' + self.pd_sepd_npu_port)             
        self.time_out = time_out
        self.local_cluster_id = local_cluster_id
        self.remote_cluster_ids = remote_cluster_ids
        self.ipport_id_map = {}
        self.addrs = []
        self.cache_desc = None
        self.cache_desc_cpu = None
        self.enable_switch_role = enable_switch_role
        self.max_block_nums = 0
        if role == 'decoder':
            self.separate_deployment_engine = SeparateDeploymentEngine(role=role, npu_size=npu_size,
                                    enable_switch_role=enable_switch_role, local_cluster_id=local_cluster_id,
                                    device_id=local_device_id, device_ip_port=self.local_device_ip_port)
        elif role == 'prefill':
            if len(self.remote_device_ip_ports) > 0:
                raise Exception("SeparateDeploymentEngine: prefill role don't need remote")
            self.separate_deployment_engine = SeparateDeploymentEngine(role=role, npu_size=npu_size,
                                    enable_switch_role=enable_switch_role, local_cluster_id=local_cluster_id,
                                    device_id=local_device_id, device_ip_port=self.local_device_ip_port)
        else:
            raise Exception("SeparateDeploymentEngine: not support role")

    @staticmethod
    def get_ip_int(self, device_ip_port):
        ip_str = device_ip_port.split(':')[0]
        return int(ipaddress.IPv4Address(ip_str))

    def build(self, num_tensors, num_blocks, num_blocks_cpu, blockshape, dtype):
        if self.remote_device_ips == ['']:
            self.remote_device_ips.clear()
        if self.role == 'decoder':
            for ind, item in enumerate(self.remote_device_ips):
                self.ipport_id_map[item + ":" + self.pd_sepd_npu_port] = self.remote_cluster_ids[ind]
                self.link(item, self.time_out)
        self.addrs = self.separate_deployment_engine.alloc_npu_cache(num_tensors=num_tensors, num_blocks=num_blocks,
                                                                   blockshape=blockshape, dtype=dtype)
        self.cache_desc = self.separate_deployment_engine.kv_cache.cache_desc
        block_shape = tuple(map(int, blockshape))
        self.cache_desc_cpu = CacheDesc(num_tensors=int(num_tensors), shape=(int(num_blocks_cpu), *block_shape),
                                data_type=STR_DTYPE_TO_DTYPE[dtype], placement=Placement.HOST)
        self.max_block_nums = num_blocks

    def get_addrs(self):
        return self.addrs

    def get_cache_desc(self):
        return self.cache_desc

    def set_cpu_cache(self, cpu_addrs: List[int]):
        cpu_cache = KvCache.create_cpu_cache(self.cache_desc_cpu, cpu_addrs)
        self.separate_deployment_engine.set_cpu_cache(cpu_cache)

    # 目前不支持并发拉blocks，带宽利用率80%，带宽200Gb/s, RDMA
    def pull_blocks(self, remote_model_instance_id: int,
                    src_block_table: List[int], dst_block_table: List[int]):
        if remote_model_instance_id not in self.remote_cluster_ids:
            logger.error(f"pull_kv error: remote_model_instance_id {remote_model_instance_id} is not linked")
            return MindieLlmErrorCode.PD_MODEL_INSTANCE_ID_ERROR
        if not all(map(lambda x: 0 <= x < self.max_block_nums, dst_block_table)):
            logger.error("pull_kv error: block id out of range")
            return MindieLlmErrorCode.PD_BLOCK_ID_OUT_OF_RANGE

        if self.role == 'prefill':
            raise Exception("SeparateDeploymentEngine: prefill role don't need pull blocks")
        rt = self.separate_deployment_engine.pull_kv(src_block_table=src_block_table, dst_block_table=dst_block_table,
                                              prompt_cluster_id=remote_model_instance_id)
        return rt

    def link(self, remote_device_ip, remote_cluster_id=0, time_out=25000):
        remote_device_ip_port = ''
        if remote_device_ip != '':
            remote_device_ip_port = remote_device_ip + ":" + self.pd_sepd_npu_port
        if remote_device_ip_port not in self.ipport_id_map:
            self.remote_cluster_ids.append(remote_cluster_id)
            self.remote_device_ips.append(remote_device_ip)
            self.ipport_id_map[remote_device_ip_port] = remote_cluster_id
        cluster_info = ClusterInfo(self.ipport_id_map[remote_device_ip_port])
        remote_ip_ports = []
        remote_ip_ports.append(remote_device_ip_port)
        local_ip_ports = []
        local_ip_ports.append(self.local_device_ip_port)
        cluster_info.set_remote_cluster_info(remote_ip_ports)
        cluster_info.set_local_cluster_info(local_ip_ports)
        cluster_infos = [cluster_info]
        ret, rets = self.separate_deployment_engine.link_clusters(cluster_infos, time_out)
        if ret != LLMStatusCode.LLM_SUCCESS:
            logger.error(f"{self.local_device_ip_port} -> {remote_device_ip_port}: link fail")
            return MindieLlmErrorCode.PD_LLM_ENGINE_ERROR
        return MindieLlmErrorCode.SUCCESS
    
    def unlink(self, remote_device_ip, remote_cluster_id=-1, time_out=6000):
        remote_device_ip_port = ''
        if remote_device_ip != '':
            remote_device_ip_port = remote_device_ip + ":" + self.pd_sepd_npu_port
        local_device_ip_port = self.local_device_ip_port
        rcid = self.ipport_id_map[remote_device_ip_port] if remote_cluster_id == -1 else remote_cluster_id
        cluster_info = ClusterInfo(rcid)
        remote_ip_ports = []
        remote_ip_ports.append(remote_device_ip_port)
        local_ip_ports = []
        local_ip_ports.append(local_device_ip_port)
        cluster_info.set_remote_cluster_info(remote_ip_ports)
        cluster_info.set_local_cluster_info(local_ip_ports)
        cluster_infos = [cluster_info]
        ret, rets = self.separate_deployment_engine.unlink_clusters(cluster_infos, time_out)
        if ret != LLMStatusCode.LLM_SUCCESS:
            logger.error(f"{self.local_device_ip_port} -> {remote_device_ip_port}: unlink fail")
            return MindieLlmErrorCode.PD_LLM_ENGINE_ERROR
        if remote_cluster_id == -1:
            self.remote_cluster_ids.remove(rcid)
            self.remote_device_ips.remove(remote_device_ip)
            del self.ipport_id_map[remote_device_ip_port]
        return MindieLlmErrorCode.SUCCESS

    def unlink_all(self, time_out=6000):
        if self.role == 'decoder':
            for x in self.remote_device_ips:
                ret = self.unlink(x, -1, time_out)
                if ret != MindieLlmErrorCode.SUCCESS:
                    raise Exception("SeparateDeploymentEngine: unlink_all fail")

    def switch_role(self, role: str, local_device_ip=''):
        local_device_ip_port = ''
        if local_device_ip != '':
            local_device_ip_port = local_device_ip + ":" + self.pd_sepd_npu_port       
        if role == self.role:
            raise Exception("SeparateDeploymentEngine: switch role is not changed")
        if not self.enable_switch_role:
            raise Exception("SeparateDeploymentEngine: switch role is not enabled")
        if role == 'prefill':
            engine_role = LLMRole.PROMPT
        elif role == 'decoder':
            engine_role = LLMRole.DECODER
        else:
            raise Exception("SeparateDeploymentEngine: only support: prefill, decoder")
        self.unlink_all()
        switch_options = {}
        if role == 'prefill':
            if local_device_ip_port == '':
                local_device_ip_port = self.local_device_ip_port
            switch_options['llm.listenIpInfo'] = local_device_ip_port
        llm_datadist = self.separate_deployment_engine.separate_deployment_engine
        llm_datadist.switch_role(engine_role, switch_options)
        self.role = role
        self.separate_deployment_engine.role = role
        self.separate_deployment_engine.kv_cache_key = None
        self.separate_deployment_engine.release_npu_cache()

    def swap_in(self, src_to_dst: dict[int, int]):
        self.separate_deployment_engine.swap_in(src_to_dst)

    def swap_out(self, src_to_dst: dict[int, int]):
        self.separate_deployment_engine.swap_out(src_to_dst)

    def finalize(self):
        self.separate_deployment_engine.release_npu_cache()        
        self.unlink_all(self.time_out)
        self.separate_deployment_engine.finalize()
