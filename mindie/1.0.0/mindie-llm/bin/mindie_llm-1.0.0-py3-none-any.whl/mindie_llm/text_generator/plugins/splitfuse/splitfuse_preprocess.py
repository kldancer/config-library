# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np

from ...utils.input_metadata import InputMetadata
from ...utils.input_manager import ModelInput
from ...utils.sampling_metadata import SamplingParam
from ....utils.decorators.time_decorator import timer


class SplitFuseCacheEngine:
    def __init__(self, input_manager):
        self.input_manager = input_manager

    def get_mix_decode_cache(self, cache_ids, decode_idx, metadata):
        cache = self.input_manager.cache
        input_ids = cache.cached_input_ids[cache_ids]
        max_seq_lens = (cache.cached_seq_lens[cache_ids]).max()
        position_ids = cache.cached_position_id[cache_ids]
        input_lengths = cache.cached_seq_lens[cache_ids]
        block_idx = metadata.batch_block_tables[decode_idx, cache.used_block_idx[cache_ids]]
        slots = cache.all_slots[block_idx, cache.used_block_offset[cache_ids]]
        decode_result = (input_ids, max_seq_lens, position_ids, input_lengths, slots)
        return decode_result
    
    def build_sampling_param_mix(self, cache_ids: np.ndarray, metadata: InputMetadata, prefill_idx):
        cache = self.input_manager.cache
        start = sum(not is_prefill_tmp for is_prefill_tmp in metadata.batch_is_prefill)
        for i in prefill_idx:
            length = metadata.batch_seq_len[i]
            start_pos = metadata.split_start_position[i]
            cache.cached_all_input_ids[cache_ids[i], start_pos: start_pos + length] = \
                metadata.input_ids_list[start: start + length]
            start += length

        batch_sampling_param = metadata.batch_sampling_param[prefill_idx]
        metadata.batch_sampling_param[prefill_idx] = cache.preprocess_sampling_params(batch_sampling_param)
        for idx, cache_id in enumerate(cache_ids):
            if idx in prefill_idx:
                cache.cached_sampling_param[cache_id] = metadata.batch_sampling_param[idx]
        batch_sampling_param = cache.cached_sampling_param[cache_ids]
        # temperature, topk, topp, typicalp, do_sample, seeds, repetition, frequency, presence, watermark
        sampling_param = SamplingParam.from_numpy(
            temperature=batch_sampling_param['temperature'].astype(np.float32),
            top_k=batch_sampling_param['top_k'].astype(np.int_),
            top_p=batch_sampling_param['top_p'].astype(np.float32),
            do_sample=batch_sampling_param['do_sample'].astype(np.bool_),
            seed=batch_sampling_param['seed'],
            repetition_penalty=batch_sampling_param['repetition_penalty'].astype(np.float32),
            frequency_penalty=batch_sampling_param['frequency_penalty'].astype(np.float32),
            presence_penalty=batch_sampling_param['presence_penalty'].astype(np.float32),
            to_tensor=cache.to_tensor
        )
        return sampling_param
    
    def update_cache(self, cache_ids, new_tokens, metadata):
        need_append_block = False
        batch_cache = self.input_manager.cache
        batch_last_prompt = metadata.batch_last_prompt
        batch_is_prefill = metadata.batch_is_prefill
        for batch, cache_id in enumerate(cache_ids):
            if batch_is_prefill[batch] and (not batch_last_prompt[batch]):
                continue
            batch_cache.cached_input_ids[cache_id] = new_tokens[batch]
            batch_cache.cached_out_ids[cache_id][batch_cache.output_len_count[cache_id]] = new_tokens[batch]
            batch_cache.cached_all_input_ids[cache_id, batch_cache.cached_position_id[cache_id] + 1] = new_tokens[batch]
            batch_cache.output_len_count[cache_id] += 1
            batch_cache.cached_seq_lens[cache_id] += 1
            batch_cache.cpu_cached_seq_idx[cache_id] += 1
            batch_cache.cached_position_id[cache_id] += 1
            tmp_used_block_idx = batch_cache.cpu_cached_seq_idx[cache_id] // batch_cache.cache_config.max_block_size
            need_append_block = need_append_block or tmp_used_block_idx > batch_cache.used_block_idx[cache_id]
            batch_cache.used_block_idx[cache_id] = tmp_used_block_idx
            batch_cache.used_block_offset[cache_id] = \
                (batch_cache.cpu_cached_seq_idx[cache_id]) % batch_cache.cache_config.max_block_size
        return need_append_block
    
    def update_cache_after_prefill(self, metadata, cached_idx, input_lengths, last_position_ids):
        cache = self.input_manager.cache
        # 由于后处理参数的刷新只有第一次prefill切块才有，而postion和Input需要每个切块刷新，因此分阶段刷新
        prefill_idx = np.arange(metadata.mix_decode_bs, metadata.batch_size)
        start_pos_idx = np.where(metadata.split_start_position == 0)[0]

        prefill_first_time_idx = np.intersect1d(prefill_idx, start_pos_idx)
        prefill_other_time_idx = np.setdiff1d(prefill_idx, prefill_first_time_idx)

        # 先刷新首次prefill的部分
        if len(prefill_first_time_idx) != 0:
            batch_ignore_eos = metadata.batch_ignore_eos[prefill_first_time_idx] \
                if metadata.batch_ignore_eos is not None else None
            batch_include_stop = metadata.batch_include_stop[prefill_first_time_idx] \
                if metadata.batch_include_stop is not None else None
            batch_skip_special_tokens = metadata.batch_skip_special_tokens[prefill_first_time_idx] \
                if metadata.batch_skip_special_tokens is not None else None
            batch_stop_strings = [metadata.batch_stop_strings[j] for j in prefill_first_time_idx] \
                if metadata.batch_stop_strings is not None else None
            batch_stop_token_ids = [metadata.batch_stop_token_ids[j] for j in prefill_first_time_idx] \
                if metadata.batch_stop_token_ids is not None else None
            batch_user_request_ids = [metadata.user_request_ids[j] for j in prefill_first_time_idx] \
                if metadata.user_request_ids is not None else None
            batch_request_ids = metadata.batch_request_ids[prefill_first_time_idx] \
                if metadata.batch_request_ids is not None else None
            cache.update_cache_after_prefill(
                cached_idx[prefill_first_time_idx],
                last_position_ids[prefill_first_time_idx],
                input_lengths[prefill_first_time_idx],
                batch_ignore_eos=batch_ignore_eos,
                batch_include_stop=batch_include_stop,
                batch_skip_special_tokens=batch_skip_special_tokens,
                batch_stop_strings=batch_stop_strings,
                batch_stop_token_ids=batch_stop_token_ids,
                user_request_ids=batch_user_request_ids,
                batch_request_ids=batch_request_ids
            )
        
        # 再刷新非首次prefill的部分
        if len(prefill_other_time_idx) != 0:
            cache_ids = cached_idx[prefill_other_time_idx]
            cache.cached_position_id[cache_ids] = last_position_ids[prefill_other_time_idx]
            cache.cached_seq_lens[cache_ids] = input_lengths[prefill_other_time_idx]
            cache.cpu_cached_seq_idx[cache_ids] = input_lengths[prefill_other_time_idx] - 1
    

class SplitFusePreprocess:
    def __init__(self, input_manager, model_wrapper, cache_manager):
        self.input_manager = input_manager
        self.spf_cache = SplitFuseCacheEngine(input_manager)
        self.model_wrapper = model_wrapper
        self.cache_manager = cache_manager
        self.device = self.model_wrapper.device

    @timer.track_time('preprocess')
    def splitfuse_preprocess(self, input_metadata):
        cached_idx = self.input_manager.save_input_cache(input_metadata)
        is_prefill = input_metadata.is_prefill
        is_mix = input_metadata.is_mix
        model_inputs, sampling_param, sampling_data, q_len, request_ids = \
            self.splitfuse_concatenate(input_metadata, cached_idx, is_mix)
        attention_mask = self.make_attention_mask(model_inputs, is_prefill)
        res = (model_inputs, cached_idx, sampling_param, sampling_data, q_len, attention_mask, request_ids)
        return res
    
    def make_attention_mask(self, model_inputs, is_prefill):        
        atten_mask = None        
        if is_prefill:
            kv_dtype = self.cache_manager.dtype
            kv_device = self.model_wrapper.device
            atten_mask = self.model_wrapper.model_runner.model.attn_mask.get_attn_mask(model_inputs.max_seq_len,
                                                                                       kv_dtype, kv_device)
        return atten_mask

    def splitfuse_concatenate(self, metadata: InputMetadata, cached_idx, is_mix):
        is_prefill = metadata.is_prefill
        request_ids = None
        if is_prefill:
            model_inputs, sampling_param, sampling_data, q_len, request_ids = \
                self.concatenate_mix(metadata, cached_idx)            
        else:
            model_inputs, sampling_param, sampling_data, request_ids = \
                self.input_manager.concatenate(metadata, cached_idx, False)   
            q_len = np.ones(metadata.batch_size, dtype=np.int32)
        q_lens = q_len.tolist()
        res = (model_inputs, sampling_param, sampling_data, q_lens, request_ids)
        return res
    
    def concatenate_mix(self, metadata: InputMetadata, cached_idx: np.ndarray):
        sampling_param = None
        sampling_data = None  

        input_ids = np.array(metadata.input_ids_list, dtype=np.int64)
        position_ids = np.zeros(metadata.total_seq_num, dtype=np.int32)
        slots = np.zeros(metadata.total_seq_num, dtype=np.int32)
        input_lengths = np.zeros(metadata.batch_size, dtype=np.int32)
        last_position_ids = np.zeros(metadata.batch_size, dtype=np.int32)
        prefill_head_indices = np.arange(metadata.batch_size, dtype=np.int64)
        q_lens = np.ones(metadata.batch_size, dtype=np.int32)  # mix input

        # decode requests are ranged in the head of requests list        
        max_seq_lens_decode = 0
        decode_len = metadata.mix_decode_bs
        if decode_len > 0:
            decode_idx = list(range(metadata.mix_decode_bs))
            (input_ids_decode, max_seq_lens_decode, position_ids_decode,
             input_lengths_decode, slots_decode) = \
                self.spf_cache.get_mix_decode_cache(cached_idx[decode_idx], decode_idx, metadata)
            input_ids[:decode_len] = input_ids_decode
            position_ids[:decode_len] = position_ids_decode
            last_position_ids[:decode_len] = position_ids_decode
            input_lengths[:decode_len] = input_lengths_decode
            slots[:decode_len] = slots_decode
        max_seq_lens = max(metadata.max_seq_len, max_seq_lens_decode)

        # prefill requests are ranged in the tail of requests list
        cur_idx = decode_len
        for i in range(decode_len, metadata.batch_size):
            seq_len = metadata.batch_seq_len[i]
            start_idx = cur_idx
            end_idx = cur_idx + seq_len
            cur_idx += seq_len
            prefill_head_indices[i] = cur_idx - 1
            position_ids[start_idx:end_idx] = range(metadata.split_start_position[i], metadata.split_end_position[i])
            seq_len_total = metadata.split_end_position[i]
            last_position_ids[i] = seq_len_total - 1
            input_lengths[i] = seq_len_total
            slots[start_idx:end_idx] = \
                self.input_manager.all_slots[metadata.batch_block_tables[i]].reshape(-1)[
                metadata.split_start_position[i]:metadata.split_end_position[i]
                ]
            q_lens[i] = seq_len 
        prefill_idx = np.arange(metadata.mix_decode_bs, metadata.batch_size)
        self.spf_cache.update_cache_after_prefill(metadata, cached_idx, input_lengths, last_position_ids)
        if cached_idx is not None:
            req_ids = [self.input_manager.cache.cached_user_request_ids.get(cache_id) for cache_id in cached_idx]
        if metadata.has_sampling:
            max_out_len = self.input_manager.cache.output_len_count[cached_idx].max()
            sampling_param = self.spf_cache.build_sampling_param_mix(cached_idx, metadata, prefill_idx)
            sampling_data = self.input_manager.cache.build_sampling_data(sampling_param.penalty_meta.has_penalty,
                                                                         cache_ids=cached_idx,
                                                                         max_seq_len=max_seq_lens,
                                                                         max_out_len=max_out_len,
                                                                         is_prefill=True,
                                                                         request_ids=metadata.batch_request_ids)
            self.input_manager.sampling_cache.add_to_cache(request_ids=metadata.batch_request_ids,
                                                           sampling_param=sampling_param)

        model_inputs = ModelInput(input_ids=input_ids,
                                   position_ids=position_ids,
                                   block_tables=metadata.batch_block_tables,
                                   slots=slots,
                                   context_length=input_lengths,
                                   max_seq_len=max_seq_lens,
                                   prefill_head_indices=prefill_head_indices,
                                   is_prefill=True)
        res = (model_inputs, sampling_param, sampling_data, q_lens, req_ids)
        return res
