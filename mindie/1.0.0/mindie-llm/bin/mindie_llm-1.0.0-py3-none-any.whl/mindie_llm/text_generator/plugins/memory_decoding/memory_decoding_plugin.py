# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np

from .decoding_policy import DecodingPolicy, MemoryDecodingSampler
from ..plugin import Plugin
from ...utils.input_metadata import InputMetadata
from ....utils.tensor import op, tensor_backend
from ....utils.log.logging import logger
from ....utils.decorators.time_decorator import timer
from ....utils.env import ENV
from ....modeling.backend_type import BackendType

MAX_DECODING_LEN = 16
MIN_DECODING_LEN = 0


class MemoryDecodingPlugin(Plugin):
    def __init__(self, generator_backend, cache_manager, input_manager, **kwargs):
        super().__init__(generator_backend, cache_manager, input_manager)
        self.device = self.model_wrapper.device if ENV.framework_backend == BackendType.ATB else None
        self.decoding_length = kwargs.get('decoding_length', 16)
        if self.decoding_length > MAX_DECODING_LEN:
            logger.warning(f"decoding_length is larger than max value {MAX_DECODING_LEN}, run with max value!")
            self.decoding_length = MAX_DECODING_LEN
        if self.decoding_length < MIN_DECODING_LEN:
            logger.warning(f"decoding_length is smaller than min value {MIN_DECODING_LEN}, run with min value!")
            self.decoding_length = MIN_DECODING_LEN
        self.decoding_policy = DecodingPolicy(kwargs, self.input_manager, self.decoding_length,
                                              input_manager.cache_config.eos_token_id)
        self.memory_decoding_sampler = MemoryDecodingSampler()

    def set_atten_mask_ms(self, model_inputs, kv_dtype):
        if ENV.framework_backend == BackendType.MS:
            seqlen = int(model_inputs.max_seq_len)
            bias_cache = np.tril(np.ones((seqlen, seqlen), dtype=np.float32)).astype(np.bool_)
            bias_cache = ~bias_cache
            atten_mask = np.where(bias_cache, np.finfo(np.float32).min, np.zeros((seqlen, seqlen)))

        else:
            kv_device = self.model_wrapper.device
            atten_mask = self.model_wrapper.model_runner.model.attn_mask.get_attn_mask(model_inputs.max_seq_len,
                                                                                       kv_dtype, kv_device)
            if atten_mask[0][1] > 0:
                atten_mask = atten_mask * -10000.0
        return atten_mask

    def calc_decoding_info(self, input_metadata, model_inputs, cached_idx):
        decoding_ids = None
        decoding_masks = None
        q_lens = None
        if not input_metadata.is_prefill:
            model_inputs, decoding_ids, decoding_masks = self.decoding_policy.update_infer_input(model_inputs,
                                                                                                 cached_idx)
            q_lens = [len(x) for x in decoding_ids]
            kv_dtype = self.cache_manager.dtype
            atten_mask = self.set_atten_mask_ms(model_inputs, kv_dtype)
            req_mask = None
            start_row = 0
            bs = len(q_lens)
            for i in range(bs):
                start = int(model_inputs.context_length[i] - q_lens[i])
                end = int(model_inputs.context_length[i])

                if req_mask is None:
                    req_mask = atten_mask[start:end, :]
                else:
                    if ENV.framework_backend == BackendType.MS:
                        # mindspore 场景使用numpy效率更高
                        req_mask = np.concatenate((req_mask, atten_mask[start:end]), 0)
                    else:
                        req_mask = op.cat((req_mask, atten_mask[start:end]), 0)
                start_row += q_lens[i]
            decoding_masks = req_mask
        res = (model_inputs, decoding_ids, decoding_masks, q_lens)
        return res

    @timer.track_time('stop')
    def tkb_postprocess(self,
                        input_metadata,
                        next_tokens,
                        preprocess_outputs,
                        sampling):

        model_inputs, cached_idx, decoding_ids, _ = preprocess_outputs

        if input_metadata.is_prefill:
            next_tokens = next_tokens.reshape((-1, 1)).tolist()
            next_tokens_length = np.ones(len(model_inputs.context_length), dtype=np.int32)
        else:
            next_tokens_before_verify = next_tokens.tolist()
            next_tokens, next_tokens_length = self.decoding_policy.verify(
                next_tokens_before_verify, decoding_ids, cached_idx)

        need_append_block = self.decoding_policy.update_cache_speculative(cached_idx, next_tokens_length,
                                                                          next_tokens, sampling)
        token_indices = self.input_manager.cache.output_len_count[cached_idx]
        contains_eos, eos_np, filtered_indices_np, truncation_indices = (
            self.input_manager.filter_eos_request(input_metadata, cached_idx, next_tokens, self.sampler))
        if contains_eos:
            self.decoding_policy.filter_out_eos(eos_np, cached_idx)
        # 如果需要新增block 或者 有请求要退出, 则不能继续做decode
        stop_generate = need_append_block or contains_eos
        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices)
        return res_and_stop

    @timer.track_time('generate_token')
    def generate_token(self, input_metadata: InputMetadata):

        model_inputs, cached_idx, sampling_param, sampling_data, request_ids = self.preprocess(input_metadata)
        sampling = (sampling_param is not None and any(sampling_param.do_sample_meta.do_sample_array))
        if input_metadata.is_prefill:
            self.decoding_policy.add_prompt_to_cache(model_inputs, cached_idx)

        model_inputs, decoding_ids, decoding_masks, q_lens = self.calc_decoding_info(
            input_metadata, model_inputs, cached_idx)

        logits = self.generator_backend.forward(
            model_inputs,
            q_lens=q_lens,
            spec_mask=decoding_masks
        )
        
        next_tokens = None
        indices = sampling_param.penalty_meta.repetition_penalty is not None and \
            sampling_param.penalty_meta.repetition_penalty != 1.0

        if isinstance(indices, bool):
            repetition_penalty_enable = indices
        else:
            repetition_penalty_enable = any(indices)
        
        if sampling or repetition_penalty_enable:
            self.memory_decoding_sampler.sampling_param = sampling_param
            if q_lens is None:
                q_lens = [1] * logits.shape[0]
            self.memory_decoding_sampler.qlens = q_lens
            logits_new = tensor_backend.zeros((tensor_backend.shape(logits, 0),
                                            tensor_backend.shape(logits, 1) + 1),
                                            dtype=logits.dtype,
                                            device=tensor_backend.get_device(logits))
            logits_new[:, :-1] = logits
            if repetition_penalty_enable:
                logits_new = self.memory_decoding_sampler.do_repetition(logits_new, sampling_data)
            if sampling:
                next_tokens = self.memory_decoding_sampler.do_sampling(logits_new, q_lens, sampling_param)
            else:
                next_tokens = self.memory_decoding_sampler.do_sampling(logits_new, q_lens, sampling_param, True)
        else:
            next_tokens, _ = self.generator_backend.sample(logits, sampling_data, sampling_param)

        preprocess_outputs = (model_inputs, cached_idx, decoding_ids, decoding_masks)
        
        next_tokens, eos_np, stop_generate, truncation_indices, token_indices = self.tkb_postprocess(
            input_metadata, next_tokens, preprocess_outputs, sampling)
        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids)
        return res_and_stop