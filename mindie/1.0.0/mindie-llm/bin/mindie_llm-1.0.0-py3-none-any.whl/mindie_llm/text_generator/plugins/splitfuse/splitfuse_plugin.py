# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from .splitfuse_preprocess import SplitFusePreprocess
from ..plugin import Plugin
from ...utils.input_metadata import InputMetadata
from ....utils.decorators.time_decorator import timer


class SplitfusePlugin(Plugin):
    def __init__(self, generator_backend, cache_manager, input_manager, **kwargs):
        super().__init__(generator_backend, cache_manager, input_manager)
        self.splitfuse_preprocess = SplitFusePreprocess(self.input_manager, self.model_wrapper, self.cache_manager)

    @timer.track_time('generate_token')
    def generate_token(self, input_metadata: InputMetadata):
        model_inputs, cached_idx, sampling_param, sampling_data, q_len, attention_mask, request_ids = \
            self.splitfuse_preprocess.splitfuse_preprocess(input_metadata)
        logits = self.generator_backend.forward(model_inputs, q_lens=q_len, spec_mask=attention_mask)

        next_tokens, _ = self.generator_backend.sample(logits, sampling_data, sampling_param)
        eos_np, stop_generate, truncation_indices, token_indices, next_tokens = (
            self.splitfuse_postprocess(input_metadata, next_tokens, cached_idx))

        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids)
        return res_and_stop

    @timer.track_time('stop')
    def splitfuse_postprocess(self, input_metadata, next_tokens, cached_idx):
        need_append_block = self.splitfuse_preprocess.spf_cache.update_cache(cached_idx, next_tokens, input_metadata)
        token_indices = self.input_manager.cache.output_len_count[cached_idx]
        next_tokens = next_tokens.reshape((-1, 1)).tolist()
        contains_eos, eos_np, filtered_indices_np, truncation_indices = (
            self.input_manager.filter_eos_request(input_metadata, cached_idx, next_tokens, self.sampler))
        stop_generate = need_append_block or contains_eos
        res = (eos_np, stop_generate, truncation_indices, token_indices, next_tokens)
        return res
