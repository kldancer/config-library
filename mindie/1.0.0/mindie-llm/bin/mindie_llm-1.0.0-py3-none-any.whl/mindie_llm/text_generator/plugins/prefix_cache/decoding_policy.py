# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np

from ...utils.input_manager import ModelInput
from ...utils.input_metadata import InputMetadata


class DecodingPolicy:
    def __init__(self, input_manager):
        self.input_manager = input_manager
    
    def update_infer_input(self, input_data: ModelInput, metadata: InputMetadata):
        if not metadata.is_prefill or metadata.computed_blocks is None:
            return input_data
        # prefill阶段有缓存时，prefill的input tokens需要减去缓存部分
        new_total_seq_num = metadata.total_seq_num - np.sum(metadata.computed_blocks) * metadata.max_block_size
        new_input_ids = np.zeros(new_total_seq_num, dtype=np.int64)
        new_position_ids = np.zeros(new_total_seq_num, dtype=np.int32)
        new_slots = np.zeros(new_total_seq_num, dtype=np.int32)
        new_prefill_head_indices = np.zeros(metadata.batch_size, dtype=np.int64)
        q_lens = np.zeros(metadata.batch_size, dtype=np.int32)
        cumulative_seq_len = 0
        batch_end_idx = 0
        for i in range(metadata.batch_size):
            seq_len = metadata.batch_seq_len[i]
            cached_size = metadata.computed_blocks[i] * metadata.max_block_size
            seq_len -= cached_size  # 减去已有缓存的seq_len
            no_cache_blocks = metadata.batch_block_tables[i][metadata.computed_blocks[i]:]

            if seq_len <= 0:
                # 若有缓存导致seq_len<=0，少用一个block的缓存，保证输入大于0
                seq_len += metadata.max_block_size
                new_input_ids = np.append(new_input_ids, np.zeros(metadata.max_block_size, dtype=np.int64))
                new_position_ids = np.append(new_position_ids, np.zeros(metadata.max_block_size, dtype=np.int32))
                new_slots = np.append(new_slots, np.zeros(metadata.max_block_size, dtype=np.int32))
                no_cache_blocks = metadata.batch_block_tables[i][metadata.computed_blocks[i] - 1:]

            start_idx = cumulative_seq_len
            end_idx = cumulative_seq_len + seq_len

            batch_end_idx += metadata.batch_seq_len[i]
            new_input_ids[start_idx:end_idx] = input_data.input_ids[batch_end_idx - seq_len:batch_end_idx]
            new_position_ids[start_idx:end_idx] = input_data.position_ids[batch_end_idx - seq_len:batch_end_idx]
            new_slots[start_idx:end_idx] = self.input_manager.all_slots[no_cache_blocks].reshape(-1)[:seq_len]
            q_lens[i] = seq_len
            cumulative_seq_len += seq_len
            new_prefill_head_indices[i] = cumulative_seq_len - 1

        return ModelInput(input_ids=new_input_ids,
                          position_ids=new_position_ids,
                          block_tables=input_data.block_tables,
                          slots=new_slots,
                          context_length=input_data.context_length,
                          max_seq_len=input_data.max_seq_len,
                          prefill_head_indices=new_prefill_head_indices,
                          is_prefill=input_data.is_prefill,
                          query_length=q_lens)
