# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np

from ....utils.log.logging import logger
from ....utils.log.error_code import ErrorCode
from .la_statistics import RequestStatsList
from .la_random import MT19937
from ....utils.tensor import op, tensor, tensor_backend
from ....utils.decorators.time_decorator import timer
from ....utils.env import ENV
from ....modeling.backend_type import BackendType


class CacheEngine:
    def __init__(self, level, window, guess_set_size):
        self.level = level
        self.guess_set_size = guess_set_size
        self.window = window
        self.requests_idx_mapping = {}
        self.used_idx = []
        self.token_map = []
        self.past_tokens = []
        self.input_tail_tokens = []
        self.last_gen_tokens = []
        self.need_cal_kv = []
        self.input_len_list = []
    
    @staticmethod
    def set_token(prompt_tokens):
        return np.random.choice(prompt_tokens)

    def get_guess_token(self, req_id, lst_token):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        if self.past_tokens[map_id][self.level - 2] is None:
            return None
        if lst_token not in self.token_map[map_id]:
            return None
        return self.token_map[map_id][lst_token]
    
    def add_guess_tokens(self, map_id, lst_token, n_grams):
        tup = tuple(n_grams)
        if lst_token not in self.token_map[map_id]:
            self.token_map[map_id][lst_token] = []
        if tup in self.token_map[map_id][lst_token]:
            self.token_map[map_id][lst_token].remove(tup)
            self.token_map[map_id][lst_token].append(tup)
        elif len(self.token_map[map_id][lst_token]) < self.guess_set_size:
            self.token_map[map_id][lst_token].append(tup)
        else:
            self.token_map[map_id][lst_token] = self.token_map[map_id][lst_token][1:] + [tup]
        return
    
    def allocate_map_id(self, req_id):
        if req_id not in self.requests_idx_mapping:
            available_idx = np.flatnonzero(np.array(self.used_idx) == 0)
            if available_idx.shape[0] == 0:
                self.used_idx.append(1)
                self.token_map.append({})
                self.past_tokens.append(None)
                self.input_tail_tokens.append([])
                self.last_gen_tokens.append([])
                self.need_cal_kv.append(False)
                self.input_len_list.append(0)
                append_idx = len(self.used_idx) - 1
                self.requests_idx_mapping[req_id] = append_idx
            else:
                unused_idx = available_idx[0]
                self.used_idx[unused_idx] = 1
                self.requests_idx_mapping[req_id] = unused_idx
        map_id = self.requests_idx_mapping[req_id]
        return map_id
    
    def del_req_cache(self, req_id):
        if req_id not in self.requests_idx_mapping:
            return
        map_id = self.requests_idx_mapping[req_id]
        self.used_idx[map_id] = 0
        self.token_map[map_id] = {}
        self.past_tokens[map_id] = None
        self.input_tail_tokens[map_id] = []
        self.last_gen_tokens[map_id] = []
        self.need_cal_kv[map_id] = False
        self.input_len_list[map_id] = 0
        del self.requests_idx_mapping[req_id]
        return
    
    def initiate_past_tokens_with_prompt(self, map_id, prompt_tokens):
        self.past_tokens[map_id] = [[self.set_token(prompt_tokens) for _ in range(self.level + self.window - 3)]] +\
                                   [None for _ in range(self.level - 2)]
        return

    def fill_token_map_with_tails(self, map_id):
        tail_len = len(self.input_tail_tokens[map_id])
        start = 0
        while tail_len >= self.level:
            self.add_guess_tokens(map_id, self.input_tail_tokens[map_id][start],
                                 self.input_tail_tokens[map_id][start + 1:start + self.level])
            start += 1
            tail_len -= 1

        self.input_tail_tokens[map_id] = self.input_tail_tokens[map_id][-tail_len:]
        return

    def fill_input_tail_tokens(self, map_id, tail_tokens):
        self.last_gen_tokens[map_id] = tail_tokens
        self.input_tail_tokens[map_id].extend(tail_tokens)
        self.fill_token_map_with_tails(map_id)
        return
    
    def fill_pool_with_prompt(self, req_id):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        prompt_tokens = self.input_tail_tokens[map_id]
        self.initiate_past_tokens_with_prompt(map_id, prompt_tokens)
        self.fill_token_map_with_tails(map_id)
        return
    
    def save_tail_tokens(self, req_id, prompt_tokens):
        map_id = self.allocate_map_id(req_id)
        self.input_tail_tokens[map_id].extend(prompt_tokens)
        return
    
    def get_past_tokens(self, req_id):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        return self.past_tokens[map_id]
    
    def get_past_tokens_len(self, req_id):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        if not self.past_tokens[map_id]:
            return 0
        past_tokens_len = 0
        for i in range(len(self.past_tokens[map_id])):
            if self.past_tokens[map_id][i] is None:
                break
            past_tokens_len += len(self.past_tokens[map_id][i])
        return past_tokens_len
    
    def update_token_map(self, map_id, past_tokens, lst_token, new_results):
        for column_idx in range(self.window):
            if column_idx == 0:
                head = lst_token
            else:
                head = past_tokens[0][column_idx - 1]
            column = []
            for line in range(1, self.level - 1):
                column.append(past_tokens[line][column_idx])
            column.append(new_results[column_idx])
            self.add_guess_tokens(map_id, head, column)
        return
    
    def update_past_tokens(self, map_id, lst_token, new_results):
        past_tokens = self.past_tokens[map_id]
        if past_tokens[self.level - 2] is not None:
            
            self.update_token_map(map_id, past_tokens, lst_token, new_results)
            past_tokens[0] = past_tokens[1][1:]
            for line in range(1, self.level - 2):
                past_tokens[line] = past_tokens[line + 1][:]
            
            past_tokens[self.level - 2] = new_results
            return
        
        if past_tokens[1] is None:
            past_tokens[0] = past_tokens[0][1:]
            past_tokens[1] = new_results
            return
        
        line = 0
        while past_tokens[line] is not None:
            past_tokens[line] = past_tokens[line][1:]
            line += 1
        past_tokens[line] = new_results[1:]
        return
    
    def update_new_results(self, req_id, lst_token, new_results):
        map_id = self.requests_idx_mapping[req_id]
        self.update_past_tokens(map_id, lst_token, new_results)
        return
    
    def append_new_generated_pool(self, req_id, new_tokens):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        self.fill_input_tail_tokens(map_id, new_tokens[:])
    
    def get_gen_tokens(self, req_id):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        if self.need_cal_kv[map_id]:
            last_gen = self.last_gen_tokens[map_id]
        else:
            last_gen = self.last_gen_tokens[map_id][-1:]
        self.need_cal_kv[map_id] = False
        return last_gen

    def set_need_cal_kv(self, req_id):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        self.need_cal_kv[map_id] = True
    
    def set_input_len(self, req_id, input_len):
        if req_id not in self.requests_idx_mapping:
            message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
            raise RuntimeError(message)
        map_id = self.requests_idx_mapping[req_id]
        self.input_len_list[map_id] = input_len
    
    def get_input_lens(self, req_ids):
        input_len_list = []
        for req_id in req_ids:
            if req_id not in self.requests_idx_mapping:
                message = (f"req_id {req_id} not allocated! This reqeust not prefilled before decoding!")
                logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_ID_INVALID) 
                raise RuntimeError(message)
            map_id = self.requests_idx_mapping[req_id]
            input_len_list.append(self.input_len_list[map_id])
        return input_len_list

DEFAULT_MASK_START_SIZE = 200


def make_triangle_mask(mask, device):
    mask_cond = tensor_backend.tensor(np.arange(tensor_backend.shape(mask, -1)), device=device)
    return tensor_backend.masked_fill(mask, mask_cond < (mask_cond + 1).view(tensor_backend.shape(mask, -1), 1), 0)


def make_triangle_mask_numpy(mask):
    mask_cond = np.arange(mask.shape[-1])
    mask_cond = mask_cond < (mask_cond + 1).reshape(mask.shape[-1], 1)
    mask = np.where(mask_cond, 0, mask)
    return mask


def make_diagonal_mask(mask):
    return tensor_backend.fill_diagonal(mask, fill_value=0.0)


def make_single_mask(level, window, line, guess_set_size, device):
    dtype = tensor.half
    cur_window = level + window - 2 - line
    guess_len = level - 1
    if line > 1:
        cur_window += 1
    tgt_len = cur_window * line + guess_len * guess_set_size
    min_num = float(np.finfo(np.half).min)
    mask = tensor_backend.full((tgt_len, tgt_len), min_num, dtype=dtype, device=device)
    for guess_index in range(guess_set_size):
        start_guess = guess_len * guess_index + 1
        mask[start_guess:start_guess + guess_len, start_guess:start_guess + guess_len] = make_triangle_mask(
            mask[start_guess:start_guess + guess_len, start_guess:start_guess + guess_len], device)

    guess_total_len = guess_len * guess_set_size
    for line_index in range(line):
        start = guess_total_len + 1
        stop = guess_total_len + cur_window
        start_past = guess_total_len + cur_window * line_index + 1
        mask[start_past:start_past + cur_window - 1, start: stop] = make_triangle_mask(
            mask[start_past:start_past + cur_window - 1, start:stop], device)

    for line_index in range(1, line):
        start = guess_total_len + cur_window
        stop = guess_total_len + cur_window * (1 + line_index)
        mask[tgt_len - cur_window * line_index:, start: stop] = make_diagonal_mask(
            mask[tgt_len - cur_window * line_index:, start: stop])

    mask[:, 0] *= 0
    return mask


def make_default_mask(level, window, guess_set_size, device):
    default_mask = []

    guess_num = 0
    for line in range(level - 1):
        if line == level - 2:
            guess_num = guess_set_size
        single_mask = make_single_mask(level, window, line + 1, guess_num, device)
        single_mask_numpy = tensor_backend.numpy(tensor_backend.cpu(single_mask[:, :]))
        default_mask.append(single_mask_numpy)

    dtype = tensor.half
    min_num = float(np.finfo(np.float16).min)
    mask = tensor_backend.full((DEFAULT_MASK_START_SIZE, DEFAULT_MASK_START_SIZE), min_num, dtype=dtype,
                               device=device)
    mask_numpy = tensor_backend.numpy(tensor_backend.cpu(mask[:, :]))
    mask_numpy = make_triangle_mask_numpy(mask_numpy)
    default_mask.append(mask_numpy)

    return default_mask

MAX_LEVEL_VALUE = 16
MAX_WINDOW_VALUE = 16
MAX_GUESS_SET_SIZE = 16
MIN_LEVEL_VALUE = 2
MIN_WINDOW_VALUE = 1
MIN_GUESS_SET_SIZE = 1


class DecodingPolicy():
    def __init__(self, kwargs, input_manager, model_wrapper, log_enable, block_size):
        self.level = kwargs.get('level', 4)
        self.window = kwargs.get('window', 5)
        self.guess_set_size = kwargs.get("guess_set_size", 5)
        if self.level > MAX_LEVEL_VALUE:
            logger.warning(f"level value is larger than max value {MAX_LEVEL_VALUE}, run with max value!")
            self.level = MAX_LEVEL_VALUE
        
        if self.window > MAX_WINDOW_VALUE:
            logger.warning(f"window value is larger than max value {MAX_WINDOW_VALUE}, run with max value!")
            self.window = MAX_WINDOW_VALUE
        
        if self.guess_set_size > MAX_GUESS_SET_SIZE:
            logger.warning(f"guess_set_size is larger than max value {MAX_GUESS_SET_SIZE}, run with max value!")
            self.guess_set_size = MAX_GUESS_SET_SIZE
        
        if self.level < MIN_LEVEL_VALUE:
            message = (f"level cannot be less than 2, but now is {self.level},"
                       " please check the value of level in plugin_params!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_PARAM_VALUE_ERR) 
            raise ValueError(message)
        
        if self.window < MIN_WINDOW_VALUE:
            message = (f"window cannot be less than 1, but now is {self.window},"
                       " please check the value of window in plugin_params!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_PARAM_VALUE_ERR) 
            raise ValueError(message)
        
        if self.guess_set_size < MIN_GUESS_SET_SIZE:
            message = (f"window cannot be less than 1, but now is {self.guess_set_size},"
                       " please check the value of guess_set_size in plugin_params!")
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_PARAM_VALUE_ERR) 
            raise ValueError(message)
        
        self.la_cache = CacheEngine(self.level, self.window, self.guess_set_size)

        self.store_guess_tokens = []
        self.store_sampling_param = None
        self.store_sampling_data = None
        self.last_tokens = None
        self.block_size = block_size
        self.input_manager = input_manager
        self.model_wrapper = model_wrapper
        self.dtype = self.model_wrapper.model_runner.dtype
        self.device = self.model_wrapper.device if ENV.framework_backend == BackendType.ATB else None

        self.default_mask = make_default_mask(self.level, self.window, self.guess_set_size, self.device)
        self.eos_token_id = input_manager.cache_config.eos_token_id

        self.request_stats_list = None
        if log_enable:
            self.request_stats_list = RequestStatsList(self.level, self.window, self.guess_set_size)
        
        self.cu_seq_len = None
        self.mt = None
        self.mt_list = []
        self.position_list = None

    @staticmethod
    def generate_sampling_result(scores, tmp, k, p):
        max_k = np.max(k)
        max_k = max(max_k, 1)
        max_k = int(min(max_k, tensor_backend.shape(scores, -1)))

        values, indices = op.topk(scores, max_k)
        if tmp is not None:
            values = values / tmp
        
        total_token_num = scores.shape[0]
        k_matrix = tensor_backend.repeat(tensor.tensor(k), (max_k, 1)).T
        pos_matrix = tensor_backend.repeat(tensor.tensor(np.arange(max_k)), (total_token_num, 1))
        mask_fill = pos_matrix >= k_matrix
        mask_fill[:, 0] = False
        mask_fill = tensor_backend.to(mask_fill, tensor_backend.get_device(values))

        min_value = float(np.finfo(tensor_backend.numpy(tensor.tensor([0], dtype=scores.dtype)).dtype).min)

        values = values.masked_fill(mask_fill, min_value)
        values = op.flip(values, dims=[-1])
        indices = op.flip(indices, dims=[-1])

        cumulative_probs = tensor_backend.cumsum(tensor_backend.softmax(values, dim=-1), dim=-1)
        sorted_indices_to_remove = cumulative_probs <= tensor_backend.tensor(1 - p, device=tensor_backend.get_device(
            values)).unsqueeze(1)
        values = values.masked_fill(sorted_indices_to_remove, min_value)
        return values, indices

    @staticmethod
    def get_flatten_tensor(lst_position_id, past_token, prep_guess_token):
        flatten_input_token = []
        flatten_position = []

        if prep_guess_token is not None:
            for _, guess in enumerate(prep_guess_token):
                flatten_input_token.extend(guess)
                flatten_position.extend(
                    list(range(lst_position_id + 1, lst_position_id + 1 + len(guess))))

        for line, past_token_line in enumerate(past_token):
            if past_token_line is None:
                break
            offset = max(line, 1)
            flatten_position.extend(list(range(lst_position_id + offset,
                                               lst_position_id + offset + len(past_token_line))))
            flatten_input_token.extend(past_token_line)
        
        return flatten_input_token, flatten_position

    @staticmethod
    def count_extend_len(batch_size, guess_tokens, past_tokens):
        sum_extend_len = 0
        max_extend_len = 0
        for batch in range(batch_size):
            this_extend_len = 0
            if guess_tokens is not None and guess_tokens[batch] is not None:
                guess_num = len(guess_tokens[batch])
                for guess_index in range(guess_num):
                    this_extend_len += len(guess_tokens[batch][guess_index])
            if past_tokens[batch] is not None:
                for _, past_token_line in enumerate(past_tokens[batch]):
                    if past_token_line is None:
                        break
                    this_extend_len += len(past_token_line)
            sum_extend_len += this_extend_len
            max_extend_len = max(max_extend_len, this_extend_len)
        return sum_extend_len, max_extend_len

    @staticmethod
    def get_last_gen_size(batch_size, last_gen_tokens):
        gen_size = 0
        for batch in range(batch_size):
            gen_size += len(last_gen_tokens[batch])
        return gen_size

    @staticmethod
    def do_repetition_penalty_batch(input_ids, scores, penalty):
        if input_ids is None:
            return scores
        non_zero_penalty_num = op.nonzero(penalty).shape[0]
        if non_zero_penalty_num < penalty.numel():
            message = ("repetition_penalty should not be 0! Please check repetition value in request.")
            logger.error(message, ErrorCode.TEXT_GENERATOR_REQ_PENALTY_ZERO_DIV_ERR)
            raise ZeroDivisionError(message)
        score = tensor_backend.gather(scores, input_ids, -1)
        score = op.where(score < 0, score * penalty, score / penalty)
        score = score.type(scores.dtype)
        scores = tensor_backend.scatter(scores, -1, input_ids, score)
        return scores
    
    @staticmethod
    def need_do_repetition_penalty(repetition_penaltys):
        if repetition_penaltys is None:
            return False

        default_penaltys = tensor_backend.ones(repetition_penaltys.shape,
                                               device=tensor_backend.get_device(repetition_penaltys),
                                               dtype=repetition_penaltys.dtype)

        return not tensor_backend.equal(repetition_penaltys, default_penaltys)

    def set_random_seed(self, sample_param):
        origin_seed = -1
        new_seed = np.int32(1)
        if sample_param is not None and sample_param.seed_meta is not None:
            new_seed = max(sample_param.seed_meta.seed_array)
        if self.mt is not None:
            origin_seed = self.mt.seed
        if origin_seed == new_seed:
            return
        new_seed = new_seed.astype(np.int32)
        new_seed = new_seed % np.iinfo(np.int32).max
        np.random.seed(new_seed)
        self.mt = MT19937(new_seed)
        self.mt_list = []
        return

    def get_random_value(self, position):
        cur_len = len(self.mt_list)
        need_len = position + self.level
        if cur_len < need_len:
            for _ in range(need_len - cur_len):
                prob = self.mt.extract_number() * 1.0 / 0xFFFFFFFF
                prob = round(prob, 6)
                self.mt_list.append(prob)
        return self.mt_list[position:position + self.level]

    def multinomial_batch(self, prob_matrix, indices, next_guess_logits_num_per_batch):
        random_values = []
        for batch, batch_logits_num in enumerate(next_guess_logits_num_per_batch):
            position = self.position_list[batch]
            batch_rand_value = []
            sampling_prob_list = self.get_random_value(position)
            batch_rand_value.append(sampling_prob_list[0])
            draft_num = int((batch_logits_num - 1) / (self.level - 1))
            for _ in range(draft_num):
                batch_rand_value.extend(sampling_prob_list[1:])
            random_values.extend(batch_rand_value)
        
        new_indices, bridge = op.sort(indices, descending=False)
        prob_matrix = tensor_backend.gather(prob_matrix, bridge, -1)
        cdf_matrix = tensor_backend.cumsum(prob_matrix, dim=-1)
        sample_probs = np.expand_dims(np.array(random_values), axis=-1)
        selected_ids = op.searchsorted(cdf_matrix, tensor_backend.to(tensor.tensor(sample_probs),
                                                                     tensor_backend.get_device(prob_matrix)))

        idx_tmp = tensor_backend.where(selected_ids == cdf_matrix.shape[1])[0]
        if idx_tmp.shape[0] != 0:
            if ENV.framework_backend == BackendType.MS:
                idx_tmp = idx_tmp.tolist()
            selected_ids[idx_tmp] = op.argmax(cdf_matrix[idx_tmp], dim=-1).unsqueeze(1)
        selected_token_ids = tensor_backend.gather(new_indices, selected_ids, -1)
        return selected_token_ids

    def handle_input(self, raw_model_inputs, input_metadata, sampling_param):
        attention_mask = None
        if input_metadata.is_prefill:
            if self.request_stats_list is not None:
                for batch in range(input_metadata.batch_size):
                    self.request_stats_list.new_request_in(
                        input_metadata.batch_seq_len[batch], input_metadata.batch_request_ids[batch])
            
            self.set_random_seed(sampling_param)
            self.cu_seq_len = np.zeros(input_metadata.batch_size + 1, dtype=np.int64)
            self.cu_seq_len[1:] = raw_model_inputs.prefill_head_indices + 1
            start = 0
            for i, length in enumerate(input_metadata.batch_seq_len):
                input_ids = input_metadata.input_ids_list[start:start + length]
                start += length
                self.la_cache.save_tail_tokens(input_metadata.batch_request_ids[i], input_ids)
                self.la_cache.set_input_len(input_metadata.batch_request_ids[i], length)
            model_inputs = raw_model_inputs
            self.position_list = [0] * input_metadata.batch_size
        else:
            self.position_list = raw_model_inputs.position_ids.tolist()
            input_len_list = self.la_cache.get_input_lens(input_metadata.batch_request_ids)
            for batch, position in enumerate(self.position_list):
                self.position_list[batch] = position + 1 - input_len_list[batch]
            model_inputs, attention_mask = self.la_preprocess(raw_model_inputs, input_metadata)
        q_len = (self.cu_seq_len[1:] - self.cu_seq_len[:-1]).tolist()
        return model_inputs, q_len, attention_mask

    def make_attention_mask(self, input_len, last_gen_len, is_prefill, past_token, prep_guess_token):
        dtype = np.float16
        cur_window = len(past_token[0]) if past_token is not None else 0
        if is_prefill:
            tgt_len = input_len + cur_window
            past_length = input_len - last_gen_len
            triangle_mask = self.default_mask[-1]
            tri_len = triangle_mask.shape[0]
            if tri_len < tgt_len:
                self.default_mask[-1] = np.array([])
                add_default_size_time = ((tgt_len - tri_len) // DEFAULT_MASK_START_SIZE) + 1
                triangle_mask = np.full((tri_len + DEFAULT_MASK_START_SIZE * add_default_size_time,
                                            tri_len + DEFAULT_MASK_START_SIZE * add_default_size_time),
                                            np.finfo(dtype).min, dtype=dtype)
                triangle_mask = make_triangle_mask_numpy(triangle_mask)
                self.default_mask[-1] = triangle_mask
            mask = triangle_mask[past_length:tgt_len, :tgt_len].copy()
            return mask
        
        cur_window += 1
        line = 0
        if past_token is not None:
            while line < len(past_token):
                if past_token[line] is None:
                    break
                line += 1
        
        num_guess = 0 if prep_guess_token is None else len(prep_guess_token)
        guess_len = self.la_cache.level - 1
        tgt_len = cur_window * line + num_guess * guess_len - 1

        past_length = input_len - last_gen_len
        mask_length = input_len + tgt_len if tgt_len >= 0 else input_len
        triangle_mask = self.default_mask[-1]
        if triangle_mask.shape[0] < mask_length:
            self.default_mask[-1] = np.array([])
            add_default_size_time = ((mask_length - triangle_mask.shape[0]) // DEFAULT_MASK_START_SIZE) + 1
            triangle_mask = np.full((triangle_mask.shape[0] + DEFAULT_MASK_START_SIZE * add_default_size_time,
                                        triangle_mask.shape[0] + DEFAULT_MASK_START_SIZE * add_default_size_time),
                                        np.finfo(dtype).min,
                                        dtype=dtype)
            triangle_mask = make_triangle_mask_numpy(triangle_mask)
            self.default_mask[-1] = triangle_mask
        mask = triangle_mask[past_length:mask_length, :mask_length].copy()
        if tgt_len >= 0:
            default_mask = self.default_mask[line - 1]
            mask[last_gen_len:, mask_length - tgt_len:mask_length] = default_mask[-tgt_len:, -tgt_len:]
        return mask

    def insert_slots(self, start, last_gen_len, extend_seq_len, block_tables):
        block_size = self.block_size
        remain = last_gen_len + extend_seq_len
        new_slots = np.empty(last_gen_len + extend_seq_len, dtype=np.int32)
        block_idx = start // block_size
        slot_start = start % block_size
        pos_now = 0

        while remain > 0:
            block_rest = block_size - slot_start
            next_length = min(block_rest, remain)
            block_num = block_tables[block_idx].item()
            new_slots[pos_now:pos_now + next_length] = (
                self.input_manager.all_slots[block_num][slot_start:slot_start + next_length].tolist())
            slot_start += next_length
            block_idx += slot_start // block_size
            slot_start = slot_start % block_size
            remain -= next_length
            pos_now += next_length

        return new_slots

    def update_decode_model_inputs(self, model_inputs, past_tokens, prep_guess_tokens, last_gen_tokens):
        batch_size = model_inputs.context_length.shape[0]
        sum_extend_len, max_entend_len = self.count_extend_len(batch_size, prep_guess_tokens, past_tokens)
        input_size = self.get_last_gen_size(batch_size, last_gen_tokens)

        input_ids_tensor = np.zeros(sum_extend_len + input_size, dtype=np.int64)
        position_ids_tensor = np.zeros(sum_extend_len + input_size, dtype=np.int64)
        is_prefill = np.zeros(batch_size + 1, dtype=np.int32)
        max_seq_len = model_inputs.max_seq_len
        total_seq_len = 0
        slots_tensor = np.zeros(sum_extend_len + input_size, dtype=np.int32)

        dtype = np.float16
        batch_mask = np.full((sum_extend_len + input_size, max_entend_len + max_seq_len),
                             np.finfo(dtype).min, dtype=dtype)
        mask_pos = 0
        last_tokens = np.zeros(batch_size, dtype=np.int32)
        
        for batch in range(batch_size):
            past_token = past_tokens[batch]
            prep_guess_token = prep_guess_tokens[batch]
            lst_position_id = model_inputs.position_ids[batch].item()
            last_tokens[batch] = model_inputs.input_ids[batch].item()
            last_gen_token = last_gen_tokens[batch]
            last_gen_len = len(last_gen_token)

            flatten_input_tensor, flatten_position_tensor = (
                self.get_flatten_tensor(lst_position_id, past_token, prep_guess_token))
            
            seq_len = model_inputs.context_length[batch].item()
            extend_seq_len = len(flatten_input_tensor)
            new_seq_len = seq_len + extend_seq_len

            new_slot_tensor = self.insert_slots(seq_len - last_gen_len, last_gen_len, extend_seq_len,
                                                           model_inputs.block_tables[batch])

            input_ids_tensor[total_seq_len:total_seq_len + last_gen_len] = last_gen_token
            gen_position_id = list(range(lst_position_id - last_gen_len + 1, lst_position_id + 1))
            position_ids_tensor[total_seq_len:total_seq_len + last_gen_len] = gen_position_id
            
            slots_tensor[total_seq_len:total_seq_len + last_gen_len + extend_seq_len] = new_slot_tensor
            total_seq_len += last_gen_len

            if extend_seq_len > 0:
                input_ids_tensor[total_seq_len:total_seq_len + extend_seq_len] = flatten_input_tensor
                position_ids_tensor[total_seq_len:total_seq_len + extend_seq_len] = flatten_position_tensor

            model_inputs.context_length[batch] = new_seq_len
            max_seq_len = max(max_seq_len, new_seq_len)
            total_seq_len += extend_seq_len
            is_prefill[batch + 1] = total_seq_len

            if_la_first_round = False
            if past_token is not None:
                if_la_first_round = past_token[1] is None
            attention_mask = self.make_attention_mask(seq_len, last_gen_len, if_la_first_round, past_token,
                                                      prep_guess_token)
            batch_mask[mask_pos:mask_pos + attention_mask.shape[0], :attention_mask.shape[1]] = attention_mask
            mask_pos += attention_mask.shape[0]
        self.last_tokens = last_tokens
        model_inputs.input_ids = input_ids_tensor[:total_seq_len]
        model_inputs.position_ids = position_ids_tensor[:total_seq_len]
        model_inputs.slots = slots_tensor[:total_seq_len]
        model_inputs.max_seq_len = max_seq_len
        self.cu_seq_len = tensor_backend.tensor(is_prefill, device=self.device)
        batch_mask = tensor_backend.tensor(batch_mask, dtype=self.dtype, device=self.device)
        return model_inputs, batch_mask[:mask_pos, :max_seq_len]

    def la_preprocess(self, model_inputs, meta_data):
        past_tokens = []
        prep_guess_tokens = []
        last_gen_tokens = []
        for batch in range(meta_data.batch_size):
            req_id = meta_data.batch_request_ids[batch]
            batch_past_token = self.la_cache.get_past_tokens(req_id)
            if batch_past_token is None:
                self.la_cache.fill_pool_with_prompt(req_id)
                prep_guess_tokens.append(None)
                last_gen_tokens.append([model_inputs.input_ids[batch].item()])
                batch_past_token = self.la_cache.get_past_tokens(req_id)
            else:
                lst_token = model_inputs.input_ids[batch].item()
                prep_guess_tokens.append(self.la_cache.get_guess_token(req_id, lst_token))
                last_gen_tokens.append(self.la_cache.get_gen_tokens(req_id))
            past_tokens.append(batch_past_token)
        self.store_guess_tokens = prep_guess_tokens
        return self.update_decode_model_inputs(model_inputs, past_tokens, prep_guess_tokens, last_gen_tokens)

    def stop_criteria(self, new_tokens, output_space_left):
        new_token_len = len(new_tokens)
        accept_guess_len = new_token_len - 1
        for index in range(new_token_len):
            if isinstance(self.eos_token_id, int):
                if new_tokens[index] == self.eos_token_id:
                    new_token_len = index + 1
                    break
            elif isinstance(self.eos_token_id, list) and self.eos_token_id:
                if new_tokens[index] in self.eos_token_id:
                    new_token_len = index + 1
                    break

        if output_space_left < new_token_len:
            new_token_len = output_space_left
        
        if new_token_len <= accept_guess_len:
            accept_guess_len = new_token_len
        return new_tokens[:new_token_len], accept_guess_len
    
    def handle_eos(self, req_id):
        self.la_cache.del_req_cache(req_id)
        self.store_guess_tokens = []
        self.last_tokens = None
        return
    
    def update_input_cache(self, cache_ids, new_tokens):
        need_append_block = False
        batch_cache = self.input_manager.cache
        for batch, cache_id in enumerate(cache_ids):
            lst_token = new_tokens[batch][-1]
            token_len = len(new_tokens[batch])
            position = batch_cache.cached_position_id[cache_id] + 1
            batch_cache.cached_all_input_ids[cache_id][position:position + token_len] = new_tokens[batch]
            batch_cache.cached_out_ids[cache_id, batch_cache.output_len_count[cache_id]:
                                       batch_cache.output_len_count[cache_id] + token_len] = new_tokens[batch]
            batch_cache.output_len_count[cache_id] += token_len
            batch_cache.cached_seq_lens[cache_id] += token_len
            batch_cache.cpu_cached_seq_idx[cache_id] += token_len
            batch_cache.cached_position_id[cache_id] += token_len
            batch_cache.cached_input_ids[cache_id] = lst_token
            tmp_used_block_idx = batch_cache.cpu_cached_seq_idx[cache_id] // batch_cache.cache_config.max_block_size
            need_append_block = need_append_block or tmp_used_block_idx > batch_cache.used_block_idx[cache_id]
            batch_cache.used_block_idx[cache_id] = tmp_used_block_idx
            batch_cache.used_block_offset[cache_id] = (
                batch_cache.cpu_cached_seq_idx[cache_id] % batch_cache.cache_config.max_block_size)
        return need_append_block
    
    def get_input_ids_pad(self, metadata):
        total_logits_nums = metadata.batch_size
        logits_num_per_batch = [1] * metadata.batch_size
        guess_tokens_num_per_batch = [0] * metadata.batch_size
        input_ids_pad = None
        if self.store_guess_tokens:
            for batch in range(metadata.batch_size):
                guess_tokens = self.store_guess_tokens[batch]
                if guess_tokens is None:
                    continue
                guess_token_num = 0
                for guess_token in guess_tokens:
                    guess_token_num += len(guess_token)
                guess_tokens_num_per_batch[batch] = guess_token_num
                total_logits_nums += guess_token_num
                logits_num_per_batch[batch] += guess_token_num
        if self.store_sampling_data.all_input_ids is None:
            return input_ids_pad
        input_ids_len = tensor_backend.shape(self.store_sampling_data.all_input_ids, -1)

        input_ids_pad = np.zeros((total_logits_nums, input_ids_len + (self.level - 1)), dtype=np.int64)
        index = 0
        for batch in range(metadata.batch_size):
            input_ids = np.expand_dims(tensor_backend.numpy(tensor_backend.cpu(
                self.store_sampling_data.all_input_ids[batch])), axis=0)
            input_ids_pad[index:index + logits_num_per_batch[batch], :input_ids_len] = \
                np.repeat(input_ids, logits_num_per_batch[batch], axis=0)
            input_ids_pad[index:index + logits_num_per_batch[batch], input_ids_len:] = input_ids[0][0]
            guess_index = index + 1
            index += logits_num_per_batch[batch]
            if self.store_guess_tokens:
                guess_tokens = self.store_guess_tokens[batch]
                if guess_tokens is None:
                    continue
                for guess_set in guess_tokens:
                    for idx, _ in enumerate(guess_set):
                        input_ids_pad[guess_index, input_ids_len:input_ids_len + idx + 1] = \
                            np.array(list(guess_set[:idx + 1]))
                        guess_index += 1

        input_ids_pad = tensor_backend.to(tensor.tensor(input_ids_pad), self.device)
        return input_ids_pad
    
    def get_past_logits(self, model_outputs, req_id, start_pos):
        past_logits = None

        past_token = self.la_cache.get_past_tokens(req_id)
        if past_token is not None:
            past_token_out_len = len(past_token[0]) if past_token[1] is None else len(past_token[0]) + 1
            past_logits = model_outputs[start_pos - past_token_out_len:start_pos]
        
        return past_logits

    def do_repetition_penalty_by_batch(self, metadata, model_outputs, sampling_param, sampling_data):
        next_guess_logits_num_per_batch = []
        inp_logits_batch = []
        repetition_penaltys = None
        next_guess_logits = None

        model_outputs_new = tensor_backend.zeros((tensor_backend.shape(model_outputs, 0),
                                                  tensor_backend.shape(model_outputs, 1) + 1),
                                                 dtype=model_outputs.dtype,
                                                 device=tensor_backend.get_device(model_outputs))
        model_outputs_new[:, :-1] = model_outputs
        if sampling_param is not None:
            repetition_penaltys = sampling_param.penalty_meta.repetition_penalty
        
        need_penalty = self.need_do_repetition_penalty(repetition_penaltys)
        
        if metadata.is_prefill:
            next_guess_logits = model_outputs_new
            if need_penalty:
                next_guess_logits = self.do_repetition_penalty_batch(sampling_data.all_input_ids,
                                                                     model_outputs_new, repetition_penaltys)
            return next_guess_logits, [1] * metadata.batch_size, inp_logits_batch
        
        ends = self.cu_seq_len[1:].tolist()
        for batch in range(metadata.batch_size):
            guess_token = self.store_guess_tokens[batch] if self.store_guess_tokens else None
            guess_token_num = 0
            if guess_token is not None:
                guess_token_num = len(guess_token) * len(guess_token[0])
            next_guess_logits_num_per_batch.append(1 + guess_token_num)

            req_id = metadata.batch_request_ids[batch]
            inp_logits_batch.append(self.get_past_logits(model_outputs_new, req_id, ends[batch]))
        
        total_logits_nums = sum(next_guess_logits_num_per_batch)
        next_guess_logits = tensor_backend.zeros((total_logits_nums, tensor_backend.shape(model_outputs_new, -1)),
                                                 dtype=model_outputs_new.dtype,
                                                 device=tensor_backend.get_device(model_outputs_new))
        
        logits_index = 0
        for batch in range(metadata.batch_size):
            req_id = metadata.batch_request_ids[batch]
            guess_token_num = next_guess_logits_num_per_batch[batch] - 1
            past_token_len = self.la_cache.get_past_tokens_len(req_id)
            next_guess_logits[logits_index:logits_index + 1 + guess_token_num] = \
                model_outputs_new[ends[batch] - past_token_len - guess_token_num - 1:ends[batch] - past_token_len]
            logits_index += (1 + guess_token_num)

        if need_penalty:
            input_ids_pad = self.get_input_ids_pad(metadata)
            draft_repetition_penaltys = tensor_backend.zeros((total_logits_nums, 1), dtype=repetition_penaltys.dtype,
                                                             device=tensor_backend.get_device(repetition_penaltys))
            logits_index = 0
            for batch in range(metadata.batch_size):
                batch_token_num = next_guess_logits_num_per_batch[batch]
                draft_repetition_penaltys[logits_index:logits_index + batch_token_num] = repetition_penaltys[batch]
                logits_index += batch_token_num
            next_guess_logits = self.do_repetition_penalty_batch(input_ids_pad, next_guess_logits,
                                                                 draft_repetition_penaltys)
            
        return next_guess_logits, next_guess_logits_num_per_batch, inp_logits_batch
    
    def la_verify_greedy_one_batch(self, verify_guess_tokens, next_guess_tokens):
        next_tokens = next_guess_tokens[0]
        need_cal_kv = False
        if verify_guess_tokens is None:
            return [next_tokens], need_cal_kv
        
        first_guess = next_tokens
        guess_size = self.level - 1
        hits = [first_guess] + [0] * guess_size
        max_hit = 0

        guess_results = next_guess_tokens[1:]
        for eg, guess_tokens in enumerate(verify_guess_tokens):
            egx = eg * guess_size
            correct = [first_guess] + guess_results[egx:egx + guess_size]
            my_guess = guess_tokens
            gg = 0
            while gg < len(my_guess):
                if my_guess[gg] != correct[gg]:
                    break
                gg += 1
            if gg > max_hit:
                max_hit = gg
                hits[:max_hit + 1] = correct[:max_hit + 1]
                if eg > 0:
                    need_cal_kv = True
        return hits[:max_hit + 1], need_cal_kv
    
    def la_verify_sample_one_batch(self, verify_guess_tokens, batch_next_tokens):
        next_guess = batch_next_tokens[0]
        guess_results = batch_next_tokens[1:]
        guess_size = self.level - 1
        hits = [next_guess]
        need_cal_kv = False

        if verify_guess_tokens is None:
            return hits, need_cal_kv
        guess_idx_list = list(range(len(verify_guess_tokens)))
        next_guess_list = []

        for idx_in_ngram in range(guess_size):
            for g_idx in guess_idx_list:
                draft_guess = verify_guess_tokens[g_idx][idx_in_ngram]
                if draft_guess == next_guess:
                    next_guess_list.append(g_idx)
            if len(next_guess_list) == 0:
                break
            guess_idx_list = next_guess_list
            next_guess_list = []
            next_idx = guess_idx_list[0]
            if next_idx > 0:
                need_cal_kv = True
            next_guess = guess_results[next_idx * guess_size + idx_in_ngram]
            hits.append(next_guess)
        return hits, need_cal_kv
    
    def la_verify_sample_by_batch(self, metadata, next_guess_logits, next_guess_logits_num_per_batch):
        temperatures = self.store_sampling_param.temperature
        top_ks = self.store_sampling_param.top_k_meta.top_k_array
        top_ps = self.store_sampling_param.top_p_meta.top_p_array

        total_logits_nums = sum(next_guess_logits_num_per_batch)

        draft_temperatures = None
        if temperatures is not None:
            draft_temperatures = tensor_backend.ones((total_logits_nums, 1), dtype=next_guess_logits.dtype,
                                                     device=tensor_backend.get_device(next_guess_logits))
        draft_ks = np.zeros(total_logits_nums)
        draft_ps = np.zeros(total_logits_nums)
        logits_index = 0
        for batch in range(metadata.batch_size):
            batch_token_num = next_guess_logits_num_per_batch[batch]
            if temperatures is not None:
                if temperatures[batch] == 0:
                    message = ("temperature cannot be `0`! Please check temperature value in request.")
                    logger.error(message, ErrorCode.TEXT_GENERATOR_TEMP_ZERO_DIV_ERR)
                    raise ZeroDivisionError(message)
                draft_temperatures[logits_index:logits_index + batch_token_num] = temperatures[batch]
            draft_ks[logits_index:logits_index + batch_token_num] = top_ks[batch]
            draft_ps[logits_index:logits_index + batch_token_num] = top_ps[batch]
            logits_index += batch_token_num

        next_tokens_batch_prepare = []

        scores, indices = self.generate_sampling_result(next_guess_logits, draft_temperatures, draft_ks, draft_ps)
        probs = tensor_backend.softmax(scores, dim=-1)
        indices = tensor_backend.cpu(indices)
        probs = tensor_backend.cpu(probs).to(tensor.float32)

        all_next_tokens_prepare = self.multinomial_batch(probs, indices, next_guess_logits_num_per_batch)
        
        if metadata.is_prefill:
            return all_next_tokens_prepare.tolist()
        else:
            all_next_tokens_prepare = all_next_tokens_prepare.squeeze(1).tolist()
            prob_index = 0

            for batch in range(metadata.batch_size):
                verify_guess_tokens = self.store_guess_tokens[batch] if not metadata.is_prefill else None
                next_logits_num = next_guess_logits_num_per_batch[batch]
                batch_next_tokens = all_next_tokens_prepare[prob_index:prob_index + next_logits_num]
                prob_index += next_logits_num

                hits, need_cal_kv = self.la_verify_sample_one_batch(verify_guess_tokens, batch_next_tokens)
                if need_cal_kv:
                    req_id = metadata.batch_request_ids[batch]
                    self.la_cache.set_need_cal_kv(req_id)
                next_tokens_batch_prepare.append(hits)

        return next_tokens_batch_prepare
    
    def la_update(self, metadata, cached_idx, next_tokens_batch_prepare, inp_tokens_batch):
        next_tokens_batch = []
        output_token_len = self.input_manager.cache.output_len_count[cached_idx]
        output_space_left = metadata.batch_max_output_lens - output_token_len
        for batch in range(metadata.batch_size):
            verify_guess_tokens = self.store_guess_tokens[batch] if not metadata.is_prefill else None
            req_id = metadata.batch_request_ids[batch]
            cut_new_results, accept_guess_len = self.stop_criteria(next_tokens_batch_prepare[batch],
                                                                  output_space_left[batch])
            guess_size = self.level - 1

            if not metadata.is_prefill:
                lst_token = self.last_tokens[batch]
                if inp_tokens_batch:
                    self.la_cache.update_new_results(req_id, lst_token, inp_tokens_batch[batch])
                self.la_cache.append_new_generated_pool(req_id, cut_new_results)
            if self.request_stats_list is not None:
                total_guess_len = 0
                if verify_guess_tokens is not None:
                    total_guess_len = len(verify_guess_tokens) * guess_size
                self.request_stats_list.update_request_stats(accept_guess_len, len(cut_new_results),
                                                             total_guess_len, req_id)
            
            next_tokens_batch.append(cut_new_results)
            if metadata.is_prefill:
                self.la_cache.save_tail_tokens(req_id, cut_new_results)
        return next_tokens_batch

    @timer.track_time('postprocess')
    def la_postprocess_multi_batch(self, metadata, model_outputs, sampling_param, sampling_data, cached_idx):
        self.store_sampling_param = sampling_param
        self.store_sampling_data = sampling_data
        next_tokens_batch_prepare = []
        next_guess_logits, next_guess_logits_num_per_batch, inp_logits_batch = (
            self.do_repetition_penalty_by_batch(metadata, model_outputs, sampling_param, sampling_data))
    
        inp_tokens_batch = []
        if inp_logits_batch:
            for inp_logits in inp_logits_batch:
                inp_tokens_batch.append(op.argmax(inp_logits, dim=-1).tolist())

        do_sample = (sampling_param is not None and any(sampling_param.do_sample_meta.do_sample_array))

        if not do_sample:
            next_guess_tokens = tensor_backend.cpu(op.argmax(next_guess_logits, dim=-1)).tolist()

            start_pos = 0
            for batch in range(metadata.batch_size):
                end = start_pos + next_guess_logits_num_per_batch[batch]
                next_guess_by_batch = next_guess_tokens[start_pos:end]
                start_pos += next_guess_logits_num_per_batch[batch]
                if metadata.is_prefill:
                    next_tokens_batch_prepare.append(next_guess_by_batch)
                    continue
                
                verify_guess_tokens = self.store_guess_tokens[batch] if not metadata.is_prefill else None
                if verify_guess_tokens is None:
                    next_tokens_batch_prepare.append(next_guess_by_batch)
                    continue
                
                new_results, need_cal_kv = self.la_verify_greedy_one_batch(verify_guess_tokens, next_guess_by_batch)
                if need_cal_kv:
                    req_id = metadata.batch_request_ids[batch]
                    self.la_cache.set_need_cal_kv(req_id)
                next_tokens_batch_prepare.append(new_results)
        else:
            next_tokens_batch_prepare = self.la_verify_sample_by_batch(metadata, next_guess_logits,
                                                                       next_guess_logits_num_per_batch)
        next_tokens_batch = self.la_update(metadata, cached_idx, next_tokens_batch_prepare, inp_tokens_batch)
        return next_tokens_batch
