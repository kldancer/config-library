# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from collections import defaultdict
from typing import Optional, List

import numpy as np

from .dynamic_decoding import DynamicBranch
from .tokens_knowledge_base_cache import TokensKnowledgeBaseCache
from ...utils.input_manager import ModelInput
from ....modeling.backend_type import BackendType
from ....utils.decorators.time_decorator import timer
from ....utils.env import ENV
from ....utils.log.logging import logger, print_log
from ....utils.tensor import op, tensor, tensor_backend

# trie-tree 查询窗口默认长度
DEFAULT_BRANCH_LENGTH = 16

# 召回草稿时需要匹配的前缀长度
PREFIX_WINDOW_SIZE = 2

# 启动动态解码长度的batch size阈值
DYNAMIC_GAMMA_BS = 4
INITIAL_BRANCH_LENGTH = 3


class DecodingPolicy:
    def __init__(self, kwargs, input_manager, decode_length, eos_token_id):
        self.cache = input_manager.cache
        self.input_manager = input_manager
        self.cache_config = self.input_manager.cache_config
        self.decode_length = decode_length
        self.input_manager = input_manager
        self.device = input_manager.device
        self.eos_token_id = eos_token_id
        self.last_accepted_token = {}
        self.dynamic_algo = kwargs.get('dynamic_algo', False)

        # tokens_knowledge_base speculative decoding
        self.prefix_ids = [[] for _ in range(self.cache_config.cache_size)]
        self.tokens_knowledge_base_cache = TokensKnowledgeBaseCache(dynamic_algo=self.dynamic_algo)
        if isinstance(self.eos_token_id, int):
            self.tokens_knowledge_base_cache.eos = (self.eos_token_id,)
        elif isinstance(self.eos_token_id, list) and self.eos_token_id:
            self.tokens_knowledge_base_cache.eos = tuple(self.eos_token_id)        
        self.tokens_knowledge_base_cache.stop_words = {}  # stop_words
        self.tokens_knowledge_base_param = defaultdict(int)
        self.tokens_knowledge_base_param['branch_length'] = DEFAULT_BRANCH_LENGTH
        self.free_block = []
        self.next_draft = {}
        self.branch_length = INITIAL_BRANCH_LENGTH
        self.last_decoding_len = {}
        self.dynamic_branch = DynamicBranch(decode_length)

    @staticmethod
    def verify_single(next_token_ids, decoding_ids):
        next_token_list = [[] for _ in range(len(decoding_ids))]
        next_tokens_length = [0 for _ in range(len(decoding_ids))]
        offset = 0
        for batch_index, decoding_id in enumerate(decoding_ids):
            if len(decoding_id) == 1:
                next_token_list[batch_index].append(next_token_ids[offset])
                next_tokens_length[batch_index] += 1
                offset += 1
            else:
                draft_ids = decoding_id[1:]
                next_token_list[batch_index].append(next_token_ids[offset])
                next_tokens_length[batch_index] += 1
                if next_token_ids[offset] != draft_ids[0]:
                    offset += len(decoding_id)
                    continue
                all_accepted = True
                for i in range(offset + 1, offset + len(draft_ids)):
                    if next_token_ids[i] == draft_ids[i - offset]:
                        next_token_list[batch_index].append(next_token_ids[i])
                        next_tokens_length[batch_index] += 1
                    else:
                        all_accepted = False
                        next_token_list[batch_index].append(next_token_ids[i])
                        next_tokens_length[batch_index] += 1
                        break
                if all_accepted:
                    next_token_list[batch_index].append(next_token_ids[offset + len(draft_ids)])
                    next_tokens_length[batch_index] += 1
                offset += len(decoding_ids[batch_index])
        return next_token_list, next_tokens_length
    
    def add_prompt_to_cache(self, model_inputs, cached_idx):
        batch_size = len(cached_idx)
        cumulative_seq_len = 0
        host_context_length = model_inputs.context_length
        host_input_ids = model_inputs.input_ids
        for i in range(batch_size):
            seq_len = host_context_length[i]
            start_idx = cumulative_seq_len
            end_idx = cumulative_seq_len + seq_len
            ids = host_input_ids[start_idx + 1: end_idx]  # tokenizer后是否包含起始字符
            if self.dynamic_algo:
                self.tokens_knowledge_base_cache.add(
                    ids, search_size=self.branch_length + 1,
                    pattern='input', use_batch=cached_idx[i])
            else:
                self.tokens_knowledge_base_cache.add(
                    ids, search_size=self.tokens_knowledge_base_param['branch_length'] + 1,
                    pattern='input', use_batch=cached_idx[i])
            self.prefix_ids[cached_idx[i]] = host_input_ids[start_idx: end_idx]
            cumulative_seq_len += seq_len

    def update_cache_speculative(self, cache_ids: np.ndarray,
                                 next_tokens_length: Optional[np.ndarray] = None,  # next_tokens_length [bs]
                                 next_tokens: List = None,  # next_tokens [bs]
                                 sampling: bool = True
                                 ):
        cache_ids_list = cache_ids.tolist()
        if sampling and next_tokens is not None:
            for i, cache_id in enumerate(cache_ids_list):
                self.cache.cached_all_input_ids[cache_id, self.cache.cached_position_id[cache_id] + 1:
                                                          self.cache.cached_position_id[cache_id]
                                                          + next_tokens_length[i] + 1] = next_tokens[i]
        if next_tokens is not None:
            for i, cache_id in enumerate(cache_ids_list):
                self.cache.cached_input_ids[cache_ids[i]] = next_tokens[i][-1]
                self.cache.cached_out_ids[cache_id, self.cache.output_len_count[cache_id]:
                                                    self.cache.output_len_count[cache_id]
                                                    + next_tokens_length[i]] = next_tokens[i]
                self.prefix_ids[cache_id] = (list(self.prefix_ids[cache_id]) + next_tokens[i])
                tids = [x for x in next_tokens[i] if x != -1]
                if self.dynamic_algo:
                    self.tokens_knowledge_base_cache.output_add(
                        tids, search_size=self.branch_length + 1,
                        final=False, pattern='output', use_batch=cache_id)
                else:
                    self.tokens_knowledge_base_cache.output_add(
                        tids, search_size=self.tokens_knowledge_base_param['branch_length'] + 1,
                        final=False, pattern='output', use_batch=cache_id)
        self.cache.output_len_count[cache_ids] += next_tokens_length
        self.cache.cached_seq_lens[cache_ids] += next_tokens_length
        self.cache.cpu_cached_seq_idx[cache_ids] += next_tokens_length
        self.cache.cached_position_id[cache_ids] += next_tokens_length

        tmp_used_block_idx = self.cache.cpu_cached_seq_idx[cache_ids] // self.cache_config.max_block_size
        need_append_block = not np.all(np.equal(tmp_used_block_idx, self.cache.used_block_idx[cache_ids]))

        self.cache.used_block_idx[cache_ids] = tmp_used_block_idx
        self.cache.used_block_offset[cache_ids] = (self.cache.cpu_cached_seq_idx[
            cache_ids]) % self.cache_config.max_block_size
        return need_append_block

    def filter_out_eos(self, end_reason, cache_ids: np.ndarray):
        for i, reason in enumerate(end_reason):
            if reason != 0:
                self.tokens_knowledge_base_cache.output_add([], final=True, pattern='output',
                                                            use_batch=cache_ids[i])
        self.tokens_knowledge_base_cache.changed_input_prefix_trees.clear()

    def update_input_speculative(self, cached_idx: np.ndarray,
                                 next_tokens_length: Optional[np.ndarray] = None,
                                 next_tokens: List = None) -> bool:
        return self.cache.update_cache_speculative(cached_idx, next_tokens_length, next_tokens)

    def verify(self, next_token_ids, decoding_ids, cached_idx):
        next_token_list, next_tokens_length = self.verify_single(next_token_ids, decoding_ids)

        for idx, cid in enumerate(cached_idx):
            self.last_accepted_token[cid] = next_tokens_length[idx]
            if self.dynamic_algo:
                self.last_decoding_len[cid] = len(decoding_ids[idx])

        return next_token_list, np.array(next_tokens_length, dtype=np.int32)

    def get_remain_slot(self, input_data, cached_idx):
        decoding_lengths = [self.decode_length] * len(cached_idx)
        if self.dynamic_algo:
            self.branch_length, decoding_lengths = self.dynamic_branch.dynamic_decoding(cached_idx, self.branch_length,
                                                                                        self.last_accepted_token,
                                                                                        self.last_decoding_len)
        else:
            half_length = self.decode_length / 2
            if len(cached_idx) > DYNAMIC_GAMMA_BS:
                for idx, cid in enumerate(cached_idx):
                    if cid in self.last_accepted_token and self.last_accepted_token[cid] < half_length:
                        decoding_lengths[idx] = half_length

            for idx, cid in enumerate(cached_idx):
                remain_gen_len = self.cache_config.max_gen_len - self.cache.output_len_count[cid]
                decoding_lengths[idx] = min(decoding_lengths[idx], remain_gen_len)

            host_block_table = input_data.block_tables
            host_slots = input_data.slots
            cur_block_idx = self.input_manager.cache.used_block_idx[cached_idx]
            for idx, cur_slot in enumerate(host_slots):
                if (cur_block_idx[idx] + 1) == len(host_block_table[idx]):
                    cur_block = host_block_table[idx][cur_block_idx[idx]]
                    remain_slot = ((cur_block + 1) * 128) - cur_slot
                    remain_slot = max(remain_slot, 1)
                    decoding_lengths[idx] = min(remain_slot, decoding_lengths[idx])
        return decoding_lengths

    def calc_decoding_info(self, input_data: ModelInput, cached_idx: np.ndarray):
        decoding_lengths = self.get_remain_slot(input_data, cached_idx)
        if self.dynamic_algo:
            branch_length = self.get_remain_slot(input_data, cached_idx)
        else:
            branch_length = self.tokens_knowledge_base_param.get('branch_length', DEFAULT_BRANCH_LENGTH)
        batch_indices = cached_idx.tolist()
        decoding_qids = []
        for batch_index in batch_indices:
            decoding_qids.append(self.prefix_ids[batch_index][-PREFIX_WINDOW_SIZE:])

        if self.dynamic_algo:
            decoding_ids, decoding_masks, hit_sizes = (self.tokens_knowledge_base_cache.
                                                       get_all_batch_draft(decoding_qids,
                                                                           batch_decoding_length=decoding_lengths,
                                                                           search_size=branch_length[0],
                                                                           indices=batch_indices))
        else:
            decoding_ids, decoding_masks, hit_sizes = (self.tokens_knowledge_base_cache.
                                                       get_all_batch_draft(decoding_qids,
                                                                           batch_decoding_length=decoding_lengths,
                                                                           search_size=branch_length,
                                                                           indices=batch_indices))
        return decoding_ids, decoding_masks, hit_sizes

    def calc_new_tensor(self, input_data, cached_idx, decoding_ids, decoding_masks, batch_indices):
        input_ids = []
        new_input_lengths = []
        for index, temp_decoding_ids in enumerate(decoding_ids):
            input_ids += temp_decoding_ids
            new_input_lengths.append(len(temp_decoding_ids) +
                                     self.input_manager.cache.cached_position_id[batch_indices[index]])

        new_input_ids_tensor = np.asarray(input_ids, dtype=np.int64)
        new_input_lengths_tensor = np.asarray(new_input_lengths, dtype=np.int64)
        new_max_seq_len = np.max(new_input_lengths)

        position_ids = []
        for index, decoding_mask in enumerate(decoding_masks):
            position_ids += ((np.sum(decoding_mask, axis=1) +
                              self.input_manager.cache.cached_position_id[batch_indices[index]]) - 1).tolist()
        new_position_ids_tensor = np.asarray(position_ids, dtype=np.int64)

        host_block_table = input_data.block_tables

        host_slots = input_data.slots

        cur_block_idx = self.input_manager.cache.used_block_idx[cached_idx]
        new_slots_length = np.sum([len(x) for x in decoding_ids])

        start = 0
        new_slots = np.empty(new_slots_length)
        for idx, start_slot in enumerate(host_slots):
            cur_block = host_block_table[idx][cur_block_idx[idx]]
            next_block_slot_count = 0

            if (start_slot + len(decoding_ids[idx])) > ((cur_block + 1) * 128):
                next_block_slot_count = (start_slot + len(decoding_ids[idx])) - ((cur_block + 1) * 128)

            temp = np.arange(start_slot, start_slot + len(decoding_ids[idx]))
            if next_block_slot_count > 0:
                next_block = host_block_table[idx][cur_block_idx[idx] + 1]
                back_temp = np.arange(next_block * 128, next_block * 128 + next_block_slot_count)
                temp[-next_block_slot_count:] = back_temp

            new_slots[start: start + len(decoding_ids[idx])] = temp
            start += len(decoding_ids[idx])
        res = (new_input_lengths_tensor, new_max_seq_len, new_input_ids_tensor, new_position_ids_tensor, new_slots)
        return res

    def update_infer_input(self, input_data: ModelInput, cached_idx: np.ndarray):
        batch_indices = cached_idx.tolist()
        decoding_ids, decoding_masks, _ = self.calc_decoding_info(input_data, cached_idx)

        new_input_lengths_tensor, new_max_seq_len, new_input_ids_tensor, new_position_ids_tensor, new_slots \
            = self.calc_new_tensor(input_data, cached_idx, decoding_ids, decoding_masks, batch_indices)
        new_model_inputs = ModelInput(input_ids=new_input_ids_tensor,
                                      position_ids=new_position_ids_tensor,
                                      block_tables=input_data.block_tables,
                                      slots=new_slots,
                                      context_length=new_input_lengths_tensor,
                                      max_seq_len=new_max_seq_len,
                                      prefill_head_indices=input_data.prefill_head_indices,
                                      is_prefill=input_data.is_prefill)
        logger.debug(f'update_infer_input new_model_inputs.input_ids: {new_model_inputs.input_ids}')
        if ENV.framework_backend == BackendType.MS:
            new_model_inputs.slots = new_model_inputs.slots.astype(np.int32)
        return new_model_inputs, decoding_ids, decoding_masks


class MemoryDecodingSampler:
    def __init__(self):
        self.qlens = None
        self.sampling_param = None

    def need_do_repetition_penalty(self):
        if self.sampling_param is not None and self.sampling_param.penalty_meta is not None:
            repetition_penaltys = self.sampling_param.penalty_meta.repetition_penalty
            if repetition_penaltys is None:
                return False
            default_penaltys = tensor_backend.ones(repetition_penaltys.shape,
                                                   device=tensor_backend.get_device(repetition_penaltys),
                                                   dtype=repetition_penaltys.dtype)

            return not tensor_backend.equal(repetition_penaltys, default_penaltys)
        else:
            return False

    def gather_sampling_params(self, logits, greedy):
        temperatures = None
        if self.sampling_param is not None:
            temperatures = self.sampling_param.temperature
            
        if greedy:
            top_ks = np.full(len(self.qlens), 1)
        elif self.sampling_param is not None and self.sampling_param.top_k_meta is not None:
            top_ks = self.sampling_param.top_k_meta.top_k_array
        else:
            top_ks = np.full(len(self.qlens), logits.shape[1])

        if self.sampling_param is not None and self.sampling_param.top_p_meta is not None: 
            top_ps = self.sampling_param.top_p_meta.top_p_array
        else:
            top_ps = np.full(len(self.qlens), 1.0)

        total_logits_nums = sum(self.qlens)

        draft_temperatures = None
        if temperatures is not None:
            draft_temperatures = tensor_backend.ones((total_logits_nums, 1), dtype=logits.dtype,
                                                     device=tensor_backend.get_device(logits))
        draft_ks = np.zeros(total_logits_nums)
        draft_ps = np.zeros(total_logits_nums)
        logits_index = 0
        for batch, batch_token_num in enumerate(self.qlens):
            if temperatures is not None:
                draft_temperatures[logits_index:logits_index + batch_token_num] = temperatures[batch]
            draft_ks[logits_index:logits_index + batch_token_num] = top_ks[batch]
            draft_ps[logits_index:logits_index + batch_token_num] = top_ps[batch]
            logits_index += batch_token_num
        return draft_temperatures, draft_ks, draft_ps

    def multinomial_select(self, probs, seeds):
        random_values = []
        for batch, batch_logits_num in enumerate(self.qlens):
            s = seeds[batch]
            s = s.astype(np.int32)
            s = s % np.iinfo(np.int32).max
            np.random.seed(s)
            random_values.extend(np.random.rand(batch_logits_num))
        sorted_prob, sort_indices = op.sort(probs, descending=True)
        cdf_matrix = tensor_backend.cumsum(sorted_prob, dim=-1)
        sample_probs = np.expand_dims(np.array(random_values), axis=-1)
        selected_ids = op.searchsorted(cdf_matrix, tensor_backend.to(tensor.tensor(sample_probs),
                                                                     tensor_backend.get_device(probs)))
        idx_tmp = tensor_backend.where(selected_ids == cdf_matrix.shape[1])[0]
        if idx_tmp.shape[0] != 0:
            selected_ids[idx_tmp] = op.argmax(cdf_matrix[idx_tmp], dim=-1).unsqueeze(1)
        selected_token_ids = tensor_backend.gather(sort_indices, selected_ids, -1)
        return selected_token_ids
    
    def do_repetition(self, logits_new, sampling_data):
        # repetition penaltys
        pad_inputs_ids = sampling_data.all_input_ids
        if pad_inputs_ids is not None and self.need_do_repetition_penalty():
            pad_inputs_ids[pad_inputs_ids == -1] = 1
            repetition_penaltys = self.sampling_param.penalty_meta.repetition_penalty
            gather_logits = tensor_backend.gather(logits_new, pad_inputs_ids, -1)
            gather_logits = tensor_backend.where(gather_logits < 0, gather_logits * repetition_penaltys,
                                                 gather_logits / repetition_penaltys)
            gather_logits = gather_logits.to(logits_new.dtype)

            if ENV.framework_backend == BackendType.ATB:
                logits_new.scatter_(-1, pad_inputs_ids, gather_logits)
            else:
                logits_new = op.scatter(logits_new, -1, pad_inputs_ids, gather_logits)
            
        return logits_new

    @timer.track_time('sample')
    def do_sampling(self, logits_new, qlens, sampling_param, greedy=False):

        draft_temperatures, draft_ks, draft_ps = self.gather_sampling_params(logits_new, greedy)

        # top-k
        max_k = np.max(draft_ks)
        max_k = max(max_k, 1)
        max_k = int(min(max_k, tensor_backend.shape(logits_new, -1)))
        values, indices = op.topk(logits_new, max_k)

        # temperatures
        if draft_temperatures is not None:
            try:
                values = values / draft_temperatures
            except ZeroDivisionError as e:
                print_log(ENV.rank, logger.error, 'temperature cannot be `0`!')
                raise e

        # top-p
        k_matrix = tensor_backend.repeat(tensor.tensor(draft_ks), (max_k, 1)).T
        pos_matrix = tensor_backend.repeat(tensor.tensor(np.arange(max_k)), (sum(qlens), 1))
        mask_fill = pos_matrix >= k_matrix
        mask_fill[:, 0] = False
        mask_fill = tensor_backend.to(mask_fill, tensor_backend.get_device(values))
        values = op.masked_fill(values, mask_fill,
                                tensor.tensor(np.finfo(tensor_backend.numpy(values[0][0]).dtype).min))
        values = op.flip(values, dims=[-1])
        indices = op.flip(indices, dims=[-1])
        cumulative_probs = tensor_backend.cumsum(tensor_backend.softmax(values, dim=-1), dim=-1)
        sorted_indices_to_remove = cumulative_probs <= tensor_backend.tensor(
            1 - draft_ps, device=tensor_backend.get_device(values)).unsqueeze(1)

        values = op.masked_fill(values, sorted_indices_to_remove,
                                tensor.tensor(np.finfo(tensor_backend.numpy(values[0][0]).dtype).min))

        # softmax and multinomial select token id
        probs = tensor_backend.softmax(values, dim=-1)
        probs = tensor_backend.cpu(probs).to(tensor.float32)
        indices = tensor_backend.cpu(indices)
        seeds = np.zeros(len(qlens))
        if sampling_param is not None and sampling_param.seed_meta is not None:
            seeds = sampling_param.seed_meta.seed_array
        selected_token_ids = self.multinomial_select(probs, seeds)
        next_tokens = tensor_backend.gather(indices, selected_token_ids, -1).reshape(-1)
        return next_tokens
