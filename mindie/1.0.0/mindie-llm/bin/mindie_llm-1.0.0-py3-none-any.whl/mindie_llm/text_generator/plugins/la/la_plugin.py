# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import time
import numpy as np

from .decoding_policy import DecodingPolicy
from ..plugin import Plugin
from ...utils.input_metadata import InputMetadata
from ...utils.request import GenerationParams, Request
from ....utils.decorators.time_decorator import timer
from ....utils.env import ENV
from ....utils.tensor import npu
from ....utils.log.logging import logger, print_log


def is_log_enable():
    log_level = ENV.log_file_level
    if log_level == "DEBUG":
        return True
    return False


class LaPlugin(Plugin):
    def __init__(self, generator_backend, cache_manager, input_manager, **kwargs):
        super().__init__(generator_backend, cache_manager, input_manager)
        block_size = cache_manager.block_size
        cache = self.input_manager.cache
        self.sample_dtype = cache.default_sampling_param.dtype
        max_gen_len = input_manager.cache_config.max_gen_len
        self.decoding_policy = DecodingPolicy(kwargs, self.input_manager, self.model_wrapper,
                                              is_log_enable(), block_size)
        rank = generator_backend.rank
        level = kwargs.get('level', 4)
        window = kwargs.get('window', 5)
        guess_set_size = kwargs.get("guess_set_size", 5)
        print_log(rank, logger.debug, f'Lookahead start, NWG={level}/{window}/{guess_set_size}')
        self.warmup(max_gen_len)

    @staticmethod
    def is_all_equal(tensor):
        if tensor is None:
            return True
        for i in tensor:
            if i != tensor[0]:
                return False
        return True

    def warmup_generate(self, sampling_param, warmup_input, has_sampling, block_tables, max_gen_len):
        gen_len = min(64, max_gen_len)
        warmup_req = Request(0, warmup_input, GenerationParams(max_new_tokens=gen_len), has_sampling, sampling_param)
        meta_data = InputMetadata.from_requests([warmup_req], block_tables, True)
        meta_data.batch_block_tables = block_tables
        if is_log_enable():
            self.decoding_policy.request_stats_list.new_request_in(len(warmup_input), 0)
        _, eos, _, _, _, _ = self.generate_token(meta_data)
        meta_data.is_prefill = False

        while eos[0] == 0:
            _, eos, _, _, _, _ = self.generate_token(meta_data)

    def warmup(self, max_gen_len):
        sampling_param = np.array([(0.7, 50., 0.92, 0.95, True, 10.0, 1.1, 0., 0., True, 1.0)], dtype=self.sample_dtype)

        warmup_input = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
        block_tables = np.array([[0, 1, 2, 3, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]])

        self.warmup_generate(sampling_param, warmup_input, True, block_tables, max_gen_len)

    @timer.track_time('generate_token')
    def generate_token(self, input_metadata: InputMetadata):
        start_time = 0
        preprocess_time = 0
        forward_time = 0
        postprocess_time = 0

        if is_log_enable():
            npu.synchronize()
            start_time = time.time() * 1000

        model_inputs, cached_idx, sampling_param, sampling_data, request_ids = self.preprocess(input_metadata)
        model_inputs, q_len, attention_mask = (
            self.decoding_policy.handle_input(model_inputs, input_metadata, sampling_param))

        if is_log_enable():
            npu.synchronize()
            preprocess_time = time.time() * 1000 - start_time

        out = self.generator_backend.forward(
            model_inputs,
            q_lens=q_len,
            spec_mask=attention_mask
        )

        if is_log_enable():
            npu.synchronize()
            forward_time = time.time() * 1000 - start_time - preprocess_time

        next_tokens = self.decoding_policy.la_postprocess_multi_batch(input_metadata, out, sampling_param,
                                                                      sampling_data, cached_idx)

        need_append_block = self.decoding_policy.update_input_cache(cached_idx, next_tokens)
        token_indices = self.input_manager.cache.output_len_count[cached_idx]
        contains_eos, eos_np, filtered_indices_np, truncation_indices = (
            self.input_manager.filter_eos_request(input_metadata, cached_idx, next_tokens, self.sampler))
        # 如果需要新增block 或者 有请求要退出, 则不能继续做decode
        stop_generate = need_append_block or contains_eos

        if is_log_enable():
            npu.synchronize()
            postprocess_time = time.time() * 1000 - start_time - preprocess_time - forward_time

        for batch in range(input_metadata.batch_size):
            req_id = input_metadata.batch_request_ids[batch]
            if eos_np[batch] != 0:
                self.decoding_policy.handle_eos(req_id)
            if is_log_enable():
                self.decoding_policy.request_stats_list.record_req_time(
                    req_id, preprocess_time, forward_time, postprocess_time, input_metadata.is_prefill)
                if eos_np[batch] != 0:
                    self.decoding_policy.request_stats_list.final_print_req_stats(req_id)
        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids)
        return res_and_stop
