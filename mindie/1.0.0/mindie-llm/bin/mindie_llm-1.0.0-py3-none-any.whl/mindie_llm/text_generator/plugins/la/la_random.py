# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

INITIALIZATION_MULTIPLIER = 1812433253  # 初始化状态数组时的乘法运算常量
TWIST_XOR_MASK = 0x9908b0df             # 状态数组旋转时用于异或运算的常量
HIGH_BIT_MASK = 0x80000000              # 用于掩码运算，提取最高位
LOW_BIT_MASK = 0x7fffffff               # 用于掩码运算，提取低 31 位
TWIST_INDEX_OFFSET = 397                # 状态数组旋转时用于下标的偏移量
STATE_ARRAY_SIZE = 624                  # 状态数组的大小
FIRST_LEFT_SHIFT_MASK = 2636928640      # 第一次左移后的掩码常量
SECOND_LEFT_SHIFT_MASK = 4022730752     # 第二次左移后的掩码常量


def _int32(x):
    return int(x & 0xFFFFFFFF)


class MT19937:
    # 根据seed初始化state数组
    def __init__(self, seed):
        self.seed = seed
        self.mt = [0] * STATE_ARRAY_SIZE
        self.mt[0] = seed
        self.mti = 0
        for i in range(1, STATE_ARRAY_SIZE):
            self.mt[i] = _int32(INITIALIZATION_MULTIPLIER * (self.mt[i - 1] ^ self.mt[i - 1] >> 30) + i)
    
    # 提取伪随机数
    def extract_number(self):
        if self.mti == 0:
            self.twist()
        # 对状态数组中的值进行一系列位运算来提取伪随机数
        y = self.mt[self.mti]
        y = y ^ y >> 11
        y = y ^ y << 7 & FIRST_LEFT_SHIFT_MASK
        y = y ^ y << 15 & SECOND_LEFT_SHIFT_MASK
        y = y ^ y >> 18
        self.mti = (self.mti + 1) % STATE_ARRAY_SIZE
        return _int32(y)
    
    # 对状态进行旋转
    def twist(self):
        for i in range(0, STATE_ARRAY_SIZE):
            y = _int32((self.mt[i] & HIGH_BIT_MASK) + (self.mt[(i + 1) % STATE_ARRAY_SIZE] & LOW_BIT_MASK))
            self.mt[i] = (y >> 1) ^ self.mt[(i + TWIST_INDEX_OFFSET) % STATE_ARRAY_SIZE]

            if y % 2 != 0:
                self.mt[i] = self.mt[i] ^ TWIST_XOR_MASK
