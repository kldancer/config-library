# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import importlib
import json
import os
from enum import Enum
from .plugin import Plugin
from ...utils.log.logging import logger, message_filter
from ...utils.log.error_code import ErrorCode


class InferenceType(int, Enum):
    REGRESSION = 0
    SPECULATE = 1
    SPLITFUSE = 2
    PREFIXCACHE = 3


PLUGIN_TYPE = 'plugin_type'


def get_plugin(plugin_config, generator_backend, cache_manager, input_manager):
    key_plugin_type = PLUGIN_TYPE
    if not plugin_config or key_plugin_type not in plugin_config or not plugin_config[key_plugin_type]:
        plugin_cls = Plugin
    else:
        plugin_type = plugin_config.get(key_plugin_type, 'not_support')
        if plugin_type is None:
            plugin_cls = Plugin
        else:
            plugin_type_lower = plugin_type.lower()
            current_path = os.path.dirname(os.path.abspath(__file__))
            supported_plugins = []
            for foldername in os.listdir(current_path):
                is_folder = os.path.isdir(os.path.join(current_path, foldername))
                skip_invalid_folder = not foldername.startswith("_")
                if is_folder and skip_invalid_folder:
                    supported_plugins.append(foldername)

            if plugin_type_lower not in supported_plugins:
                message = (
                    f"unsupported model type: {plugin_type_lower}, Please check whether a folder"
                    f"named {plugin_type_lower} is exist in mindie_llm.text_generator.plugins.") 
                logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_NAME_INVALID)               
                raise NotImplementedError(message)

            cls_name = ''.join([word.capitalize() for word in plugin_type_lower.split('_')]) + 'Plugin'

            module_path = f"mindie_llm.text_generator.plugins.{plugin_type_lower}.{plugin_type_lower}_plugin"
            plugin_module = importlib.import_module(module_path)
            plugin_cls = getattr(plugin_module, f"{cls_name}")

    return plugin_cls(generator_backend, cache_manager, input_manager, **plugin_config)


PLUGIN_INFERENCE_TYPE = {
    'la': InferenceType.SPECULATE,
    'memory_decoding': InferenceType.SPECULATE,
    'splitfuse': InferenceType.SPLITFUSE,
    'prefix_cache': InferenceType.PREFIXCACHE
}


def get_inference_mode(plugin_config):
    if not plugin_config:
        return InferenceType.REGRESSION
    key_plugin_type = PLUGIN_TYPE
    plugin_type = plugin_config.get(key_plugin_type, "")
    if not plugin_type:
        return InferenceType.REGRESSION
    plugin_type = plugin_type.lower()
    return PLUGIN_INFERENCE_TYPE.get(plugin_type, InferenceType.REGRESSION)


def validation_func_la(data, speculation_gamma):
    return (data.get('level') - 1) * (data.get('window') + data.get('guess_set_size')) <= speculation_gamma


PLUGIN_FIELDS = 'required_fields'
PLUGIN_CHECK_FUNC = 'validation_func'
MAX_JSON_LENGTH = 1024


class PluginParameterValidator:
    def __init__(self, speculation_gamma):
        self.speculation_gamma = speculation_gamma
        # 定义 plugin_type 和它所需要的字段之间的映射以及相应的校验函数
        # required_fields中添加必填参数，validation_func中添加对必填参数的校验逻辑
        self.rules = {
            'la': {
                PLUGIN_FIELDS: {'level', 'window', 'guess_set_size'},
                PLUGIN_CHECK_FUNC: lambda data: validation_func_la(data, self.speculation_gamma)
            },
            'memory_decoding': {
                PLUGIN_FIELDS: {'decoding_length'},
                PLUGIN_CHECK_FUNC: lambda data: data.get('decoding_length') <= self.speculation_gamma
            },
            'splitfuse': {
                PLUGIN_FIELDS: set(),  # 没有额外的字段要求
                PLUGIN_CHECK_FUNC: lambda data: True  # 不需要额外校验
            },
            'prefix_cache': {
                PLUGIN_FIELDS: set(),  # 没有额外的字段要求
                PLUGIN_CHECK_FUNC: lambda data: True  # 不需要额外校验
            }
        }

    def validate(self, plugin_params):
        if not plugin_params:
            plugin_config = {PLUGIN_TYPE: None}
            return plugin_config
        
        # 验证给定的 JSON 字符串是否符合对应的 plugin_type 规则
        try:
            if len(plugin_params) > MAX_JSON_LENGTH:
                message = (f"The length of plugin_params is too long, it should be within (0, {MAX_JSON_LENGTH}]")
                raise ValueError(message)
            data = json.loads(plugin_params)
        except json.JSONDecodeError as e:
            message = ("The 'plugin_params' field does not conform to JSON format. Please check.")
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_NAME_INVALID)
            raise json.JSONDecodeError(message) from e

        plugin_type = data.get(PLUGIN_TYPE)
        if plugin_type == "":
            plugin_config = {PLUGIN_TYPE: None}
            return plugin_config

        rule = self.rules.get(plugin_type)
        if rule is None:
            message = (
                f"Unsupported plugin type: {plugin_type}, "
                f"Only 'la', 'memory_decoding', 'prefix_cache', and 'splitfuse' are supported.")
            message = message_filter(message)
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_NAME_INVALID)
            raise NotImplementedError(message)

        required_fields = rule[PLUGIN_FIELDS]
        missing_fields = required_fields.difference(data.keys())
        if missing_fields:
            message = (f"Missing fields for plugin_type '{plugin_type}': {missing_fields}")
            message = message_filter(message)
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_PARAM_VALUE_ERR)
            raise NotImplementedError(message)
        
        # 如果定义了校验函数，则执行校验
        if not rule[PLUGIN_CHECK_FUNC](data):
            message = (f"Validation failed for plugin_type '{plugin_type}'."
                       f" Please check the parameter configuration against the user manual.")
            message = message_filter(message)
            logger.error(message, ErrorCode.TEXT_GENERATOR_PLUGIN_PARAM_VALUE_ERR)
            raise ValueError(message)

        return data