# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import time
import numpy as np

from .decoding_policy import DecodingPolicy
from ..plugin import Plugin
from ...utils.input_metadata import InputMetadata
from ...utils.request import GenerationParams, Request
from ....modeling.backend_type import BackendType
from ....utils.decorators.time_decorator import timer
from ....utils.env import ENV
from ....utils.log.logging import logger, print_log

UPDATE_INTERVAL = 2 * 60


def is_log_enable():
    log_level = ENV.log_file_level
    if log_level == "DEBUG":
        return True
    return False


class PrefixCachePlugin(Plugin):
    def __init__(self, generator_backend, cache_manager, input_manager, **kwargs):
        super().__init__(generator_backend, cache_manager, input_manager)
        self.decoding_policy = DecodingPolicy(self.input_manager)
        # 全量推理次数
        self.total_batch_size = 0
        self.total_prefill_time = 0
        self.total_token_num = 0
        self.total_forward_time_cost = 0
        self.total_matched_token_num = 0
        # 记录上一次的更新时间
        self.update_time = 0
        self.rank = generator_backend.rank
        self.attention_mask = AttentionMask(None)
        cache = self.input_manager.cache
        self.sample_dtype = cache.default_sampling_param.dtype
        max_gen_len = input_manager.cache_config.max_gen_len

        print_log(self.rank, logger.debug, 'Prefix Cache start')
        print_log(self.rank, logger.debug, 'Prefix Cache warmup Start!')
        self.warmup(max_gen_len)
        print_log(self.rank, logger.debug, 'Prefix Cache warmup Over!')

    def reset_counter(self):
        self.total_batch_size = 0
        self.total_prefill_time = 0
        self.total_token_num = 0
        self.total_forward_time_cost = 0
        self.total_matched_token_num = 0

    @timer.track_time('generate_token')
    def generate_token(self, input_metadata: InputMetadata):
        model_inputs, cached_idx, sampling_param, sampling_data, request_ids = self.preprocess(input_metadata)
        # prefill阶段有缓存时，用decode并行解码模式代替prefill
        if input_metadata.is_prefill and input_metadata.computed_blocks is not None:
            model_inputs.is_prefill = False
            model_inputs = self.decoding_policy.update_infer_input(model_inputs, input_metadata)
        if input_metadata.is_prefill or self.generator_backend.backend_type == BackendType.MS:
            q_lens, decoding_masks = self.get_extra_infer_input(model_inputs, input_metadata.batch_size)
        else:
            q_lens = []
            decoding_masks = None
        
        # 纯推理开始时间
        start_time = time.perf_counter()

        logits = self.generator_backend.forward(
            model_inputs,
            q_lens=q_lens,
            spec_mask=decoding_masks
        )

        next_tokens, _ = self.generator_backend.sample(logits, sampling_data, sampling_param)

        sampling = True if sampling_param is not None else False
        eos_np, stop_generate, truncation_indices, token_indices, next_tokens = self.postprocess(
            input_metadata, next_tokens, cached_idx, sampling)

        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids)

        if is_log_enable() and input_metadata.is_prefill and self.rank == 0:
            new_update_time = time.perf_counter()
            if new_update_time - self.update_time > UPDATE_INTERVAL:
                self.reset_counter()
            self.update_time = new_update_time
            end_time = time.perf_counter()
            self.total_prefill_time += 1
            self.total_batch_size += input_metadata.batch_size
            time_cost = (end_time - start_time) * 1000
            self.total_forward_time_cost += time_cost
            self.total_token_num += input_metadata.total_seq_num
            matched_token_num = 0
            if input_metadata.computed_blocks is not None:
                matched_token_num = input_metadata.max_block_size * sum(input_metadata.computed_blocks)
                self.total_matched_token_num += matched_token_num
            print_log(self.rank, logger.debug, f'Prefix Cache Reporter: #batchsize: {input_metadata.batch_size}, '
                      f'#forward time cost: {round(time_cost, 3)}ms, #new-token: {input_metadata.total_seq_num}, '
                      f'#cached-token: {matched_token_num}, #cache hit rate: '
                      f'{round(matched_token_num / input_metadata.total_seq_num * 100, 3)}%')
            print_log(self.rank, logger.debug, f'Prefix Cache Global Reporter: #total prefill time cost: '
                      f'{round(self.total_forward_time_cost, 3)}ms, #average prefill time cost: '
                      f'{round(self.total_forward_time_cost / self.total_prefill_time, 3)}ms, #average prefill '
                      f'batchsize: {round(self.total_batch_size / self.total_prefill_time, 3)}, #total prefill tokens'
                      f': {self.total_token_num}, #total matched tokens: {self.total_matched_token_num}, #total '
                      f'cached hit rate: {round(self.total_matched_token_num / self.total_token_num * 100, 3)}%')

        return res_and_stop

    def get_extra_infer_input(self, model_inputs, batch_size):
        q_lens_list = []
        decoding_mask_list = None
        if not model_inputs.is_prefill:  # decode并行解码模式，需要构造q_lens和spec_mask参数
            if model_inputs.query_length is not None:
                q_lens_list = model_inputs.query_length.tolist()
            else:
                q_lens_list = [1] * batch_size
            
            kv_dtype = self.cache_manager.dtype
            if self.generator_backend.backend_type == BackendType.MS:
                if model_inputs.query_length is None:
                    return q_lens_list, [[0]] * batch_size
                seq_len = model_inputs.max_seq_len
                atten_mask = self.attention_mask.get_attn_mask(seq_len)
            else:
                kv_device = self.model_wrapper.device
                atten_mask = self.model_wrapper.model_runner.model.attn_mask.get_attn_mask(model_inputs.max_seq_len,
                                                                                           kv_dtype, kv_device)
                if atten_mask[0][1] > 0:
                    atten_mask = atten_mask * -10000.0
            req_mask = None
            for i in range(batch_size):
                start = model_inputs.context_length[i] - q_lens_list[i]
                end = model_inputs.context_length[i]
                if req_mask is None:
                    req_mask = atten_mask[start:end]
                else:
                    if self.generator_backend.backend_type == BackendType.MS:
                        req_mask = np.concatenate((req_mask, atten_mask[start:end]), axis=0)
                    else:
                        import torch
                        req_mask = torch.cat((req_mask, atten_mask[start:end]), 0)
            decoding_mask_list = req_mask
        return q_lens_list, decoding_mask_list

    def warmup_generate(self, sampling_param, warmup_input, has_sampling, block_tables, max_gen_len):
        gen_len = min(64, max_gen_len)
        warmup_req = Request(0, warmup_input, GenerationParams(max_new_tokens=gen_len), has_sampling, sampling_param)
        meta_data = InputMetadata.from_requests([warmup_req], block_tables, True)
        meta_data.batch_block_tables = block_tables

        meta_data.is_prefill = True
        meta_data.computed_blocks = [0] * meta_data.batch_size
        self.generate_token(meta_data)

    def warmup(self, max_gen_len):
        sampling_param = np.array([(0.7, 50., 0.92, 0.95, True, 10.0, 1.1, 0., 0., True, 1.0)], dtype=self.sample_dtype)

        warmup_input = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1] * 30)
        block_tables = np.array([[0, 1, 2, 3, 4, 5, 6, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]])

        self.warmup_generate(sampling_param, warmup_input, True, block_tables, max_gen_len)


class AttentionMask:
    def __init__(self, atten_mask):
        self._seq_len_cache = 0
        self.atten_mask_cache = atten_mask
    
    def update_attn_cache(self, seq_len):
        # Reset the tables if the sequence length has changed,
        # or if we're on a new device (possibly due to tracing for instance). 
        if seq_len > self._seq_len_cache:
            self._seq_len_cache = seq_len
            bias_cache = np.tril(np.ones((seq_len, seq_len), dtype=np.bool_))
            bias_cache = ~bias_cache
            mask_value = np.finfo(np.float32).min
            atten_mask = np.ma.masked_array(np.zeros((seq_len, seq_len)), mask=bias_cache).filled(mask_value)
            self.atten_mask_cache = atten_mask

    def get_attn_mask(self, max_s: int):
        self.update_attn_cache(max_s)
        return self.atten_mask_cache[:max_s, :max_s]