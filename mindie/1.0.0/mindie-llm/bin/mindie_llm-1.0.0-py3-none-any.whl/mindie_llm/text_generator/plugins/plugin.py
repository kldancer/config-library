# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from ...utils.decorators.time_decorator import timer


class Plugin:
    def __init__(self, generator_backend, cache_manager, input_manager, **kwargs):
        self.generator_backend = generator_backend
        self.model_wrapper = self.generator_backend.model_wrapper
        self.sampler = self.generator_backend.sampler
        self.cache_manager = cache_manager
        self.input_manager = input_manager

    @timer.track_time('generate_token')
    def generate_token(self, input_metadata):
        model_inputs, cached_idx, sampling_param, sampling_data, request_ids = self.preprocess(input_metadata)
        logits = self.generator_backend.forward(model_inputs)

        next_tokens, _ = self.generator_backend.sample(logits, sampling_data, sampling_param)

        sampling = True if sampling_param is not None else False
        eos_np, stop_generate, truncation_indices, token_indices, next_tokens = (
            self.postprocess(input_metadata, next_tokens, cached_idx, sampling))

        res_and_stop = (next_tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids)
        return res_and_stop

    @timer.track_time('preprocess')
    def preprocess(self, input_metadata):
        cached_idx = self.input_manager.save_input_cache(input_metadata)
        model_inputs, sampling_param, sampling_data, request_ids = \
            self.input_manager.concatenate(input_metadata, cached_idx, False)
        res = (model_inputs, cached_idx, sampling_param, sampling_data, request_ids)
        return res

    @timer.track_time('stop')
    def postprocess(self, input_metadata, next_tokens, cached_idx, sampling):
        need_append_block = self.input_manager.update_input(cached_idx, next_tokens, sampling)
        token_indices = self.input_manager.cache.output_len_count[cached_idx]
        next_tokens = next_tokens.reshape((-1, 1)).tolist()
        contains_eos, eos_np, filtered_indices_np, truncation_indices = (
            self.input_manager.filter_eos_request(input_metadata, cached_idx, next_tokens, self.sampler))
        stop_generate = need_append_block or contains_eos
        res = (eos_np, stop_generate, truncation_indices, token_indices, next_tokens)
        return res
