# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import wraps
from _cpu_logits_handler import _PostProcessingManager

import numpy as np
from mindspore import mint, Tensor
from mindspore.communication import get_rank
import mindspore as ms

from .logits_handler import LogitsHandler
from ...utils.sampling_metadata import SamplingParam
from ....utils.log.logging import logger, print_log
from ....utils.env import ENV

MS_HANDLER_REGISTRY = {}


def register_class(name):
    def decorator(cls):
        MS_HANDLER_REGISTRY[name] = cls

        @wraps(cls)
        def wrapper(*args, **kwargs):
            return cls(*args, **kwargs)
        return wrapper
    return decorator


def repetition_penalty_with_outliers_ids(logits, sequence_ids, repetition_penalty, rank=0):
    bs, vocab_size = logits.shape
    sequence_tokens_counts = mint.zeros((bs, vocab_size + 1), dtype=ms.int32)
    sequence_ids = mint.clamp(sequence_ids, -1, vocab_size)
    sequence_ids[mint.lt(sequence_ids, 0)] = vocab_size
    sequence_tokens_counts = mint.scatter_add(
        sequence_tokens_counts, 1, sequence_ids, mint.ones_like(sequence_ids))
    mask = mint.gt(sequence_tokens_counts[:, :vocab_size], 0)
    try:
        logits = mint.where(mint.logical_and(mask, mint.lt(logits, 0)), logits * repetition_penalty,
                            logits)
        logits = mint.where(mint.logical_and(mask, mint.gt(logits, 0)), logits / repetition_penalty,
                            logits)
    except ZeroDivisionError as e:
        print_log(rank, logger.error, 'repetition penalty cannot be `0`!')
        raise e
    res = logits, None
    return res


@register_class('repetition_penalty')
class RepetitionPenaltyLogitsHandler(LogitsHandler):
    def __init__(self, metadata):
        super().__init__(metadata)

    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        repetition_penalty = params.penalty_meta.repetition_penalty
        sequence_ids = self.metadata.sequence_ids
        bs, vocab_size = logits.shape
        sequence_ids_np = sequence_ids.asnumpy()
        if sequence_ids_np.min() < 0 or sequence_ids_np.max() >= vocab_size:
            return repetition_penalty_with_outliers_ids(logits, sequence_ids, repetition_penalty, self.metadata.rank)

        repetition_logits = mint.gather(logits, 1, sequence_ids)
        try:
            repetition_logits = mint.where(repetition_logits < 0, repetition_logits * repetition_penalty,
                                           repetition_logits / repetition_penalty)
        except ZeroDivisionError as e:
            print_log(self.metadata.rank, logger.error, 'repetition penalty cannot be `0`!')
            raise e
        logits = mint.scatter(logits, -1, sequence_ids, repetition_logits.astype(logits.dtype))
        res = logits, None
        return res


@register_class('frequency_penalty')
class FrequencyPenaltyLogitsHandler(LogitsHandler):
    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        self.metadata.count_output_tokens()
        logits -= params.penalty_meta.frequency_penalty * self.metadata.output_tokens_counts
        res = logits, None
        return res


@register_class('presence_penalty')
class PresencePenaltyLogitsHandler(LogitsHandler):
    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        self.metadata.count_output_tokens()
        output_tokens_mask = self.metadata.output_tokens_counts > 0
        logits -= params.penalty_meta.presence_penalty * output_tokens_mask
        res = logits, None
        return res


@register_class('temperature')
class TemperatureLogitsHandler(LogitsHandler):
    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        try:
            logits = logits / params.temperature
        except ZeroDivisionError as e:
            print_log(self.metadata.rank, logger.error, 'temperature cannot be `0`!')
            raise e
        res = logits, None
        return res


@register_class('topk_topp_sampling')
class TopKTopPSamplingLogitsHandler(LogitsHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try:
            rank_id = get_rank()
        except RuntimeError:
            # If distributed initialization is not performed.
            rank_id = 0

        self.processor = _PostProcessingManager.get_instance(self.metadata.num_threads, rank_id)
        self.filter_value = self.metadata.filter_value
        self.speed_mode, self.use_approx = bool(ENV.speed_mode_type & 2), bool(ENV.speed_mode_type & 1)

    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        # top_k
        max_top_k = int(params.top_k_meta.max_top_k)
        top_k = params.top_k_meta.top_k_tensor

        kth_logits = None
        if max_top_k > 0:
            k_logits, k_index = mint.topk(logits, max_top_k, 1)
            if params.top_k_meta.top_k_disabled_mask_tensor is not None:
                kth_logits = mint.gather(k_logits, 1, top_k).reshape(-1, 1)
                kth_logits.masked_fill(params.top_k_meta.top_k_disabled_mask_tensor, self.filter_value)
                indices_to_remove = logits < kth_logits
                logits.masked_fill(indices_to_remove, self.filter_value)
                sorted_logits, sorted_indices = mint.sort(logits, descending=True)
            else:
                return self._fusion_topk_topp_sampling(k_logits, k_index)
        else:
            sorted_logits, sorted_indices = mint.sort(logits, descending=True)

        # top_p
        top_p = params.top_p_meta.top_p_tensor

        cutoff_logit = None
        if top_p is not None:
            cumulative_probs = mint.nn.functional.softmax(sorted_logits, dim=-1)
            cumulative_probs = mint.cumsum(cumulative_probs, dim=-1)
            cutoff_index = mint.sum(cumulative_probs < top_p, dim=-1, keepdim=True)

            # Avoid out-of-bounds when top_p is close to 1.
            max_cutoff_index = sorted_logits.shape[-1] - 1
            cutoff_index = mint.where(cutoff_index > max_cutoff_index, max_cutoff_index, cutoff_index)
            cutoff_logit = mint.gather(sorted_logits, -1, cutoff_index)

        if kth_logits is not None and cutoff_logit is not None:
            sorted_logits = sorted_logits.masked_fill(sorted_logits < mint.maximum(cutoff_logit, kth_logits),
                                                      self.filter_value)
        elif kth_logits is not None:
            sorted_logits = sorted_logits.masked_fill(sorted_logits < kth_logits, self.filter_value)
        elif cutoff_logit is not None:
            sorted_logits = sorted_logits.masked_fill(sorted_logits < cutoff_logit, self.filter_value)

            # sampling
        return self._do_sampling(sorted_logits, sorted_indices, params)

    def multinomial(self, sorted_prob, sorted_indices, num_samples, seeds):
        random_values = []
        for cur_seed in seeds:
            try:
                np.random.seed(cur_seed)
            except ValueError as e:
                print_log(self.metadata.rank, logger.warning,
                          f'The seed is out of range: {e}. And will use [cur_seed % 2**32] by default.')
                np.random.seed(cur_seed % 2**32)
            random_values.append(np.random.rand(num_samples))
        cdf_matrix = mint.cumsum(sorted_prob, dim=-1)
        selected_ids = mint.searchsorted(cdf_matrix, ms.Tensor(random_values))
        selected_tokens = mint.gather(sorted_indices, -1, selected_ids)
        return selected_tokens

    def clear(self, request_ids: np.ndarray):
        self.processor.delete_configs(request_ids)

    def configure(self, params: SamplingParam):
        if self.metadata.request_ids is None:
            self.metadata.request_ids = np.arange(len(params.do_sample_meta.do_sample_array))
        self.processor.set_batch_configs(self.metadata.request_ids,
                                         params.top_k_meta.top_k_array,
                                         params.top_p_meta.top_p_array,
                                         params.do_sample_meta.do_sample_array,
                                         params.seed_meta.seed_array,
                                         self.metadata.sampling_method)

    def _fusion_topk_topp_sampling(self, logits: ms.Tensor, index: ms.Tensor):
        # In order to support bf16 and avoid poor cast performance on the CPU, logits is casted to fp32 in advance.
        host_dtype = "float32"
        logits = logits.astype(ms.float32).asnumpy()
        index = index.asnumpy()
        logits_addr = logits.ctypes.data
        index_addr = index.ctypes.data

        token_ids_array, _ = self.processor.next_token_chooser(self.metadata.request_ids, logits_addr, index_addr,
                                                               len(self.metadata.request_ids), logits.shape[1],
                                                               self.speed_mode, host_dtype, self.use_approx)
        if self.speed_mode:
            token_ids_array = index[np.arange(index.shape[0]), token_ids_array]
        return logits, token_ids_array

    def _do_sampling(self, sorted_logits: ms.Tensor, sorted_indices: ms.Tensor, params: SamplingParam):
        do_sample_array = params.do_sample_meta.do_sample_array
        do_sample = params.do_sample_meta.do_sample_tensor
        argmax_indices_array = np.squeeze(np.argwhere(np.equal(do_sample_array, 0)), 1)
        argmax_indices = ms.Tensor.from_numpy(argmax_indices_array)
        indices_array = np.where(do_sample_array > 0)[0]
        indices = ms.Tensor.from_numpy(indices_array)
        seed_array = params.seed_meta.seed_array[indices_array]

        sampled_indices = sorted_indices[indices]
        filtered_logits = sorted_logits[indices]
        sampled_probs = mint.nn.functional.softmax(filtered_logits, dim=-1)
        sampled_tokens = self.multinomial(sampled_probs, sampled_indices, 1,
                                          seed_array).squeeze(1)
        tokens = Tensor([-1] * len(do_sample), ms.int64)
        tokens = mint.scatter(tokens, 0, index=indices, src=sampled_tokens)
        if argmax_indices_array.size == 0:
            return sorted_logits, tokens.reshape(-1).asnumpy()

        filtered_indices = sorted_indices[argmax_indices]
        selected_tokens = filtered_indices[:, 0]
        tokens = mint.scatter(tokens, 0, index=argmax_indices, src=selected_tokens)
        return sorted_logits, tokens.reshape(-1).asnumpy()


@register_class('greedy_search')
class GreedySearchLogitsHandler(LogitsHandler):
    def __call__(self, logits: ms.Tensor, params: SamplingParam):
        tokens = mint.argmax(logits, -1)
        return logits, tokens.reshape(-1).asnumpy()
