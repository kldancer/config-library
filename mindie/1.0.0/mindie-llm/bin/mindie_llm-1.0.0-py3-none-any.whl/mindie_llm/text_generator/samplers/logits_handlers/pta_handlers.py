# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import wraps

import numpy as np
import torch
import torch.nn.functional as F

from .logits_handler import LogitsHandler
from ...utils.sampling_metadata import SamplingParam
from ....utils.log.logging import logger, print_log

PTA_HANDLER_REGISTRY = {}


def register_class(name):
    def decorator(cls):
        PTA_HANDLER_REGISTRY[name] = cls

        @wraps(cls)
        def wrapper(*args, **kwargs):
            return cls(*args, **kwargs)
        return wrapper
    return decorator


@register_class('repetition_penalty')
class RepetitionPenaltyLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        repetition_penalty = params.penalty_meta.repetition_penalty
        vocab_size = len(logits[0])
        sequence_tokens_counts = torch.zeros((len(logits), vocab_size + 1),
                                             dtype=torch.int32, device=self.metadata.sequence_ids.device)
        sequence_ids = torch.clamp(self.metadata.sequence_ids, -vocab_size, vocab_size)
        sequence_tokens_counts.scatter_add_(1, sequence_ids, torch.ones_like(sequence_ids))
        sequence_tokens_mask = sequence_tokens_counts[:, :vocab_size] > 0
        try:
            logits = torch.where(sequence_tokens_mask & torch.lt(logits, 0), logits * repetition_penalty,
                                 logits).to(logits.dtype)
            logits = torch.where(sequence_tokens_mask & torch.ge(logits, 0), logits / repetition_penalty,
                                 logits).to(logits.dtype)
        except ZeroDivisionError as e:
            print_log(self.metadata.rank, logger.error, 'repetition penalty cannot be `0`!')
            raise e
        return logits, None


@register_class('frequency_penalty')
class FrequencyPenaltyLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        self.metadata.count_output_tokens()
        logits -= params.penalty_meta.frequency_penalty * self.metadata.output_tokens_counts
        return logits, None


@register_class('presence_penalty')
class PresencePenaltyLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        self.metadata.count_output_tokens()
        output_tokens_mask = self.metadata.output_tokens_counts > 0
        logits -= params.penalty_meta.presence_penalty * output_tokens_mask
        return logits, None


@register_class('temperature')
class TemperatureLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        try:
            logits = logits / params.temperature
        except ZeroDivisionError as e:
            print_log(self.metadata.rank, logger.error, 'temperature cannot be `0`!')
            raise e
        return logits, None


@register_class('top_k')
class TopKLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        top_k = params.top_k_meta.top_k_tensor
        disabled_mask = params.top_k_meta.top_k_disabled_mask_tensor
        top_k[disabled_mask] = 0
        filter_value = self.metadata.filter_value
        sorted_logits, _ = torch.sort(logits, descending=True)
        kth_logits_ = torch.gather(sorted_logits, 1, params.top_k_meta.top_k_tensor)
        if disabled_mask is not None and disabled_mask.any():
            kth_logits_.masked_fill_(disabled_mask, filter_value)
        indices_to_remove = logits < kth_logits_
        logits.masked_fill_(indices_to_remove, filter_value)
        return logits, None


@register_class('top_p')
class TopPLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        sorted_logits, sorted_indices = torch.sort(logits, descending=False)
        cumulative_probs = sorted_logits.softmax(dim=-1).cumsum(dim=-1)
        sorted_indices_to_remove = cumulative_probs <= (1 - params.top_p_meta.top_p_tensor)
        sorted_indices_to_remove[..., -self.metadata.min_tokens_to_keep:] = 0
        indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
        logits = logits.masked_fill(indices_to_remove, self.metadata.filter_value)
        return logits, None


@register_class('sampling')
class SamplingLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        do_sample_array = params.do_sample_meta.do_sample_array
        do_sample_tensor = params.do_sample_meta.do_sample_tensor
        indices_array = np.where(do_sample_array > 0)[0]
        indices_tensor = torch.tensor(indices_array).to(logits.device)
        argmax_indices = torch.nonzero(do_sample_tensor == 0).squeeze(1)
        filtered_logits = logits[indices_tensor]
        sampled_probs = F.softmax(filtered_logits, dim=-1)
        sampled_token_ids = self.multinomial(sampled_probs, 1, params.seed_meta.seed_array[indices_array]).squeeze(1)
        token_ids = torch.tensor([-1] * len(do_sample_tensor), device=logits.device)
        token_ids.scatter_(0, indices_tensor, sampled_token_ids)
        filtered_logits = logits[argmax_indices]
        argmax_token_ids = filtered_logits.argmax(dim=-1)
        token_ids.scatter_(0, argmax_indices, argmax_token_ids)
        return logits, token_ids.cpu().numpy()

    @staticmethod
    def multinomial(prob_matrix, num_samples, seeds):
        random_values = []
        for s in seeds:
            s = s.astype(np.int32)
            s = s % np.iinfo(np.int32).max
            np.random.seed(s)
            random_values.append(np.random.rand(num_samples))
        sorted_prob, indices = torch.sort(prob_matrix, descending=True)
        cdf_matrix = torch.cumsum(sorted_prob, dim=-1)
        selected_ids = torch.searchsorted(cdf_matrix, torch.tensor(np.array(random_values)).to(prob_matrix.device))
        selected_token_ids = torch.gather(indices, -1, selected_ids)
        return selected_token_ids


@register_class('greedy_search')
class GreedySearchLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        token_ids = logits.argmax(dim=-1)
        return None, token_ids.cpu().numpy()
