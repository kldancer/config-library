# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Optional, Tuple

import numpy as np

from mindie_llm.utils.tensor import tensor
from ..handler_metadata import HandlerMetadata
from ...utils.sampling_metadata import SamplingParam


class LogitsHandler:
    def __init__(self, metadata: HandlerMetadata):
        self.metadata = metadata

    def __call__(self,
                 logits: tensor.Tensor,
                 params: SamplingParam
                 ) -> Tuple[tensor.Tensor, Optional[np.ndarray]]:
        raise NotImplementedError(
            f"{self.__class__} is abstract, needed to be implemented. "
        )


class LogitsHandlerList(list):
    def __init__(self):
        self.switches = []
        super().__init__()

    def __call__(self,
                 logits: tensor.Tensor,
                 params: SamplingParam
                 ) -> Tuple[tensor.Tensor, np.ndarray]:
        tokens = None
        for i in self.switches:
            logits, tokens = self[i](logits, params)
        return logits, tokens
