# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import wraps

import numpy as np
import torch
import torch_npu
from _cpu_logits_handler import _PostProcessingManager

from .logits_handler import LogitsHandler
from ...utils.sampling_metadata import SamplingParam
from ....utils.env import ENV
from ....utils.log.error_code import ErrorCode
from ....utils.log.logging import logger

CPU_HANDLER_REGISTRY = {}


def register_class(name):
    def decorator(cls):
        CPU_HANDLER_REGISTRY[name] = cls

        @wraps(cls)
        def wrapper(*args, **kwargs):
            return cls(*args, **kwargs)

        return wrapper

    return decorator


@register_class('topk_topp_sampling')
class TopKTopPSamplingLogitsHandler(LogitsHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.processor = _PostProcessingManager.get_instance(self.metadata.num_threads, self.metadata.npu_id)
        self.filter_value = self.metadata.filter_value
        self.speed_mode, self.use_approx = bool(ENV.speed_mode_type & 2), bool(ENV.speed_mode_type & 1)

    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        batch_size = len(self.metadata.request_ids)
        if batch_size != logits.shape[0]:
            message = ('The batch size of request_ids and logits are inconsistent. This may occur if incorrect '
                       'request_ids are provided when calling the sample method of the generator_backend or when '
                       'directly invoking the sampler. Please check the shapes of request_ids and logits before making '
                       'these calls.')
            logger.error(message, ErrorCode.TEXT_GENERATOR_LOGITS_SHAPE_MISMATCH)
            raise ValueError("The batch size of request_ids and logits not equal.")
        logits, index = self.preprocess_top_k(logits, params)
        torch_npu.npu.synchronize()
        logits_addr = logits.data_ptr()
        index_addr = index.data_ptr()
        host_dtype = "float32" if (logits.dtype == torch.float32) else (
            "bfloat16" if (logits.dtype == torch.bfloat16) else "float16")
        token_ids_array, logprobs = self.processor.next_token_chooser(self.metadata.request_ids, logits_addr,
                                                                      index_addr, batch_size, logits.shape[1],
                                                                      self.speed_mode, host_dtype, self.use_approx)
        if self.speed_mode:
            index_array = index.cpu().numpy()
            token_ids_array = index_array[np.arange(index_array.shape[0]), token_ids_array]
        return logprobs, token_ids_array

    def clear(self, request_ids: np.ndarray):
        self.processor.delete_configs(request_ids)

    def configure(self, params: SamplingParam):
        if self.metadata.request_ids is None:
            self.metadata.request_ids = np.arange(len(params.do_sample_meta.do_sample_array))
        self.processor.set_batch_configs(self.metadata.request_ids,
                                         params.top_k_meta.top_k_array,
                                         params.top_p_meta.top_p_array,
                                         params.do_sample_meta.do_sample_array,
                                         params.seed_meta.seed_array,
                                         self.metadata.sampling_method)

    def preprocess_top_k(self, logits: torch.Tensor, params: SamplingParam):
        if params.top_k_meta.max_top_k > 0:
            k_logits, index = torch.topk(logits, params.top_k_meta.max_top_k)
            kth_logits = torch.gather(k_logits, 1, params.top_k_meta.top_k_tensor)
            if params.top_k_meta.top_k_disabled_mask_tensor is not None:
                kth_logits.masked_fill_(params.top_k_meta.top_k_disabled_mask_tensor, self.filter_value)
                indices_to_remove = logits < kth_logits
                logits.masked_fill_(indices_to_remove, self.filter_value)
                logits, index = torch.sort(logits, descending=True)
            else:
                logits = k_logits
        else:
            logits, index = torch.sort(logits, descending=True)
        return logits, index
