# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from dataclasses import dataclass
from typing import Literal
import math

import numpy as np

from ...modeling.backend_type import BackendType


@dataclass
class HandlerMetadata:
    output_ids = None
    sequence_ids = None

    output_tokens_counts = None

    backend_type: str = None
    batch_size: int = 0
    device: str = 'npu'
    filter_value = -math.inf
    min_tokens_to_keep = 1
    num_threads: int = 8
    npu_id: int = 0
    rank: int = 0
    request_ids: np.ndarray = None
    sampling_method: Literal['exponential', 'multinomial'] = 'multinomial'
    vocab_size: int = 0

    def count_output_tokens(self):
        if self.output_tokens_counts is None:
            if self.backend_type == BackendType.ATB:
                import torch
                output_tokens_counts = torch.zeros((self.batch_size, self.vocab_size + 1),
                                                   dtype=torch.int32, device=self.output_ids.device)
                output_tokens_counts.scatter_add_(1, self.output_ids, torch.ones_like(self.output_ids))
                self.output_tokens_counts = output_tokens_counts[:, :self.vocab_size]
            elif self.backend_type == BackendType.MS:
                import mindspore as ms
                from mindspore import ops
                output_tokens_counts = ops.zeros((self.batch_size, self.vocab_size + 1), dtype=ms.int32)
                if self.output_ids is not None:
                    output_tokens_counts = ops.tensor_scatter_elements(output_tokens_counts, self.output_ids,
                                                                       ops.ones_like(self.output_ids), 1)
                self.output_tokens_counts = output_tokens_counts[:, :self.vocab_size]

    def clear_tokens_counts(self):
        self.output_tokens_counts = None
