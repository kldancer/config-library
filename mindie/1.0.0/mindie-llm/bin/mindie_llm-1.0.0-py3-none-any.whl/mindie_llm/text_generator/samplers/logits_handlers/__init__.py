# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from .logits_handler import LogitsHandler, LogitsHandlerList
from ...utils.config import HandlingBackend


def get_handler_registry(handling_backend):
    if handling_backend == HandlingBackend.ATB:
        from .atb_handlers import ATB_HANDLER_REGISTRY
        return ATB_HANDLER_REGISTRY
    elif handling_backend == HandlingBackend.CPU:
        from .cpu_handlers import CPU_HANDLER_REGISTRY
        return CPU_HANDLER_REGISTRY
    elif handling_backend == HandlingBackend.PTA:
        from .pta_handlers import PTA_HANDLER_REGISTRY
        return PTA_HANDLER_REGISTRY
    elif handling_backend == HandlingBackend.MS:
        from .ms_handlers import MS_HANDLER_REGISTRY
        return MS_HANDLER_REGISTRY
    else:
        raise NotImplementedError(
            f'{handling_backend} not implemented, supported backends `atb/cpu/pta/ms`')
