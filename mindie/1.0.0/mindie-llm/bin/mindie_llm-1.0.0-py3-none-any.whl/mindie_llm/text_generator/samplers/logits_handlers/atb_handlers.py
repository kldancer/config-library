# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from functools import wraps
import json

import torch
import torch.nn.functional as F

from .logits_handler import LogitsHandler
from ...utils.sampling_metadata import SamplingParam

ATB_HANDLER_REGISTRY = {}


def register_class(name):
    def decorator(cls):
        ATB_HANDLER_REGISTRY[name] = cls
        
        @wraps(cls)
        def wrapper(*args, **kwargs):
            return cls(*args, **kwargs)
        return wrapper
    return decorator


@register_class('topk_topp_sampling')
class TopKTopPSamplingLogitsHandler(LogitsHandler):
    def __call__(self, logits: torch.Tensor, params: SamplingParam):
        if params.top_k_meta.top_k_tensor is None:
            params.top_k_meta.top_k_tensor = torch.full((logits.shape[0], 1), logits.shape[1]).to(logits.device) - 1
        top_k = params.top_k_meta.top_k_tensor + 1
        if params.top_k_meta.top_k_disabled_mask_tensor is not None:
            top_k[params.top_k_meta.top_k_disabled_mask_tensor] = self.metadata.vocab_size
        top_k = top_k.to(torch.int32)
        if params.top_p_meta.top_p_tensor is None:
            params.top_p_meta.top_p_tensor = torch.full((logits.shape[0], 1), 1, dtype=torch.float16).to(logits.device)
        top_p = params.top_p_meta.top_p_tensor.to(torch.float16)
        random_seeds = params.seed_meta.seed_array.tolist()
        param = json.dumps({'randSeeds': random_seeds, 'topkToppSamplingType': 1})
        operation = torch.classes.OperationTorch.OperationTorch('TopkToppSamplingOperation')
        operation.set_param(param)

        logits = logits.to(torch.float16)
        probs = F.softmax(logits)
        tokens, _ = operation.execute([probs, top_k, top_p])
        return logits, tokens.squeeze(1).cpu().numpy()
