# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import numpy as np

from .handler_metadata import HandlerMetadata
from .logits_handlers import LogitsHandlerList, get_handler_registry
from ..utils.config import SamplerConfig, HandlingBackend
from ..utils.sampling_metadata import SamplingData, SamplingParam


class Sampler:
    def __init__(self, sampler_config: SamplerConfig):
        self.backend_type = sampler_config.backend_type
        self.handling_policy = sampler_config.handling_policy
        self.npu_id = sampler_config.npu_id
        self.num_threads = sampler_config.num_threads
        self.rank = sampler_config.rank

        self.batch_input_ids = None
        self.batch_input_ids_tensor = None
        self.batch_output_ids = None
        self.batch_output_ids_tensor = None
        self.batch_size = 0

        self.handler_data = HandlerMetadata(backend_type=self.backend_type, num_threads=self.num_threads,
                                            npu_id=self.npu_id, rank=self.rank)
        self.handlers = LogitsHandlerList()
        self.need_configuring = False
        self.params_cache = None
        self.valid_params = {}

        self.__set_handlers()
        self.handlers.switches = [self.valid_params.get('greedy_search')]

    def __call__(
        self,
        batch_logits,
        batch_sampling_data: SamplingData,
        batch_sampling_params: SamplingParam
    ):
        if batch_sampling_params != self.params_cache:
            self.params_cache = batch_sampling_params
            self.handler_data.batch_size, self.handler_data.vocab_size = batch_logits.shape
            self.switch_handlers(batch_sampling_data, batch_sampling_params)

        if batch_sampling_data is not None:
            self.handler_data.output_ids = batch_sampling_data.output_ids
            self.handler_data.sequence_ids = batch_sampling_data.all_input_ids

        if self.backend_type == HandlingBackend.MS:
            from mindspore.common.api import _pynative_executor as ms_pyexecutor
            ms_pyexecutor.set_async_for_graph(True)
            batch_logits, next_tokens = self.handlers(batch_logits, batch_sampling_params)
            ms_pyexecutor.sync()
            ms_pyexecutor.set_async_for_graph(False)
        else:
            batch_logits, next_tokens = self.handlers(batch_logits, batch_sampling_params)
        self.handler_data.clear_tokens_counts()
        return batch_logits, next_tokens

    def clear_cache(self, request_ids: np.ndarray):
        if self.need_configuring:
            self.handlers[-2].clear(request_ids)

    def switch_handlers(self, batch_sampling_data, batch_sampling_params):
        if batch_sampling_params is None:
            self.handlers.switches = [self.valid_params.get('greedy_search')]
        else:
            self.handlers.switches = []
            self.__check_and_append(batch_sampling_params.penalty_meta.repetition_penalty, 'repetition_penalty')
            self.__check_and_append(batch_sampling_params.penalty_meta.frequency_penalty, 'frequency_penalty')
            self.__check_and_append(batch_sampling_params.penalty_meta.presence_penalty, 'presence_penalty')

            if batch_sampling_params.do_sample_meta.do_sample_tensor is not None:
                self.__check_and_append(batch_sampling_params.temperature, 'temperature')
                fusion_sampling = self.valid_params.get('topk_topp_sampling')
                if not fusion_sampling:
                    self.__check_and_append(batch_sampling_params.top_k_meta.top_k_tensor, 'top_k')
                    self.__check_and_append(batch_sampling_params.top_p_meta.top_p_tensor, 'top_p')
                    self.handlers.switches.append(self.valid_params.get('sampling'))
                else:
                    self.handler_data.request_ids = batch_sampling_data.request_ids
                    if self.need_configuring and batch_sampling_data.is_prefill:
                        self.handlers[-2].configure(batch_sampling_params)
                    self.handlers.switches.append(self.valid_params.get('topk_topp_sampling'))
            else:
                self.handlers.switches.append(self.valid_params.get('greedy_search'))

    def __check_and_append(self, parameter, parameter_name):
        if parameter is not None:
            self.handlers.switches.append(self.valid_params.get(parameter_name))

    def __find_handler(self, parameter_name):
        handling_backend = self.handling_policy.get(parameter_name)
        if not handling_backend:
            raise ValueError(f'The current policy config does not support this parameter: {parameter_name}!')
        backend_registry = get_handler_registry(handling_backend)
        if not backend_registry:
            raise ValueError(f'No such handler backend: {handling_backend}!')
        parameter_handler_cls = backend_registry.get(parameter_name)
        if not parameter_handler_cls:
            raise ValueError(f'The backend {handling_backend} does not have such handler: {parameter_name}!')
        return parameter_handler_cls

    def __set_handlers(self):
        valid_params = ['repetition_penalty', 'frequency_penalty', 'presence_penalty', 'temperature']
        fusion_sampling_key = 'topk_topp_sampling'
        sampling_backend = self.handling_policy.get(fusion_sampling_key)
        if sampling_backend == HandlingBackend.PTA:
            valid_params.append('top_k')
            valid_params.append('top_p')
            valid_params.append('sampling')
        elif sampling_backend == HandlingBackend.ATB:
            valid_params.append(fusion_sampling_key)
        else:
            valid_params.append(fusion_sampling_key)
            self.need_configuring = True

        valid_params.append('greedy_search')
        for param_name in valid_params:
            parameter_handler_cls = self.__find_handler(param_name)
            self.handlers.append(parameter_handler_cls(self.handler_data))
        self.valid_params = {param: idx for idx, param in enumerate(valid_params)}
