# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from .generator_backend import parse_config, ParseType
from ...modeling.backend_type import BackendType
from ...utils.log.error_code import ErrorCode
from ...utils.log.logging import logger


def get_generator_backend(model_config):
    backend_type = model_config.get('backend_type', None)
    if backend_type == BackendType.ATB:
        from .generator_torch import GeneratorTorch
        generator_cls = GeneratorTorch
    elif backend_type == BackendType.MS:
        from .generator_ms import GeneratorMS
        generator_cls = GeneratorMS
    else:
        message = ('Unsupported backend type. The `backend_type` field only supports either "atb" or "ms". If you are '
                   'using a service framework, please modify its configuration file to ensure the `backend_type` '
                   'parameter passed to the `Generator` is correct. Such files are typically located in '
                   'conf/config.json or a similar path. Note that this parameter must be consistent with the '
                   'environment variable `MINDIE_LLM_FRAMEWORK_BACKEND`.')
        logger.error(message, ErrorCode.TEXT_GENERATOR_GENERATOR_BACKEND_INVALID)
        raise NotImplementedError(f'{backend_type} not implemented, '
                                  f'supported backends `{BackendType.__members__.values()}`')
    return generator_cls(model_config)
