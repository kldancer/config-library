# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

__all__ = ['GeneratorTorch']

import gc
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

import torch
from .generator_backend import GeneratorBackend, MAX_KEY_LENGTH
from .torch_utils.cache_pool import CachePool
from ..plugins import InferenceType
from ..utils.input import ModelInput
from ...utils.decorators.time_decorator import timer
from ...utils.log.logging import logger
from ...utils.log.error_code import ErrorCode


def reorder_array(array: np.ndarray, order: List[int], axis: int = 0, position: List[int] = None):
    if array is None or len(array) == 0:
        return array
    if position is None:
        position = []
    pos_len = len(position)
    order_len = len(order)
    group_count = pos_len if pos_len > 0 else order_len
    if order_len == 0 or order == range(group_count):
        return array
    tensor_group = np.split(array, position if pos_len > 0 else group_count, axis=axis)
    tensor_group = [tensor_group[idx] for idx in order]
    return np.concatenate(tensor_group, dtype=array.dtype, axis=axis)


def reorder_tensor(tensor: torch.Tensor, order: List[int], dim: int = 0, position: List[int] = None):
    if position is None:
        position = []
    pos_len = len(position)
    order_len = len(order)
    group_count = pos_len if pos_len > 0 else order_len
    if order_len == 0 or order == range(group_count):
        return tensor
    tensor_group = torch.split(tensor, position if pos_len > 0 else tensor.size(dim) // order_len)
    tensor_group = [tensor_group[idx] for idx in order]
    return torch.concat(tensor_group).reshape_as(tensor)


def check_model_config(model_config):
    model_name = model_config.get('model_name')
    if model_name is not None and (len(model_name) < 1 or len(model_name) > MAX_KEY_LENGTH):
        message = "The length of `model_name` should be in range of [1, 256]. " \
            "If you are using MindIE as a service framework, " \
            "`model_name` is loaded from $BackendConfig.ModelDeployConfig.ModelConfig.modelName " \
            "in ${MIES_INSTALL_PATH}/conf/config.json."
        logger.error(message, ErrorCode.TEXT_GENERATOR_PARAM_OUT_OF_RANGE)
        raise ValueError(message)

    inference_mode = model_config.get('inference_mode')
    if inference_mode is not None and inference_mode not in \
        [InferenceType.REGRESSION, InferenceType.SPECULATE, InferenceType.SPLITFUSE, InferenceType.PREFIXCACHE]:
        message = "`inference_mode` must be among choice [0, 1, 2, 3]. " \
            "If you are using MindIE as a service framework, " \
            "`inference_mode` is derived from $BackendConfig.ModelDeployConfig.ModelConfig.plugin_params " \
            "in ${MIES_INSTALL_PATH}/conf/config.json."
        logger.error(message, ErrorCode.TEXT_GENERATOR_PARAM_OUT_OF_RANGE)
        raise ValueError(message)

    max_position_embeddings = model_config.get('max_position_embeddings')
    if max_position_embeddings is not None and max_position_embeddings <= 0:
        message = "`max_position_embeddings` must be greater than 0. " \
            "If you are using MindIE as a service framework, " \
            "`max_position_embeddings` is derived from " \
            "$BackendConfig.ModelDeployConfig.ModelConfig.max_position_embeddings " \
            "in ${MIES_INSTALL_PATH}/conf/config.json."
        logger.error(message, ErrorCode.TEXT_GENERATOR_PARAM_OUT_OF_RANGE)
        raise ValueError(message)


class GeneratorTorch(GeneratorBackend):
    """The interface class for using `torch` backend.

    The interface class exposed to third-party service frameworks in scenarios where the `torch` backend is used. It
    mainly provides forward inference and sampling functions. Its sampling function is implemented by the `sample`
    method of the base class `GeneratorBackend`.

    Attributes:
        cache_pool: A pool used for storing the kv cache.

    Args:
        model_config: A dictionary containing the model configuration as detailed in
            `mindie_llm.text_generator.utils.config.ModelConfig`.
    """
    cache_pool: CachePool = None

    def __init__(self, model_config: Dict[str, Any]) -> None:
        super().__init__(model_config)
        check_model_config(model_config)

        self.tokenizer = self.model_wrapper.tokenizer
        self.device = self.model_wrapper.device
        self.rank = self.model_wrapper.rank
        self.adapter_manager = self.model_wrapper.adapter_manager

    def to_tensor(self, data):
        return torch.tensor(data, device=self.device)

    def forward_tensor(
        self,
        input_ids: torch.Tensor,
        position_ids: torch.Tensor,
        is_prefill: bool,
        kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
        block_tables: torch.Tensor,
        slots: torch.Tensor,
        input_lengths: torch.Tensor,
        max_seq_len: int,
        lm_head_indices: Optional[torch.Tensor] = None,
        **kwargs
    ):
        """Call the `forward_tensor` of `model_wrapper`."""
        adapter_ids = kwargs.get("adapter_ids")
        batch_size = input_lengths.shape[0]
        if adapter_ids is not None and len(adapter_ids) > batch_size:
            message = "The length of `adapter_ids` should not be larger than batch size."
            logger.error(message, ErrorCode.TEXT_GENERATOR_INTERNAL_ERROR)
            raise ValueError(message)
        logits = self.model_wrapper.forward_tensor(
            input_ids=input_ids,
            position_ids=position_ids,
            is_prefill=is_prefill,
            kv_cache=kv_cache,
            block_tables=block_tables,
            slots=slots,
            input_lengths=input_lengths,
            max_seq_len=max_seq_len,
            lm_head_indices=lm_head_indices,
            **kwargs,
        )
        return logits

    @timer.track_time('forward')
    def forward(self, model_inputs: ModelInput, **kwargs):
        """
        Preprocess the inputs involving multi-lora, and pass the processed inputs to the model
        wrapper for forward inference.
        """
        # sort input by adapter_ids
        do_reorder_requests = False
        revert_adapter_idx = []
        adapter_ids = model_inputs.adapter_ids
        if adapter_ids is not None and self.adapter_manager is not None:
            do_reorder_requests, revert_adapter_idx = self._sort_model_inputs_by_adapter_ids(model_inputs)
        logits = self.model_wrapper.forward(model_inputs, self.cache_pool.npu_cache, **kwargs)
        # sort logits back to the original order (related to lm_head_indices)
        if do_reorder_requests:
            logits = reorder_tensor(logits, revert_adapter_idx)
        return logits

    def update_cache_policy(self, cache_manager):
        self.cache_pool = CachePool(cache_manager, self.device)
        self.cache_pool.allocate_cpu_cache()
        self.cache_pool.allocate_npu_cache()

    def clear_cache(self):
        del self.cache_pool
        torch.npu.empty_cache()
        gc.collect()

    def swap_cache(self, swap_decision):
        swap_decision_tensor = torch.tensor(swap_decision, dtype=torch.int64, device=self.device)
        self.cache_pool.swap_cache(swap_decision_tensor)

    def update_cache_after_switch_pd_role(self):
        self.cache_pool.allocate_npu_cache()

    def warm_up(self, model_inputs: ModelInput, **kwargs) -> None:
        inference_mode = kwargs.get('inference_mode', None)

        if inference_mode == InferenceType.SPLITFUSE:
            q_lens = model_inputs.context_length.tolist()
            super().warm_up(model_inputs, q_lens=q_lens)
        elif inference_mode == InferenceType.PREFIXCACHE:
            q_lens = model_inputs.context_length.tolist()
            kv_device = self.model_wrapper.device
            kv_dtype = self.model_wrapper.model_info.dtype
            attn_mask = self.model_wrapper.model_runner.model.attn_mask.get_attn_mask(
                model_inputs.max_seq_len, kv_dtype, kv_device)
            if attn_mask[0][1] > 0:
                attn_mask = attn_mask * - 10000.0
            req_mask_list = []
            for _, q_len in enumerate(q_lens):
                req_mask = attn_mask[0: q_len]
                req_mask_list.append(req_mask)
            spec_mask = torch.cat(req_mask_list, dim=0)
            model_inputs.is_prefill = False
            super().warm_up(model_inputs, q_lens=q_lens, spec_mask=spec_mask)
        else:
            super().warm_up(model_inputs)

    def _sort_model_inputs_by_adapter_ids(self, model_inputs):
        adapter_ids = model_inputs.adapter_ids
        batch_size = model_inputs.context_length.shape[0]
        if len(adapter_ids) > batch_size:
            message = "The length of `adapter_ids` should not be larger than batch size."
            logger.error(message, ErrorCode.TEXT_GENERATOR_INTERNAL_ERROR)
            raise ValueError(message)
        effective_adapter_ids = self.adapter_manager.preprocess_adatper_ids(
            adapter_ids, model_name=self.model_wrapper.model_name, model_id=self.model_wrapper.model_id)
        if len(effective_adapter_ids) == 1:
            model_inputs.adapter_ids = effective_adapter_ids
            return False, []
        if self.adapter_manager.check_adapter_ids_is_sorted(effective_adapter_ids):
            return False, []
        sorted_adapter_idx, revert_adapter_idx = self.adapter_manager.sort_adapter_ids(effective_adapter_ids)

        input_lengths_origin = model_inputs.context_length.cumsum()
        split_batch_group = input_lengths_origin.tolist() if model_inputs.is_prefill else []
        model_inputs.adapter_ids = [effective_adapter_ids[idx] for idx in sorted_adapter_idx]
        model_inputs.input_ids = reorder_array(
            model_inputs.input_ids, sorted_adapter_idx, position=split_batch_group)
        model_inputs.position_ids = reorder_array(
            model_inputs.position_ids, sorted_adapter_idx, position=split_batch_group)
        model_inputs.slots = reorder_array(
            model_inputs.slots, sorted_adapter_idx, position=split_batch_group)
        model_inputs.block_tables = reorder_array(model_inputs.block_tables, sorted_adapter_idx)
        model_inputs.context_length = reorder_array(model_inputs.context_length, sorted_adapter_idx)
        if model_inputs.prefill_head_indices is not None:
            lm_head_indices_check = input_lengths_origin - 1
            if np.array_equal(model_inputs.prefill_head_indices, lm_head_indices_check):
                model_inputs.prefill_head_indices = model_inputs.context_length.cumsum() - 1
            else:
                logger.warning("prefill_head_indices passed through model_inputs "
                               "is not consistent with context_length")

        return True, revert_adapter_idx