# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Any, Dict, Optional

import mindspore as ms
import numpy as np

from .generator_backend import GeneratorBackend
from ..utils.input import ModelInput
from ...utils.env import ENV


class GeneratorMS(GeneratorBackend):
    """The interface class for using `mindspore` backend.

    The interface class exposed to third-party service frameworks in scenarios where the `mindspore` backend is used. It
    mainly provides forward inference and sampling functions. Its sampling function is implemented by the `sample`
    method of the base class `GeneratorBackend`.

    Args:
        model_config: A dictionary containing the model configuration as detailed in
            `mindie_llm.text_generator.utils.config.ModelConfig`.
    """
    swap_func: Optional[callable] = None

    def __init__(self, model_config: Dict[str, Any]) -> None:
        super().__init__(model_config)
        plugin_name = 'plugin_params'
        self.plugin_params = model_config[plugin_name] if plugin_name in model_config else None
        self.tokenizer = self.model_wrapper.tokenizer
        self.max_position_embeddings = self.model_wrapper.max_position_embeddings

    @staticmethod
    def _set_q_lens(is_speculative_decoding, **kwargs):
        if is_speculative_decoding is False:
            return kwargs
        kwargs['q_lens'] = 1
        return kwargs

    @staticmethod
    def _set_spec_mask(is_speculative_decoding, plugin_type, **kwargs):
        if is_speculative_decoding is False:
            return kwargs

        if plugin_type == 'la':
            kwargs['spec_mask'] = np.zeros((1, 1))

            return kwargs
        kwargs['spec_mask'] = np.zeros((1, 2049))
        return kwargs

    def to_tensor(self, data):
        return ms.Tensor(data) if data.size > 0 else None

    def update_cache_policy(self, cache_manager):
        """The method for updating the kv cache, which is used in warm-up stage."""
        if cache_manager.sepd_worker is None:
            return
        use_mb_swapper = ENV.use_mb_swapper
        if use_mb_swapper and len(cache_manager.sepd_worker.addrs) != 1:
            return
        if not use_mb_swapper and len(cache_manager.sepd_worker.addrs) <= 1:
            return

        if use_mb_swapper:
            kv_cache_addr_offset = 0
            for i in range(self.model_wrapper.model_runner.num_layers):
                key_cache, value_cache = self.model_wrapper.model_runner.model.kvcache(i)
                key_cache.set_device_address(cache_manager.sepd_worker.addrs[0] + kv_cache_addr_offset,
                                             key_cache.shape, key_cache.dtype)
                kv_cache_addr_offset += cache_manager.num_npu_blocks * cache_manager.mini_block_bytes
                key_cache.set_device_address(cache_manager.sepd_worker.addrs[0] + kv_cache_addr_offset,
                                             value_cache.shape, value_cache.dtype)
                kv_cache_addr_offset += cache_manager.num_npu_blocks * cache_manager.mini_block_bytes
        else:
            for i in range(self.model_wrapper.model_runner.num_layers):
                key_cache, value_cache = self.model_wrapper.model_runner.model.kvcache(i)
                key_cache.set_device_address(cache_manager.sepd_worker.addrs[i * 2],
                                             key_cache.shape, key_cache.dtype)
                value_cache.set_device_address(cache_manager.sepd_worker.addrs[i * 2 + 1],
                                               value_cache.shape, value_cache.dtype)

    def clear_cache(self):
        pass

    def update_cache_after_switch_pd_role(self):
        pass

    def swap_cache(self, swap_decision):
        self.model_wrapper.swap_cache(swap_decision)

    def warm_up(self, model_inputs, **kwargs):
        """The warm-up method customized for mindspore."""
        # warm up prefill
        self.forward(model_inputs)
        ms.hal.synchronize()
        plugin_type = self._get_plugin_type()
        # warm up decode
        is_speculative_decoding = True if (plugin_type == "memory_decoding" or plugin_type == "prefix_cache" or
                                           plugin_type == "la") else False
        model_inputs = ModelInput(input_ids=np.array([[1]], np.int64),
                                  position_ids=np.array([1]) if is_speculative_decoding else None,
                                  block_tables=np.array([[0]], np.int32),
                                  slots=np.array([0], np.int32),
                                  context_length=[1],
                                  max_seq_len=0,
                                  prefill_head_indices=None,
                                  is_prefill=False)
        kwargs = self._set_params(is_speculative_decoding, plugin_type)
        self.forward(model_inputs, **kwargs)
        ms.hal.synchronize()

    def _get_plugin_type(self):
        if not self.plugin_params:
            plugin_config = {}
        else:
            import json
            plugin_config = json.loads(self.plugin_params)
        return plugin_config['plugin_type'] if 'plugin_type' in plugin_config else None

    def _set_params(self, is_speculative_decoding, plugin_type):
        kwargs = {}
        kwargs = self._set_q_lens(is_speculative_decoding, **kwargs)
        kwargs = self._set_spec_mask(is_speculative_decoding, plugin_type, **kwargs)
        return kwargs
