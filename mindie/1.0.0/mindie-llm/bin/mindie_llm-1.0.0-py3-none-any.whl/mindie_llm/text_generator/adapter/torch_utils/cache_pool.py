# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import List, Tuple
import torch
import torchair

from ....utils.log.logging import logger
from ....utils.env import ENV
if ENV.use_mb_swapper:
    from _memory_bridge import _Swapper
    MBSWAPPER = _Swapper.get_instance()


class CachePool:
    def __init__(self, cache_manager, device):
        self.npu_cache: List[Tuple[torch.Tensor, torch.Tensor]] = []
        self.cpu_cache: List[Tuple[torch.Tensor, torch.Tensor]] = []

        self.num_layers = cache_manager.num_layers
        self.k_head_size = cache_manager.k_head_size
        self.v_head_size = cache_manager.v_head_size
        self.block_shape = cache_manager.block_shape
        self.k_block_shape = cache_manager.k_block_shape
        self.v_block_shape = cache_manager.v_block_shape
        self.dtype = cache_manager.dtype
        self.num_cpu_blocks = cache_manager.num_cpu_blocks
        self.mini_block_bytes = cache_manager.mini_block_bytes
        self.k_mini_block_bytes = cache_manager.k_mini_block_bytes
        self.v_mini_block_bytes = cache_manager.v_mini_block_bytes

        self.num_npu_blocks = cache_manager.num_npu_blocks
        self.device = device

        self.cpu_row_bytes = cache_manager.cpu_row_bytes
        self.npu_row_bytes = cache_manager.npu_row_bytes

        self.total_h2d_swap_count = 0
        self.total_d2h_swap_count = 0
        swap_func_mapping = {
            'MB': self.sync_swap_mb,
            'BASE': self.sync_swap_base
        }
        self.sepd_worker = cache_manager.sepd_worker
        if self.sepd_worker is not None and self.k_head_size != self.v_head_size:
            raise ValueError(f"Prefill-decode disaggregation does not handle the situation "
                             f"when the size of k head is not equal to the size of v head. "
                             f"The size of k head is {self.k_head_size}. The size of v head is {self.v_head_size}.")
        self.use_mb_swapper = ENV.use_mb_swapper
        self.cpu_blocks_addrs = []
        if self.use_mb_swapper:
            if self.k_head_size != self.v_head_size:
                raise ValueError(f"Memory bridge swapper does not handle the situation "
                                 f"when the size of k head is not equal to the size of v head. "
                                 f"The size of k head is {self.k_head_size}. The size of v head is {self.v_head_size}.")
            logger.debug(">>>You are using mb swapper.")
            self.npu_blocks_addrs = []  # 各个block的 K起始地址和V起始地址 [(k0,v0),(k1,v1),...]
            self.cpu_blocks_addrs = []  # 各个block的 K起始地址和V起始地址 [(k0,v0),(k1,v1),...]
            self.swapper = MBSWAPPER  # 初始化kv cache的swapper
            self.swap_cache = swap_func_mapping.get('MB')
        else:
            logger.debug(">>>You are using torch swapper.")
            self.swap_cache = swap_func_mapping.get('BASE')

    def allocate_cpu_cache(self):
        if self.use_mb_swapper:
            raw_blocks = torch.empty(
                size=(self.num_layers, 2, self.num_cpu_blocks, *self.block_shape),
                dtype=self.dtype,
            ).pin_memory()
            logger.debug(f"raw_blocks: {raw_blocks.shape}, {raw_blocks.dtype}, {raw_blocks.device}")

            # 更新各个block的首miniblock地址列表(cache矩阵的首行，各列地址差值为 self.mini_block_bytes)
            for j in range(self.num_cpu_blocks):
                self.cpu_blocks_addrs.append(
                    (raw_blocks.data_ptr() + j * self.mini_block_bytes,
                     raw_blocks.data_ptr() + (j + self.num_cpu_blocks) * self.mini_block_bytes))

            # 更新self.cpu_cache，新方案的各行的K和V仍然为全局连续，K为偶数行，V为奇数行
            for i in range(self.num_layers):
                key_blocks = raw_blocks[i][0]
                value_blocks = raw_blocks[i][1]
                self.cpu_cache.append((key_blocks, value_blocks))
        else:
            for _ in range(self.num_layers):
                key_blocks = torch.empty(
                    size=(self.num_cpu_blocks, *self.k_block_shape),
                    dtype=self.dtype,
                ) if self.k_head_size > 0 else torch.empty((1,), dtype=self.dtype)
                value_blocks = torch.empty(
                    size=(self.num_cpu_blocks, *self.v_block_shape),
                    dtype=self.dtype,
                ) if self.v_head_size > 0 else torch.empty((1,), dtype=self.dtype)
                self.cpu_cache.append((key_blocks, value_blocks))
                self.cpu_blocks_addrs.append(key_blocks.data_ptr())
                self.cpu_blocks_addrs.append(value_blocks.data_ptr())
        if self.sepd_worker is not None:
            self.sepd_worker.set_cpu_cache(self.cpu_blocks_addrs)

    def allocate_npu_cache(self):
        self.npu_cache.clear()
        if self.use_mb_swapper:
            if self.sepd_worker is not None:
                raw_blocks = torchair.llm_datadist.create_npu_tensors(self.sepd_worker.get_cache_desc().shape,
                                                    self.dtype, self.sepd_worker.get_addrs())[0]
            else:
                raw_blocks = torch.empty(
                    size=(self.num_layers, 2, self.num_npu_blocks, *self.block_shape),
                    dtype=self.dtype,
                    device=self.device,
                )
            logger.debug(f"raw_blocks: {raw_blocks.shape}, {raw_blocks.dtype}, {raw_blocks.device}")

            # 更新各个block的首miniblock地址列表(cache矩阵的首行，各列地址差值为 self.mini_block_bytes)
            for j in range(self.num_npu_blocks):
                self.npu_blocks_addrs.append(
                    (raw_blocks.data_ptr() + j * self.mini_block_bytes,
                     raw_blocks.data_ptr() + (j + self.num_npu_blocks) * self.mini_block_bytes,))

            # 更新self.npu_cache，新方案的各行的K和V仍然为全局连续，K为偶数行，V为奇数行
            for i in range(self.num_layers):
                key_blocks = raw_blocks[i][0]
                value_blocks = raw_blocks[i][1]
                self.npu_cache.append((key_blocks, value_blocks))

        else:
            if self.sepd_worker is not None:
                kv_tensors = torchair.llm_datadist.create_npu_tensors(self.sepd_worker.get_cache_desc().shape,
                                                    self.dtype, self.sepd_worker.get_addrs())
                for i in range(self.num_layers):
                    self.npu_cache.append((kv_tensors[2 * i], kv_tensors[2 * i + 1]))
            else:
                for _ in range(self.num_layers):
                    key_blocks = torch.empty(
                        size=(self.num_npu_blocks, *self.k_block_shape),
                        dtype=self.dtype,
                        device=self.device,
                    ) if self.k_head_size > 0 else torch.empty((1,), dtype=self.dtype, device=self.device)
                    value_blocks = torch.empty(
                        size=(self.num_npu_blocks, *self.v_block_shape),
                        dtype=self.dtype,
                        device=self.device,
                    ) if self.v_head_size > 0 else torch.empty((1,), dtype=self.dtype, device=self.device)
                    self.npu_cache.append((key_blocks, value_blocks))

    def sync_swap_mb(self, swap_decision_tensor):
        # `swap_decision_tensor是一组swap请求，每个请求有三个分量：in/out、srcBlockId、dstBlockId
        if self.sepd_worker is not None:
            raise Exception("SeparateDeploymentEngine not support mb_swarper")
        params = [self.cpu_row_bytes, self.npu_row_bytes, self.mini_block_bytes, self.num_layers]
        for decision in swap_decision_tensor:
            kind = int(decision[0].item())
            if kind == 0:  # swap in
                cpu_key_block_addr = self.cpu_blocks_addrs[decision[1]][0]
                npu_key_block_addr = self.npu_blocks_addrs[decision[2]][0]
                cpu_value_block_addr = self.cpu_blocks_addrs[decision[1]][1]
                npu_value_block_addr = self.npu_blocks_addrs[decision[2]][1]
                self.swapper.h2d_swap(cpu_key_block_addr, npu_key_block_addr, params)
                self.swapper.h2d_swap(cpu_value_block_addr, npu_value_block_addr, params)
                self.total_h2d_swap_count += 1
            elif kind == 1:
                npu_key_block_addr = self.npu_blocks_addrs[decision[1]][0]
                cpu_key_block_addr = self.cpu_blocks_addrs[decision[2]][0]
                npu_value_block_addr = self.npu_blocks_addrs[decision[1]][1]
                cpu_value_block_addr = self.cpu_blocks_addrs[decision[2]][1]
                self.swapper.d2h_swap(cpu_key_block_addr, npu_key_block_addr, params)
                self.swapper.d2h_swap(cpu_value_block_addr, npu_value_block_addr, params)
                self.total_d2h_swap_count += 1
            else:
                continue

    def sync_swap_base(self, swap_decision_tensor):
        if self.sepd_worker is not None: 
            self.pd_sep_swap(swap_decision_tensor)
            return
        swap_cnt = 0
        for decision in swap_decision_tensor:
            logger.debug("[CacheManager]\t>>> Swap direction %s from %s to %s", decision[0], decision[1], decision[2])
            if decision[0] == 0 or decision[0] == 1:
                swap_cnt += 1
            else:
                continue
            for i in range(self.num_layers):
                device_key: torch.Tensor = self.npu_cache[i][0]
                device_value: torch.Tensor = self.npu_cache[i][1]
                host_key: torch.Tensor = self.cpu_cache[i][0]
                host_value: torch.Tensor = self.cpu_cache[i][1]

                src, dst = decision[1], decision[2]
                decision_type = decision[0]
                if decision_type == 1:
                    # swap out
                    device_block_no = src
                    host_block_no = dst

                    if self.k_head_size > 0:
                        tmp_k = device_key[device_block_no, ...]
                        host_key[host_block_no, ...] = tmp_k

                    if self.v_head_size > 0:
                        tmp_v = device_value[device_block_no, ...]
                        host_value[host_block_no, ...] = tmp_v
                elif decision_type == 0:
                    # swap in
                    device_block_no = dst
                    host_block_no = src

                    if self.k_head_size > 0:
                        tmp_k = host_key[host_block_no, ...]
                        device_key[device_block_no, ...] = tmp_k

                    if self.v_head_size > 0:
                        tmp_v = host_value[host_block_no, ...]
                        device_value[device_block_no, ...] = tmp_v
                else:
                    continue

    def pd_sep_swap(self, swap_decision_tensor):
        d2h_block_ids = {}
        h2d_block_ids = {}
        for decision in swap_decision_tensor:
            if decision[0] == 0:
                h2d_block_ids[int(decision[1])] = int(decision[2])
            elif decision[0] == 1:
                d2h_block_ids[int(decision[1])] = int(decision[2])
            else:
                continue
        self.sepd_worker.swap_out(d2h_block_ids)
        self.sepd_worker.swap_in(h2d_block_ids)