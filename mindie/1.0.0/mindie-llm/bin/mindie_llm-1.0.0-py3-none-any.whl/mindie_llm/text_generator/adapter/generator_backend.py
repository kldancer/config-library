# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import json
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from ..samplers.sampler import Sampler
from ..utils.config import SamplerConfig
from ..utils.input import ModelInput
from ..utils.sampling_metadata import SamplingData, SamplingParam
from ...modeling.model_wrapper import get_model_wrapper
from ...utils.decorators.time_decorator import timer

MAX_WORLD_SIZE = 1048576
MAX_KEY_LENGTH = 256


class ParseType(int, Enum):
    TO_STR = 0
    TO_INT = 1
    TO_FLOAT = 2
    TO_BOOL = 3
    TO_JSON = 4


MODEL_CONFIG_KEY_TYPE = {
    "load_tokenizer": ParseType.TO_BOOL,
    "max_position_embeddings": ParseType.TO_INT,
    "max_sequence_length": ParseType.TO_INT,
    "max_seq_len": ParseType.TO_INT,
    "bos_token_id": ParseType.TO_INT,
    "eos_token_id": ParseType.TO_JSON,
    "pad_token_id": ParseType.TO_INT,
    "cpu_mem": ParseType.TO_INT,
    "npu_mem": ParseType.TO_INT,
    "block_size": ParseType.TO_INT,
    "temperature": ParseType.TO_FLOAT,
    "top_k": ParseType.TO_INT,
    "top_p": ParseType.TO_FLOAT,
    "typical_p": ParseType.TO_FLOAT,
    "do_sample": ParseType.TO_BOOL,
    "seed": ParseType.TO_INT,
    "repetition_penalty": ParseType.TO_FLOAT,
    "frequency_penalty": ParseType.TO_FLOAT,
    "presence_penalty": ParseType.TO_FLOAT,
    "watermark": ParseType.TO_BOOL,
    "length_penalty": ParseType.TO_FLOAT
}


def parse_config(model_config, item_name, required=False, parse_type=ParseType.TO_STR, default_value=None):
    value = model_config.get(item_name)
    if value is None:
        if required:
            raise ValueError(f"model_config: `{item_name}` is required, but not set")
        if default_value is not None:
            value = default_value
    elif parse_type == ParseType.TO_INT:
        value = int(value)
    elif parse_type == ParseType.TO_FLOAT:
        value = float(value)
    elif parse_type == ParseType.TO_BOOL:
        value = value is True or value == 'true' or value == '1'
    elif parse_type == ParseType.TO_JSON:
        value = json.loads(value)
    return value


class GeneratorBackend:
    """The base class for a generator backend.

    This class provides basic implementation of forward inference and sampling. All methods here can be overridden by
    subclasses, so it should not be instantiated directly.

    Args:
        model_config: A dictionary containing the model configuration as detailed in
            `mindie_llm.text_generator.utils.config.ModelConfig`.
    """

    def __init__(self, model_config: Dict[str, Any]) -> None:
        backend_type = parse_config(model_config, 'backend_type', required=True)
        num_threads = parse_config(model_config, 'num_threads', parse_type=ParseType.TO_INT, default_value=8)
        npu_device_id = parse_config(model_config, 'npu_device_id', required=True, parse_type=ParseType.TO_INT)
        local_rank = parse_config(model_config, 'local_rank', required=True, parse_type=ParseType.TO_INT)
        self.rank = parse_config(model_config, 'rank', required=True, parse_type=ParseType.TO_INT)
        self.world_size = parse_config(model_config, 'world_size', required=True, parse_type=ParseType.TO_INT)
        self.trust_remote_code = parse_config(model_config, 'trust_remote_code', required=True,
                                              parse_type=ParseType.TO_BOOL, default_value=False)

        if self.world_size < 1 or self.world_size > MAX_WORLD_SIZE:
            raise ValueError("World size should be in the range of 1 to 1048576.")
        if self.rank < 0 or self.rank >= self.world_size:
            raise ValueError("Rank should be in the range of 0 to world_size - 1.")
        if local_rank < 0 or local_rank >= self.world_size:
            raise ValueError("Local rank should be in the range of 0 to world_size - 1.")

        self.__parse_config_key(model_config)

        model_config["rank"] = self.rank
        model_config["world_size"] = self.world_size
        model_config['npu_device_id'] = npu_device_id
        model_config['local_rank'] = local_rank

        self.backend_type = backend_type
        self.model_wrapper = get_model_wrapper(model_config, backend_type)
        self.config = self.model_wrapper.config
        self.config_dict = self.model_wrapper.config_dict
        self.update_config(model_config)
        self.model_info = self.model_wrapper.model_info

        sampler_config = SamplerConfig(
            backend_type=backend_type,
            npu_id=npu_device_id,
            num_threads=num_threads,
            rank=self.rank
        )
        self.sampler = Sampler(sampler_config)

        self.max_position_embeddings = self.model_wrapper.max_position_embeddings

    @staticmethod
    def __parse_config_key(model_config):
        for key, value in MODEL_CONFIG_KEY_TYPE.items():
            if key in model_config:
                model_config[key] = parse_config(model_config, key, parse_type=value)

    def build_inputs(self, conversations: List[List[Dict[str, str]]], **kwargs) -> List[List[int]]:
        return [self.model_wrapper.make_context(conversation, **kwargs) for conversation in conversations]

    def update_config(self, kwargs):
        for key, value in kwargs.items():
            if key in self.config_dict.keys():
                setattr(self.config, key, value)

    @timer.track_time('forward')
    def forward(self, model_inputs: ModelInput, **kwargs) -> Any:
        """Call the `forward` method of the model wrapper, which should return a Tensor of corresponding backend."""
        logits = self.model_wrapper.forward(model_inputs, **kwargs)
        return logits

    @timer.track_time('sample')
    def sample(
        self,
        logits: Any,
        sampling_data: SamplingData,
        sampling_param: SamplingParam
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Call the sampler of mindie-llm.

        This method samples from the input logits based on the post-processing parameters and selects the token ids.

        Args:
            logits: A Tensor of corresponding backend. It is the output obtained from the model's forward propagation.
            sampling_data: Some sampling metadata like input and out token ids.
            sampling_param: Some sampling parameters like penalty, temperature, top_k and top_p, etc.

        Returns:
            next_tokens: A numpy array of the next tokens' ids.
            logits_or_logprobs: A numpy array of the logits (for greedy search) or the log-probability (for multinomial
                sampling) of the chosen tokens. Note that it would be a `None` if all sequences in the batch do greedy
                search.
        """
        logits_or_logprobs, next_tokens = self.sampler(logits, sampling_data, sampling_param)
        return next_tokens, logits_or_logprobs

    def warm_up(self, model_inputs: ModelInput, **kwargs) -> None:
        """Warm-up without anything returned."""
        _ = self.forward(model_inputs, **kwargs)
