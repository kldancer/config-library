# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import math
import queue
from typing import Any, Dict, List, Tuple, Union

import numpy as np

from .adapter import get_generator_backend, parse_config, ParseType
from .plugins import get_plugin, get_inference_mode, InferenceType, PluginParameterValidator
from .utils.cache_manager import CacheManager, calc_npu_mem, calc_block_mem
from .utils.config import CacheConfig, ModelConfig
from .utils.input_manager import InputManager
from .utils.input_metadata import InputMetadata
from .utils.request import Request
from ..utils.decorators.time_decorator import timer
from ..utils.env import ENV
from ..utils.error import MindieLlmErrorCode
from ..utils.log.error_code import ErrorCode
from ..utils.log.logging import logger, print_log
from ..utils.tensor import npu


class Generator:
    """A class for generating tokens using a large language model.

    The primary interface class. Upper-level applications can create instances of the `Generator` to perform actions
    such as warm-up and token generation.

    Args:
        model_config: A dictionary or `ModelConfig` instance containing model configuration parameters. Refer to the
            definition of `ModelConfig` for the specific meaning of each parameter.
    """

    def __init__(self, model_config: Union[Dict[str, Any], ModelConfig]) -> None:
        if isinstance(model_config, ModelConfig):
            model_config = vars(model_config)
        self.model_config = model_config
        self.cpu_mem = parse_config(model_config, 'cpu_mem', required=True, parse_type=ParseType.TO_INT)
        self.npu_mem = parse_config(model_config, 'npu_mem', required=True, parse_type=ParseType.TO_INT)
        self.block_size = parse_config(model_config, 'block_size', required=True, parse_type=ParseType.TO_INT)
        max_seq_len = parse_config(model_config, 'max_seq_len', required=True, parse_type=ParseType.TO_INT)
        max_iter_times = parse_config(model_config, 'max_iter_times', required=True, parse_type=ParseType.TO_INT)
        max_input_len = parse_config(model_config, 'max_input_len', required=True, parse_type=ParseType.TO_INT)
        max_prefill_tokens = parse_config(model_config, 'max_prefill_tokens', required=True,
                                          parse_type=ParseType.TO_INT)
        ignore_eos = parse_config(model_config, 'ignore_eos', parse_type=ParseType.TO_BOOL)
        tokenizer_sliding_window_size = parse_config(model_config, 'tokenizer_sliding_window_size',
                                                     parse_type=ParseType.TO_INT, default_value=2)
        self.trust_remote_code = parse_config(model_config, 'trust_remote_code', required=True,
                                              parse_type=ParseType.TO_BOOL, default_value=False)

        self.model_role = model_config.get('model_role', 'standard')
        self.local_model_instance_id = model_config.get('local_model_instance_id', None)
        self.remote_model_instance_ids = model_config.get('remote_model_instance_ids', [])
        self.local_device_ip = model_config.get('local_device_ip', None)
        self.remote_device_ips = model_config.get('remote_device_ips', '').split(',')
        self.pd_sepd_npu_port = model_config.get('pd_sepd_npu_port', '1234')
        self.local_device_id = model_config.get('npu_device_id', None)
        self.device_inited = False
        self.separate_deployment_worker = None
        if self.npu_mem != -1:
            self._init_sepd_engine(self.npu_mem)
        self.input_metadata_queue = queue.Queue()

        plugin_params = parse_config(model_config, 'plugin_params')
        speculation_gamma = parse_config(model_config, 'speculation_gamma', parse_type=ParseType.TO_INT)
        validator = PluginParameterValidator(speculation_gamma)
        plugin_config = validator.validate(plugin_params)
        model_config['inference_mode'] = get_inference_mode(plugin_config)
        inference_mode = model_config['inference_mode']

        self.backend_type = parse_config(model_config, 'backend_type', required=True, default_value='atb')
        self.rank = parse_config(model_config, 'rank', required=True, parse_type=ParseType.TO_INT)
        self.world_size = parse_config(model_config, 'world_size', required=True, parse_type=ParseType.TO_INT)
        self.local_rank = parse_config(model_config, 'local_rank', required=True, parse_type=ParseType.TO_INT)
        self.is_mix_model = True if inference_mode == InferenceType.SPLITFUSE else False

        self.generator_backend = get_generator_backend(model_config)
        self.model_wrapper = self.generator_backend.model_wrapper
        self.sampler = self.generator_backend.sampler
        self.model_info = self.generator_backend.model_info
        self.tokenizer = self.generator_backend.tokenizer
        self.max_position_embeddings = self.generator_backend.max_position_embeddings
        self.to_tensor = self.generator_backend.to_tensor
        self.vocab_size = self.model_wrapper.config.vocab_size

        self.cache_config = CacheConfig(
            ignore_eos=ignore_eos,
            max_block_size=self.block_size,
            max_gen_len=min(max_iter_times, max_seq_len),
            max_seq_len=max_seq_len,
            model_wrapper_config=self.model_wrapper.config,
            rank=self.rank,
            tokenizer_sliding_window_size=tokenizer_sliding_window_size
        )
        self.cache_manager = None
        if getattr(self.model_wrapper.config, 'eos_token_id', None) is not None:
            self.cache_config.eos_token_id = self.model_wrapper.config.eos_token_id
        elif getattr(self.tokenizer, 'eos_token_id', None) is not None:
            self.cache_config.eos_token_id = self.tokenizer.eos_token_id

        if getattr(self.model_wrapper.config, 'pad_token_id', None) is not None:
            self.cache_config.pad_token_id = self.model_wrapper.config.pad_token_id
        elif getattr(self.tokenizer, 'pad_token_id', None) is not None:
            self.cache_config.pad_token_id = self.tokenizer.pad_token_id
        self.cache_config.pad_token_id = np.clip(int(self.cache_config.pad_token_id), -1, self.vocab_size)

        if self.backend_type == 'atb':
            lora_adapter = self.model_wrapper.model_runner.lora_adapter
            if lora_adapter is not None and inference_mode == InferenceType.SPLITFUSE:
                message = ("SplitFuse is not supported when LoRA is enabled!"
                           " If you want to enable SplitFuse only, please ensure that there is no file"
                           " named 'lora_adapter.json' in the model path. Or if LoRA is exactly what you need,"
                           " try to clear 'plugin_params' and to make sure 'templateType' is 'Standard'.")
                logger.error(message, ErrorCode.TEXT_GENERATOR_FEAT_COMPAT_INVALID)
                raise NotImplementedError(message)

        self.warm_up(max_prefill_tokens, max_seq_len, max_input_len, max_iter_times, inference_mode)

        self.input_manager = InputManager(self.model_wrapper, self.cache_config, self.cache_manager,
                                          self.tokenizer, self.to_tensor)
        self.plugin = get_plugin(plugin_config, self.generator_backend, self.cache_manager, self.input_manager)

    def __del__(self):
        if self.separate_deployment_worker is not None:
            self.separate_deployment_worker.finalize()

    def build_inputs(self, conversations: List[List[Dict[str, str]]], **kwargs) -> List[List[int]]:
        """Convert the multi-turn dialogues of all requests in a batch into token ids based on the template."""
        return [self.model_wrapper.make_context(conversation, **kwargs) for conversation in conversations]

    def generate_token(self, input_metadata: InputMetadata) -> Tuple[np.ndarray, np.ndarray, bool, np.ndarray]:
        """The core method for generating token ids.

        The key method called by the `BatchScheduler`, used for one iteration of generating token ids for a batch. Each
        iteration can be divided into four stages: preprocessing, forward propagation, sampling, and stop-checking. The
        handling of these stages may vary depending on the different plugins configured.

        Args:
            input_metadata: The input metadata constructed by the `BatchScheduler` includes request data such as input
                ids, post-processing parameters, etc.
        """
        try:
            if self.model_role == 'decoder' and not input_metadata.is_prefill and not self.input_metadata_queue.empty():
                while not self.input_metadata_queue.empty():
                    input_metadata_pass = self.input_metadata_queue.get()
                    cached_idx = self.input_manager.save_input_cache(input_metadata_pass)
                    self.input_manager.concatenate(input_metadata_pass, cached_idx, False, True)

            if self.model_wrapper.generate_token_enable:
                tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids = (
                    self.model_wrapper.generate_token(input_metadata))
            else:
                if self.plugin:
                    tokens, eos_np, stop_generate, truncation_indices, token_indices, request_ids = (
                        self.plugin.generate_token(input_metadata))
                else:
                    raise NotImplementedError('plugin not implemented')

            if ENV.benchmark_enable and request_ids is not None:
                timer.log_time(self.rank, request_ids, token_indices)

            max_request_token = max([len(x) for x in tokens])
            token_len_np = np.zeros(len(tokens), dtype=np.int64)
            for request_id, token in enumerate(tokens):
                token_len_np[request_id] = len(token)
                token.extend([0] * (max_request_token - len(token)))
            request_tokens_np = np.asarray(tokens, dtype=np.int64)
            eof_np = np.copy(np.array([eos_np, token_len_np], dtype=np.int64).T, order='C')
            res_and_stop = (request_tokens_np, eof_np, stop_generate, truncation_indices)
        except NotImplementedError as e:
            print_log(self.rank, logger.error, f'Something not implemented: {e}')
            for rid in input_metadata.batch_request_ids:
                self.input_manager.clear_cache(rid, self.sampler)
            raise e
        except Exception as e:
            print_log(self.rank, logger.error, f'Unknown exception: {e}')
            for rid in input_metadata.batch_request_ids:
                self.input_manager.clear_cache(rid, self.sampler)
            raise e
        return res_and_stop

    def generate(self, requests: List[Request], is_prefill: bool = False
                 ) -> Tuple[np.ndarray, np.ndarray, bool, np.ndarray]:
        """Generate token ids using `Request`."""
        block_tables = np.asarray([request.block_tables for request in requests])
        input_metadata = InputMetadata.from_requests(requests, block_tables, is_prefill)
        res_and_stop = self.generate_token(input_metadata)
        return res_and_stop

    def prefill(self, requests: List[Request]) -> Tuple[np.array, np.array, bool, np.array]:
        """Generate token ids using `Request` of prefilling stage."""
        return self.generate(requests, is_prefill=True)

    def decode(self, requests: List[Request]) -> Tuple[np.array, np.array, bool, np.array]:
        """Generate token ids using `Request` of decoding stage."""
        return self.generate(requests, is_prefill=False)

    def pull_kv(self, input_metadata: InputMetadata, p_d_infos: List[Tuple[int, List[int], List[int]]]
                ) -> Tuple[MindieLlmErrorCode, int]:
        """Pull kv cache from a remote model instance."""
        if not self.device_inited:
            npu.set_device(int(self.local_device_id))
            self.device_inited = True
        for x in p_d_infos:
            rt = self.separate_deployment_worker.pull_blocks(remote_model_instance_id=x[0],
                                                             src_block_table=x[1], dst_block_table=x[2])
            if rt != MindieLlmErrorCode.SUCCESS:
                return rt, x[0]
        self.input_metadata_queue.put(input_metadata)
        return MindieLlmErrorCode.SUCCESS, 0

    def link(self, remote_device_ip: str, remote_cluster_id: int, time_out: int = 6000) -> MindieLlmErrorCode:
        """Create a link with another device."""
        return self.separate_deployment_worker.link(remote_device_ip, remote_cluster_id, time_out)

    def unlink(self, remote_device_ip: str, remote_cluster_id: int = -1, time_out: int = 6000) -> MindieLlmErrorCode:
        """Destroy the link with another device."""
        return self.separate_deployment_worker.unlink(remote_device_ip, remote_cluster_id, time_out)

    def switch_role(self, role: str, local_device_ip: str = '') -> None:
        """Change the role of current device under p-d separation deployment."""
        self.separate_deployment_worker.switch_role(role, local_device_ip)
        self.cache_manager.rebuild_sepd_worker()
        self.generator_backend.update_cache_after_switch_pd_role()
        self.model_role = role

    def seq_ctrl(self, request_ids: List[int]) -> List[int]:
        """Clear the cache of certain requests according to their request ids."""
        logger.debug(f"[Model]\t>>> rank-{self.rank} enter seqctrl")
        rets = []
        for request_id in request_ids:
            logger.debug(f"[Model]\t>>> rank-{self.rank} seqctrl request {request_id}")
            ret = self.input_manager.clear_cache(request_id, self.sampler)
            rets.append(ret)
        return rets

    def generate_mix(self, requests: List[Request], is_prefill_batch: np.ndarray
                     ) -> Tuple[np.ndarray, np.ndarray, bool, np.ndarray]:
        """Generate token ids using `Request` under splitfuse scenario."""
        block_tables = np.asarray([request.block_tables for request in requests])
        input_metadata = InputMetadata.from_requests_mix(requests, block_tables, is_prefill_batch)
        res_and_stop = self.generate_token(input_metadata)
        return res_and_stop

    def warm_up(
            self,
            max_prefill_tokens: int = 4096,
            max_seq_len: int = 2560,
            max_input_len: int = 1,
            max_iter_times: int = 2560,
            inference_mode: InferenceType = 0
    ) -> None:
        """Warm-up to ensure normal performance.

        Since the performance during the first inference may be impacted by the initialization of certain objects, we
        simulate an inference as a warm-up. In addition, when `npu_mem` is set to -1, the warm-up will also calculate an
        optimal npu memory size for the kv cache based on the memory usage of the NPU during the simulated inference.

        Args:
            max_prefill_tokens: The maximum limit of the sum of tokens in a batch to prefill.
            max_seq_len: The maximum sequence length of the model.
            max_input_len: The maximum input length set by configuration.
            max_iter_times: The maximum number of iterations. It can also be considered as the max output length.
            inference_mode: The inference mode which can be one of the enum class `InferenceType`.

        Raises:
            RuntimeError: Setting the above-mentioned upper limit parameters too large, or setting `NPU_MEMORY_FRACTION`
                too large, could lead to an OOM (Out of Memory) exception.
        """
        if self.npu_mem == -1:
            npu.synchronize()
            peak_memory = npu.max_memory_allocated()
            total_memory = npu.get_device_properties(self.local_rank).total_memory
            print_log(self.rank, logger.debug,
                      f'before prefill, peak_memory: {peak_memory}, total_memory: {total_memory}')
            block_mem_size = calc_block_mem(self.model_info, self.block_size)
            total_blocks = int((total_memory * ENV.memory_fraction - peak_memory) // block_mem_size)

            prefill_reqs, block_tables, prefill_blocks = self._get_warm_up_reqs(total_blocks, max_prefill_tokens,
                                                                                max_seq_len, max_input_len,
                                                                                max_iter_times)
            input_metadata = InputMetadata.from_requests(prefill_reqs, block_tables, True, self.block_size)

            num_prefill_blocks = 1

            prefill_npu_mem = calc_npu_mem(num_prefill_blocks, self.model_info, self.block_size)
            prefill_npu_mem_gb = prefill_npu_mem / 1024 / 1024 / 1024
            print_log(self.rank, logger.info,
                      f'`Prefill blocks` during warmup needs npu memory(GB): {prefill_npu_mem_gb}')
            self.cache_manager = CacheManager(self.rank, self.model_info, self.separate_deployment_worker,
                                              self.cpu_mem, prefill_npu_mem_gb, self.block_size, self.backend_type)
            self.generator_backend.update_cache_policy(self.cache_manager)
            try:
                self._generate_inputs_warm_up_backend(input_metadata, inference_mode, dummy=True)
            except RuntimeError as e:
                if str(e).startswith('NPU out of memory'):
                    print_log(self.rank,
                              logger.error,
                              'Warmup failed, because of model inference out of memory when `npuMemSize` set to -1.'
                              'please try to decrease `max_prefill_tokens`')
                raise e

            npu.synchronize()
            peak_memory = npu.max_memory_allocated()
            total_memory = npu.get_device_properties(self.local_rank).total_memory
            print_log(self.rank, logger.debug,
                      f'after prefill, peak_memory: {peak_memory}, total_memory: {total_memory}')

            del self.cache_manager
            self.generator_backend.clear_cache()

            total_blocks = int(
                (total_memory * ENV.memory_fraction - peak_memory) // block_mem_size) + num_prefill_blocks
            npu_mem = calc_npu_mem(total_blocks, self.model_info, self.block_size) / 1024 / 1024 / 1024
            if self.model_role == 'prefill' or self.model_role == 'decoder':
                from .utils.separate_deployment_engine import WORKSPACE_SIZE
                npu_mem = npu_mem - WORKSPACE_SIZE / 1024 / 1024 / 1024
                self._init_sepd_engine(npu_mem)
            print_log(self.rank, logger.info, f'`Total blocks` needs npu memory(GB): {npu_mem}')
            self.cache_manager = CacheManager(self.rank, self.model_info, self.separate_deployment_worker,
                                              self.cpu_mem, npu_mem, self.block_size, self.backend_type)
            try:
                self.generator_backend.update_cache_policy(self.cache_manager)
            except RuntimeError as e:
                if str(e).startswith('Trying to create tensor with negative dimension'):
                    print_log(self.rank,
                              logger.error,
                              'Warmup failed, because of model inference out of memory when `npuMemSize` set to -1.'
                              'please try to increase the environment value `NPU_MEMORY_FRACTION`'
                              ' or decrease `max_prefill_tokens`')
                    raise e

            npu.synchronize()
            peak_memory = npu.max_memory_allocated()
            print_log(self.rank, logger.debug,
                      f'after warmup, peak_memory: {peak_memory}, total_memory: {total_memory}')
        else:
            self.cache_manager = CacheManager(self.rank, self.model_info, self.separate_deployment_worker,
                                              self.cpu_mem, self.npu_mem, self.block_size, self.backend_type)
            prefill_reqs, block_tables, prefill_blocks = self._get_warm_up_reqs(self.cache_manager.num_npu_blocks,
                                                                                max_prefill_tokens, max_seq_len,
                                                                                max_input_len, max_iter_times)
            input_metadata = InputMetadata.from_requests(prefill_reqs, block_tables, True, self.block_size)
            self.generator_backend.update_cache_policy(self.cache_manager)
            try:
                self._generate_inputs_warm_up_backend(input_metadata, inference_mode)
            except RuntimeError as e:
                if str(e).startswith('NPU out of memory'):
                    print_log(self.rank,
                              logger.error,
                              f'Warmup failed,'
                              f'because of model inference out of memory when `npuMemSize` set to {self.npu_mem}.'
                              f'please try to decrease `npuMemSize`')
                raise e

    def swap(self, block_operation: Any) -> None:
        """Operate cache according to the swap decision.

        Args:
            block_operation: Any type can be transferred to the numpy array.
                Its first element should be a swap decision like this: [[decision_id, src_block, dst_block] * n].
                The map of decision ids is: 0 -> swap from cpu to npu; 1 -> swap from npu to cpu; 2 -> recompute.
        """
        swap_decision = np.array(block_operation, copy=False)[0]
        for decision in swap_decision:
            if int(decision[0]) == 2:
                self.input_manager.clear_cache(int(decision[1]), self.sampler)
        self.generator_backend.swap_cache(swap_decision)

    def _generate_inputs_warm_up_backend(self, input_metadata: InputMetadata, inference_mode: InferenceType,
                                         dummy=False) -> None:
        input_manager = InputManager(self.model_wrapper, self.cache_config, self.cache_manager, self.tokenizer,
                                     self.to_tensor)
        model_inputs, _, _, _ = input_manager.concatenate(input_metadata, None, True, dummy=dummy)

        self.generator_backend.warm_up(model_inputs, inference_mode=inference_mode)

    def _get_warm_up_reqs(
            self,
            num_blocks,
            max_prefill_tokens=4096,
            max_seq_len=2560,
            max_input_len=1,
            max_iter_times=2560
    ) -> Tuple[List[Request], np.ndarray, List[int]]:
        params_checklist = (max_prefill_tokens, max_seq_len, max_input_len, max_iter_times)
        if not all(isinstance(param, int) for param in params_checklist):
            raise ValueError(f'warmup need all params int type, but got {max_prefill_tokens=}, '
                             f'{max_seq_len=}, {max_input_len=}, {max_iter_times=}')
        print_log(self.rank, logger.info, f'warmup params: {max_prefill_tokens=}, {max_seq_len=}, '
                                          f'{max_input_len=}, {max_iter_times=}')
        max_len = min(max_seq_len, max_input_len + max_iter_times)
        if max_prefill_tokens < max_len:
            max_prefill_tokens = max_len
            print_log(self.rank, logger.warning, '`max_prefill_tokens` is smaller than `max_len`, '
                                                 ' and it will be replaced by `max_len`, '
                                                 '`max_len` = min(max_seq_len, max_input_len + max_iter_times)')
        max_input_length = min(max_seq_len, max_input_len)
        if max_input_length <= 0:
            raise ValueError("max_input_len and max_seq_len should be greater than 0")

        prefill_reqs = []
        prefill_blocks = []
        while max_prefill_tokens > 0:
            input_len = min(max_prefill_tokens, max_len)
            output_len = 0
            if self.block_size == 0:
                raise ZeroDivisionError('self.cache_manager.block_size should be greater than 0')
            num_required_block = math.ceil(input_len / self.block_size)
            if sum(prefill_blocks) + num_required_block > num_blocks:
                print_log(self.rank, logger.warning, 'The `max_prefill_tokens` exceeds what the npu mem can hold.')
                break
            request = Request.from_warmup(input_len, output_len)
            max_prefill_tokens -= input_len
            prefill_blocks.append(num_required_block)
            prefill_reqs.append(request)
        batch_size = len(prefill_reqs)
        if batch_size == 0:
            message = ('Warmup failed. This issue could be caused by setting both `max_prefill_tokens` and '
                       '`max_input_length` to very large values, or setting insufficient `npu_mem`. Reducing either '
                       '`max_prefill_tokens` or `max_input_length` may help resolve this issue. If `npu_mem` is -1, try'
                       ' to increase the environment value `NPU_MEMORY_FRACTION` or `npu_mem` in configuration '
                       'directly. Increase `world_size` can be another choice.')
            logger.error(message)
            raise RuntimeError(message)
        block_tables = np.zeros(batch_size * prefill_blocks[0], dtype=np.int32).reshape(batch_size, -1)
        if prefill_blocks[-1] != prefill_blocks[0]:
            # 最后一个请求长度不满max_seq_len的情况，后面pad -1
            block_tables[-1, prefill_blocks[-1]:] = -1
        return prefill_reqs, block_tables, prefill_blocks

    def _init_sepd_engine(self, npu_mem: int) -> None:
        if self.model_role == 'decoder':
            from .utils.separate_deployment_engine import SeparateDeploymentWorker
            self.separate_deployment_worker = SeparateDeploymentWorker(
                role='decoder',
                npu_size=npu_mem * 1024 * 1024 * 1024,
                local_device_id=self.local_device_id,
                local_cluster_id=self.local_model_instance_id,
                local_device_ip=self.local_device_ip,
                remote_cluster_ids=self.remote_model_instance_ids,
                remote_device_ips=self.remote_device_ips,
                pd_sepd_npu_port=self.pd_sepd_npu_port
            )
        elif self.model_role == 'prefill':
            from .utils.separate_deployment_engine import SeparateDeploymentWorker
            self.separate_deployment_worker = SeparateDeploymentWorker(
                role='prefill',
                npu_size=npu_mem * 1024 * 1024 * 1024,
                local_device_id=self.local_device_id,
                local_cluster_id=self.local_model_instance_id,
                local_device_ip=self.local_device_ip,
                remote_cluster_ids=[], remote_device_ips=[],
                pd_sepd_npu_port=self.pd_sepd_npu_port
            )
