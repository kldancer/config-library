# Copyright Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import math
import numpy as np

from mindie_llm.utils.tensor import tensor, op


def decode_token(req_list, tokenizer, truncation_indices_list):
    decode_res_list = []
    token_num_list = []
    request_id = 0
    token_num = 0
    truncation_indices = np.concatenate(truncation_indices_list)
    for i, req in enumerate(req_list):
        out_token = len(req.out_token_list)
        truncation_idx = truncation_indices[i]
        token_tensor = tensor.tensor(req.out_token_list, dtype=tensor.int64)
        if tokenizer:
            decode_text = tokenizer.decode(token_tensor, skip_special_tokens=req.skip_special_tokens)
            if truncation_idx[0] != 0:
                decode_text = decode_text[:truncation_idx[0]]
            decode_res_list.append(decode_text)
        else:
            decode_res_list.append(token_tensor)
        token_num += out_token
        token_num_list.append((request_id, token_num))
        request_id += 1
    return decode_res_list, token_num_list


class Scheduler:
    def __init__(self, max_batch_size, max_prefill_tokens, generator,
                 load_tokenizer, is_mix_model, split_chunk_tokens, **kwargs):

        self.max_batch_size = max_batch_size
        self.max_prefill_tokens = max_prefill_tokens

        self.generator = generator
        self.tokenizer = self.generator.model_wrapper.tokenizer if load_tokenizer else None
        self.cache_manager = self.generator.cache_manager
        self.input_manager = self.generator.input_manager
        self.free_block_mask = op.ones(self.cache_manager.num_npu_blocks, dtype=tensor.int64)
        self.total_slots = self.cache_manager.slots

        self.is_mix_model = is_mix_model
        self.split_chunk_tokens = split_chunk_tokens
        self.speculation_gamma = kwargs.get('speculation_gamma', 0)

    @staticmethod
    def get_status_by_batch_req_status(batch_req_status):
        is_prefill_batch = np.where(batch_req_status != 2, True, False)
        return is_prefill_batch

    @staticmethod
    def is_mix_batch_judge(batch_req_status):
        batch_size = len(batch_req_status)
        decode_bsnum = np.count_nonzero(batch_req_status == 2)
        last_prefill_bsnum = np.count_nonzero(batch_req_status == 1)
        if ((decode_bsnum == batch_size) or (last_prefill_bsnum == batch_size)):
            return False
        else:
            return True

    def can_batch(self, batch_size, tokens_num, input_tokens_num):
        if batch_size >= self.max_batch_size:
            return False
        if self.max_prefill_tokens and tokens_num > self.max_prefill_tokens:
            return False
        if self.is_mix_model and input_tokens_num >= self.split_chunk_tokens:
            return False
        return True    
    
    def is_not_last_prompt(self, tokens_num, left_token_num):
        if self.is_mix_model is not True:
            return False
        if (left_token_num + tokens_num <= self.split_chunk_tokens):
            return False
        return True

    def get_prefill_requests(self, requests, req_begin_idx=0):
        batch_size = 0
        tokens_num = 0
        prefill_requests = []
        block_tables = []
        begin_idx = min(req_begin_idx, len(requests) - 1)
        end_idx = req_begin_idx
        free_block_idx = 0
        block_len_max = 0
        for i in range(begin_idx, len(requests)):
            if self.can_batch(batch_size, tokens_num, 0):
                req = requests[i]

                batch_size += 1
                max_seq_len = req.max_new_tokens + req.input_length + self.speculation_gamma
                tokens_num += max_seq_len
                if self.cache_manager.block_size == 0:
                    raise ValueError('self.cache_manager.block_size should not be 0.')
                curr_need_blocks = math.ceil(max_seq_len / self.cache_manager.block_size)

                req.block_tables = np.arange(free_block_idx, free_block_idx + curr_need_blocks + 1, dtype=np.int32)
                block_len_max = len(req.block_tables) if len(req.block_tables) > block_len_max else block_len_max
                free_block_idx += curr_need_blocks + 1
                block_tables.append(req.block_tables)
                prefill_requests.append(req)
                end_idx = i
            else:
                break
        block_tables_pad = []
        req_index = 0
        for block_table in block_tables:
            if len(block_table) < block_len_max:
                pad_len = block_len_max - len(block_table)
                block_table = np.pad(block_table, (0, pad_len), 'constant', constant_values=(-1,))
                requests[req_index].block_tables = block_table
            block_tables_pad.append(block_table)
            req_index += 1
        block_tables = np.asarray(block_tables_pad)
        return prefill_requests, block_tables, end_idx

    def generate(self, requests):
        if self.is_mix_model:
            decode_text_list, token_num_list = self.generate_is_mix_model(requests)
            return decode_text_list, token_num_list
        stop_generate = False
        req_begin_idx = 0
        truncation_indices_list = []
        while req_begin_idx < len(requests):
            prefill_requests, _, end_idx = self.get_prefill_requests(requests, req_begin_idx)
            req_begin_idx = end_idx + 1

            if prefill_requests:
                request_tokens_np, eof_np, stop_generate, truncation_indices = self.generator.prefill(prefill_requests)
                for i, prefill_request in enumerate(prefill_requests):
                    prefill_request.out_token_list.extend(list(request_tokens_np[i]))
                truncation_indices_list.append(truncation_indices)

            while not stop_generate:
                request_tokens_np, eof_np, stop_generate, truncation_indices = self.generator.decode(prefill_requests)
                for i, request in enumerate(prefill_requests):
                    idx = eof_np[i][1]
                    out_tokens = request_tokens_np[i][:idx]
                    request.out_token_list.extend(out_tokens)
                truncation_indices_list[-1] = truncation_indices

        decode_text_list, token_num_list = decode_token(requests, self.tokenizer, truncation_indices_list)
        return decode_text_list, token_num_list

    def generate_is_mix_model(self, requests):
        stop_generate = False
        req_begin_idx = 0
        truncation_indices_list = []

        while req_begin_idx < len(requests):
            # step1: 首轮prefill切块以及对应的block_table生成, 同时输出batch_req_status用于记录每一个batch的req状态：
            # 0：prefill切块，1：最后一个prefill切块，2：decode
            prefill_requests, batch_req_status, end_idx, alias_input_ids_list = \
                self.get_fisrt_spf_prefill_requests(requests, req_begin_idx)   

            # step2: prefill_requests存在, 则进行第一轮推理
            if prefill_requests:
                is_prefill_batch = self.get_status_by_batch_req_status(batch_req_status)
                request_tokens_np, eof_np, stop_generate, truncation_indices = \
                    self.generator.generate_mix(prefill_requests, is_prefill_batch)
                for i, request in enumerate(prefill_requests):
                    if batch_req_status[i] == 1:
                        request.out_token_list.extend(list(request_tokens_np[i]))
                truncation_indices_list.append(truncation_indices)

            # step3: mix阶段判断, 始终刷新prefill_requests、batch_req_status
            mix_status = self.is_mix_batch_judge(batch_req_status)
            while (mix_status and (not stop_generate)):
                prefill_requests, batch_req_status = self.get_spf_requests(prefill_requests, 
                                                                           batch_req_status,
                                                                           alias_input_ids_list)
                is_prefill_batch = self.get_status_by_batch_req_status(batch_req_status)
                request_tokens_np, eof_np, stop_generate, truncation_indices = \
                    self.generator.generate_mix(prefill_requests, is_prefill_batch)
                for i, request in enumerate(prefill_requests):
                    if batch_req_status[i] == 1:
                        request.out_token_list.extend(list(request_tokens_np[i]))
                    elif batch_req_status[i] == 2:
                        idx = eof_np[i][1]
                        out_tokens = request_tokens_np[i][:idx]
                        request.out_token_list.extend(out_tokens)
                truncation_indices_list[-1] = truncation_indices
                mix_status = self.is_mix_batch_judge(batch_req_status)

            # step4: 判断是否进入纯decode阶段
            while (not stop_generate):
                is_prefill_batch = [0] * len(is_prefill_batch)
                request_tokens_np, eof_np, stop_generate, truncation_indices = \
                    self.generator.generate_mix(prefill_requests, is_prefill_batch)
                for i, request in enumerate(prefill_requests):
                    idx = eof_np[i][1]
                    out_tokens = request_tokens_np[i][:idx]
                    request.out_token_list.extend(out_tokens)
                truncation_indices_list[-1] = truncation_indices
            req_begin_idx = end_idx + 1

        # step5: 生成输出list
        decode_text_list, token_num_list = decode_token(requests, self.tokenizer, truncation_indices_list)
        return decode_text_list, token_num_list
    
    def get_fisrt_spf_prefill_requests(self, requests, req_begin_idx):
        batch_size = 0
        tokens_num = 0
        input_tokens_num = 0
        prefill_requests = []
        block_tables = []
        batch_req_status = []
        begin_idx = min(req_begin_idx, len(requests) - 1)
        end_idx = req_begin_idx
        free_block_idx = 0
        block_len_max = 0
        alias_input_ids_list = []
        for i in range(begin_idx, len(requests)):
            if self.can_batch(batch_size, tokens_num, input_tokens_num):
                req = requests[i]
                batch_size += 1
                max_seq_len = req.max_new_tokens + req.input_length + self.speculation_gamma
                tokens_num += max_seq_len
                if self.cache_manager.block_size == 0:
                    raise ValueError('self.cache_manager.block_size should not be 0.')
                curr_need_blocks = math.ceil(max_seq_len / self.cache_manager.block_size)
                req.block_tables = np.arange(free_block_idx, free_block_idx + curr_need_blocks + 1, dtype=np.int32)
                block_len_max = len(req.block_tables) if len(req.block_tables) > block_len_max else block_len_max
                free_block_idx += curr_need_blocks + 1
                block_tables.append(req.block_tables)
                alias_input_ids_list.append(requests[i].input_ids)
                if (self.is_not_last_prompt(input_tokens_num, req.input_length)):
                    req.split_start_position = 0
                    req.split_end_position = self.split_chunk_tokens - input_tokens_num
                    req.input_ids = req.input_ids[req.split_start_position:req.split_end_position]
                    req.last_prompt = 0
                    status = 0
                else:
                    req.split_start_position = 0
                    req.split_end_position = req.input_length
                    req.last_prompt = 1
                    status = 1
                input_tokens_num += req.split_end_position - req.split_start_position
                batch_req_status.append(status)
                prefill_requests.append(req)
                end_idx = i
            else:
                break
        batch_req_status = np.array(batch_req_status, dtype=np.int32)    
        batch_result = (prefill_requests, batch_req_status, end_idx, alias_input_ids_list)    
        return batch_result
    
    def get_spf_requests(self, requests, batch_req_status, alias_input_ids_list):
        tokens_num = 0
        for i, req in enumerate(requests):
            if (batch_req_status[i] == 0): # 上一次没有处理到最后一个prefill块
                prefill_len_unprocess = len(alias_input_ids_list[i]) - req.split_end_position
                if (self.is_not_last_prompt(tokens_num, prefill_len_unprocess)):
                    req.split_start_position = req.split_end_position
                    req.split_end_position = req.split_start_position + self.split_chunk_tokens - tokens_num                    
                    req.last_prompt = 0
                else:
                    req.split_start_position = req.split_end_position
                    req.split_end_position = len(alias_input_ids_list[i])
                    req.last_prompt = 1
                    batch_req_status[i] = 1
            elif (batch_req_status[i] == 1): # 上一次是最后一个prefill快
                req.split_start_position = 0
                req.split_end_position = 1
                req.last_prompt = 1
                batch_req_status[i] = 2
            req.input_ids = alias_input_ids_list[i][req.split_start_position:req.split_end_position]
            tokens_num += req.split_end_position - req.split_start_position
            requests[i] = req
        return requests, batch_req_status   
    