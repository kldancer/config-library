# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import functools
import json
import os
import time
import uuid

from ..env import ENV
from ..file_utils import MAX_FILE_SIZE, safe_open
from ..log.logging import logger, prepare_log_path
from ..tensor import npu


class Timer:
    def __init__(self, logger_instance):
        self.logger = logger_instance
        self.time_cache = {}

    def track_time(self, logging_name):
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                if ENV.benchmark_enable:
                    npu.synchronize()
                    start_time = time.time()
                    result = func(*args, **kwargs)
                    npu.synchronize()
                    end_time = time.time()
                    duration = end_time - start_time
                    if self.time_cache.get(logging_name) is None:
                        self.time_cache[logging_name] = [duration]
                    else:
                        self.time_cache[logging_name].append(duration)
                    self.logger.debug(f"{logging_name} took {duration:.6f} seconds to execute")
                    return result
                else:
                    return func(*args, **kwargs)

            return wrapper

        return decorator

    def log_time(self, rank, request_ids, token_indices):
        if rank == 0:
            reserved_lines = None
            prepare_log_path(ENV.benchmark_filepath)
            if os.path.exists(ENV.benchmark_filepath) and os.path.getsize(ENV.benchmark_filepath) > MAX_FILE_SIZE:
                with safe_open(ENV.benchmark_filepath, 'r', encoding='utf-8', max_file_size=2 * MAX_FILE_SIZE) as file:
                    lines = file.readlines()
                    reserved_lines = lines[-int(ENV.benchmark_reserving_ratio * len(lines)):]
                os.remove(ENV.benchmark_filepath)
            batch_id = str(uuid.uuid4())
            time_info = {k: v[-1] * 1000 for k, v in self.time_cache.items()}
            with safe_open(ENV.benchmark_filepath, 'a', encoding='utf-8') as file:
                if reserved_lines is not None:
                    file.writelines(reserved_lines)
                for i, request_id in enumerate(request_ids):
                    token_idx = token_indices[i]
                    request_time_info = {
                        'batch_id': batch_id,
                        'request_id': str(request_id),
                        'token_idx': int(token_idx),
                        'unit': 'ms'
                    }
                    request_time_info.update(time_info)
                    file.write(json.dumps(request_time_info) + '\n')
        self.time_cache = {}


timer = Timer(logger)
