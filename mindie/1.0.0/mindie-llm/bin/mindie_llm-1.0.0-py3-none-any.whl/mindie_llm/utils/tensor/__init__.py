# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.
"""使用样例
from mindie_llm.tensor import tensor, op

tensor.Tensor

operations: 
    op.ones
    op.full

type:
    tensor.int64
    tensor.float32

npu/hal 
    mindspore 中的 torch.npu 等效于 mindspore.hal
    npu.synchronize()
    npu.max_memory_allocated()
    npu.get_device_properties(self.rank).total_memory 
"""

from mindie_llm.utils.tensor.ms_tensor import MindSporeBackend
from mindie_llm.utils.tensor.torch_tensor import TorchBackend
from mindie_llm.utils.tensor.llm_tensor import LLMTensor
from mindie_llm.utils.env import ENV
from mindie_llm.modeling.backend_type import BackendType


def _set_tensor_backend() -> LLMTensor:
    _backend = MindSporeBackend() if ENV.framework_backend == BackendType.MS else TorchBackend()
    return _backend


tensor_backend = _set_tensor_backend()
tensor = tensor_backend.get_backend()
op = tensor_backend.get_op()

npu = tensor_backend.get_npu()
hal = tensor_backend.get_hal()
