# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.

import os
from dataclasses import dataclass


@dataclass
class EnvVar:
    """
    环境变量
    """
    # 模型运行时动态申请现存池大小（单位：GB）
    reserved_memory_gb: int = int(os.getenv("RESERVED_MEMORY_GB", "0"))

    # 使用哪些卡
    visible_devices: str = os.getenv("ASCEND_RT_VISIBLE_DEVICES", None)
    # 是否绑核
    bind_cpu: bool = os.getenv("BIND_CPU", "1") == "1"

    memory_fraction = float(os.getenv("NPU_MEMORY_FRACTION", "0.8"))

    # 是否记录服务化benchmark所需的性能数据
    benchmark_enable = os.getenv("MINDIE_LLM_BENCHMARK_ENABLE", "0") == "1"
    benchmark_filepath = os.getenv("MINDIE_LLM_BENCHMARK_FILEPATH",
                                   os.path.join(os.getenv("MINDIE_LLM_HOME_PATH"), "logs/benchmark.jsonl"))
    benchmark_reserving_ratio = os.getenv("MINDIE_LLM_BENCHMARK_RESERVING_RATIO", 0.1)

    # 日志级别
    log_file_level: str = str(os.getenv("MINDIE_LOG_LEVEL", os.getenv("MIES_PYTHON_LOG_LEVEL", 
                        os.getenv("MINDIE_LLM_PYTHON_LOG_LEVEL", "INFO"))))
    # 日志是否打印
    log_to_file: str = str(os.getenv("MINDIE_LOG_TO_FILE", os.getenv("MIES_PYTHON_LOG_TO_FILE", 
                        os.getenv("MINDIE_LLM_PYTHON_LOG_TO_FILE", "1")))) 
    # 日志路径
    log_file_path: str = str(os.getenv("MINDIE_LOG_PATH", os.getenv("MIES_PYTHON_LOG_PATH", 
                        os.getenv("MINDIE_LLM_PYTHON_LOG_PATH", ""))))
    # 日志是否输出到命令行
    log_to_stdout: str = str(os.getenv("MINDIE_LOG_TO_STDOUT", os.getenv("MIES_PYTHON_LOG_TO_STDOUT", 
                        os.getenv("MINDIE_LLM_PYTHON_LOG_TO_STDOUT", "0"))))
    # 日志最大大小
    log_file_maxsize = int(os.getenv('MINDIE_LLM_PYTHON_LOG_MAXSIZE', "20971520"))
    # 日志最大数量
    log_file_maxnum = int(os.getenv('MINDIE_LLM_PYTHON_LOG_MAXNUM', "10"))
    # 日志可选内容
    log_verbose: str = str(os.getenv("MINDIE_LOG_VERBOSE", 1))

    # 是否开启基于memory bridge 的swapper优化
    use_mb_swapper: bool = os.getenv("MINDIE_LLM_USE_MB_SWAPPER", os.getenv("MIES_USE_MB_SWAPPER", "0")) == "1"

    # 选择后处理加速模式
    speed_mode_type = int(os.getenv("POST_PROCESSING_SPEED_MODE_TYPE", "0"))

    rank: int = int(os.getenv("RANK", "0"))
    local_rank: int = int(os.getenv("LOCAL_RANK", "0"))
    world_size: int = int(os.getenv("WORLD_SIZE", "1"))

    # 模型框架类型， ATB 或者 MS, 默认为ATB
    framework_backend = os.getenv('MINDIE_LLM_FRAMEWORK_BACKEND', "ATB").lower()

    continuous_batching = os.getenv("MINDIE_LLM_CONTINUOUS_BATCHING", "1") == "1"

    performance_prefix_tree = os.getenv("PERFORMANCE_PREFIX_TREE_ENABLE", "0") == "1"

    def __post_init__(self):
        # 校验
        if self.log_file_maxsize < 0 or self.log_file_maxsize > 524288000:
            raise ValueError("MINDIE_LLM_PYTHON_LOG_MAXSIZE should between 0 and 524288000 (500MB), "
                                f"but get {self.log_file_maxsize}.")
        if self.log_file_maxnum < 0 or self.log_file_maxnum > 64:
            raise ValueError("MINDIE_LLM_PYTHON_LOG_MAXNUM should between 0 and 64, "
                                f"but get {self.log_file_maxnum}.")

        if self.reserved_memory_gb >= 64 or self.reserved_memory_gb < 0:
            raise ValueError("RESERVED_MEMORY_GB should be in the range of 0 to 64, 64 is not inclusive.")

        if self.visible_devices is not None:
            try:
                self.visible_devices = list(map(int, self.visible_devices.split(',')))
            except ValueError as e:
                raise ValueError("ASCEND_RT_VISIBLE_DEVICES should be in format "
                                 "{device_id},{device_id},...,{device_id}") from e

        if self.memory_fraction <= 0 or self.memory_fraction > 1.0:
            raise ValueError("NPU_MEMORY_FRACTION should be in the range of 0 to 1.0, 0.0 is not inclusive.")

        if self.world_size < 0:
            raise ValueError("WORLD_SIZE should not be a number less than 0.")
        if self.rank < 0 or self.rank >= self.world_size:
            raise ValueError("RANK should be in the range of 0 to WORLD_SIZE, WORLD_SIZE is not inclusive.")
        if self.local_rank < 0 or self.local_rank >= self.world_size:
            raise ValueError("LOCAL_RANK should be in the range of 0 to WORLD_SIZE, WORLD_SIZE is not inclusive.")


ENV = EnvVar()
