# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from enum import Enum


class MindieLlmErrorCode(Enum):
    SUCCESS = 0
    PD_UNKNOW_ERROR = 203001
    PD_BLOCK_ID_OUT_OF_RANGE = 203002
    PD_MODEL_INSTANCE_ID_ERROR = 203003
    PD_LLM_ENGINE_ERROR = 203004