# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import argparse
import os
import sys
from setuptools import setup

os.environ['SOURCE_DATE_EPOCH'] = '0'

parser = argparse.ArgumentParser(description="Infer Engine Setup Parameters")
parser.add_argument("--setup_cmd", type=str, default="bdist_wheel")
parser.add_argument("--version", type=str, default="1.0.RC1")

args = parser.parse_args()
sys.argv = [sys.argv[0], args.setup_cmd]
infer_engine_version = args.version

setup(
    name='infer_engine',
    version=infer_engine_version,
    description='infer engine sdk',
    packages=['sdk'],
    package_data={
        '':['infer_engine.so']
    },
    include_package_data=True,
    python_requires=">=3.10",
)