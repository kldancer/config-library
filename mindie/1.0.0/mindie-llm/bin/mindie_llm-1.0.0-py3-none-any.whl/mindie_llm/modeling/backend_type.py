# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from enum import Enum


class BackendType(str, Enum):
    ATB = 'atb'
    MS = 'ms'
