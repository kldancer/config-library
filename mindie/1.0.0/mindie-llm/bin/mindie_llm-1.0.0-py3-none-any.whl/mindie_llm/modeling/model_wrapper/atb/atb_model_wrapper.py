# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Dict, List, Optional, Tuple, Iterable

import torch
import numpy as np
from atb_llm.models import InferenceMode
from atb_llm.runner.model_runner import ModelRunner

from ..model_info import ModelInfo
from ..wrapper import ModelWrapper
from ....utils.log.logging import logger


class ATBModelWrapper(ModelWrapper):
    def __init__(self,
                 rank, local_rank, world_size, npu_device_id,  # 部署参数
                 model_id: str,
                 **kwargs,
                 ):
        self.generate_token_enable = False
        self.model_id = model_id
        self.model_name = kwargs.get('model_name')
        self.model_runner = ModelRunner(
            model_name_or_path=model_id,
            rank=rank,
            local_rank=local_rank,
            npu_id=npu_device_id,
            world_size=world_size,
            trust_remote_code=kwargs.get('trust_remote_code', False),
            load_tokenizer=kwargs.get('load_tokenizer', True),
            tokenizer_path=kwargs.get('tokenizer_path', None),
            inference_mode=kwargs.get("inference_mode", InferenceMode.REGRESSION),
            max_position_embeddings=kwargs.get("max_position_embeddings", None),
        )
        self.config = self.model_runner.config
        self.config_dict = self.model_runner.config_dict
        self.tokenizer = self.model_runner.tokenizer
        self.process_group = self.model_runner.process_group
        self.rank = rank
        logger.debug(f">>>rank:{self.rank} distribute, "
                     f"process_group {self.process_group}, size {self.process_group.size()}")
        self.device = self.model_runner.device

        torch.distributed.barrier(group=self.process_group)
        self.model_runner.load_weights()
        torch.distributed.barrier(group=self.process_group)

        self.model_info = ModelInfo(self.model_runner.device,
                                    self.model_runner.kv_cache_dtype,
                                    torch.tensor([], dtype=self.model_runner.kv_cache_dtype).element_size(),
                                    self.model_runner.num_layers,
                                    self.model_runner.num_kv_heads,
                                    self.model_runner.head_size,
                                    k_head_size=self.model_runner.k_head_size,
                                    v_head_size=self.model_runner.v_head_size)
        self.max_position_embeddings = self.model_runner.model.max_position_embeddings
        self.soc_info = self.model_runner.soc_info
        self.adapter_manager = self.model_runner.adapter_manager

    def forward(self, model_inputs, npu_cache=None, **kwargs):
        """
        Refers to a single forward pass through the network.

        Args:
            model_inputs: Inference inputs.
            npu_cache: KV cache tensor on NPU.
            kwargs: If data parallel is enabled, kwargs contains the following additional inputs.
                shard_effective_token_indices: Used for data segmentation. From the token index of all requests
                    arranged by DP group (including dummy data), select token indices for the current DP group.
                token_index_with_padding: Used for data summarization.
                    Token index of the current DP group (containing padding token).
                    Requests of each DP group are uniformly padded to the maximum input length of all requests.
                    Padding token index is represented by 0.
                skip_padding_token_indices: Used to filter padding tokens.
                    Token index of all dp groups (excluding dummy data).

        Returns:
            torch.Tensor: logits.
        """
        input_ids = torch.tensor(model_inputs.input_ids).to(self.device)
        position_ids = torch.tensor(model_inputs.position_ids, dtype=torch.int64).to(self.device)
        block_tables = torch.tensor(model_inputs.block_tables, dtype=torch.int32).to(self.device)
        slots = torch.tensor(model_inputs.slots).to(self.device)
        input_lengths = torch.tensor(model_inputs.context_length).to(self.device)
        lm_head_indices = torch.tensor(
            model_inputs.prefill_head_indices, dtype=torch.int32).to(self.device) \
            if model_inputs.prefill_head_indices is not None else None
        logits = self.forward_tensor(
            input_ids=input_ids,
            position_ids=position_ids,
            is_prefill=model_inputs.is_prefill,
            kv_cache=npu_cache,
            block_tables=block_tables,
            slots=slots,
            input_lengths=input_lengths,
            max_seq_len=model_inputs.max_seq_len,
            lm_head_indices=lm_head_indices,
            adapter_ids=model_inputs.adapter_ids,
            **kwargs,
        )
        return logits

    def forward_tensor(
            self,
            input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs):
        logits = self.model_runner.forward(
            input_ids=input_ids,
            position_ids=position_ids,
            is_prefill=is_prefill,
            kv_cache=kv_cache,
            block_tables=block_tables,
            slots=slots,
            input_lengths=input_lengths,
            max_seq_len=max_seq_len,
            lm_head_indices=lm_head_indices,
            **kwargs,
        )
        return logits

    def generate_position_ids(self, input_ids: np.ndarray) -> Iterable:
        return self.model_runner.generate_position_ids(input_ids)

    def make_context(self, conversation: List[Dict[str, str]], **kwargs):
        return self.model_runner.input_builder.make_context(self.rank, conversation, **kwargs)
