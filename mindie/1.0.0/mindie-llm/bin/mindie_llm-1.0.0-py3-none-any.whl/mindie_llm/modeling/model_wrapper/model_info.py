# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from dataclasses import dataclass
from typing import Any


class ModelInfo:
    device: Any
    dtype: Any
    data_byte_size: int
    num_layers: int
    num_kv_heads: int
    head_size: int
    k_head_size: int
    v_head_size: int


    def __init__(self, device, dtype, data_byte_size, num_layers, num_kv_heads, head_size, **kwargs):
        self.device = device
        self.dtype = dtype
        self.data_byte_size = data_byte_size
        self.num_layers = num_layers
        self.num_kv_heads = num_kv_heads
        self.head_size = head_size
        self.k_head_size = kwargs.get("k_head_size", self.head_size)
        self.v_head_size = kwargs.get("v_head_size", self.head_size)
