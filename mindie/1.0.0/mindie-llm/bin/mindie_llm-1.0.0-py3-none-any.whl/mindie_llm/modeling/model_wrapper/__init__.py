# Copyright Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from ..backend_type import BackendType


def get_model_wrapper(model_config, backend_type):
    if backend_type == BackendType.ATB:
        from .atb.atb_model_wrapper import ATBModelWrapper
        wrapper_cls = ATBModelWrapper
    elif backend_type == BackendType.MS:
        from .ms.mf_model_wrapper import MFModelWrapper
        wrapper_cls = MFModelWrapper
    else:
        raise NotImplementedError(f'{backend_type} not implemented, '
                                  f'supported backends `{BackendType.__members__.values()}`')
    return wrapper_cls(**model_config)


def get_tokenizer_wrapper(model_id: str, backend_type: str, **kwargs):
    if backend_type == BackendType.ATB:
        from .atb.atb_tokenizer_wrapper import ATBTokenizerWrapper
        wrapper_cls = ATBTokenizerWrapper
    elif backend_type == BackendType.MS:
        from .ms.mf_tokenizer_wrapper import MFTokenizerWrapper
        wrapper_cls = MFTokenizerWrapper
    else:
        raise NotImplementedError(f'{backend_type} not implemented, '
                                  f'supported backends `{BackendType.__members__.values()}`')
    return wrapper_cls(model_id, **kwargs)
