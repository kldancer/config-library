# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

from mindformers import get_model


class MFTokenizerWrapper:
    def __init__(self, model_id: str, **kwargs):
        tokenizer, input_builder = get_model(model_id)
        self.tokenizer = tokenizer
        self.input_builder = input_builder
        self.toolscallprocessor = None

    def tokenize(self, inputs, **kwargs):
        return self.tokenizer.tokenize(inputs, **kwargs)