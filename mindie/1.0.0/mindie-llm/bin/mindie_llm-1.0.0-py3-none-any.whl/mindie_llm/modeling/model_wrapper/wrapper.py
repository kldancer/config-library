# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from abc import abstractmethod
from typing import Iterable

import numpy as np


class ModelWrapper:
    @abstractmethod
    def forward(self, model_inputs, npu_cache=None, **kwargs):
        pass

    @abstractmethod
    def generate_position_ids(self, input_ids: np.ndarray) -> Iterable:
        pass
