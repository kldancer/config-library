# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

from atb_llm.runner.tokenizer_wrapper import TokenizerWrapper


class ATBTokenizerWrapper:
    def __init__(self, model_id: str, **kwargs):
        self.tokenizer_wrapper = TokenizerWrapper(model_id, **kwargs)
        self.config = self.tokenizer_wrapper.config
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        self.tokenizer = self.tokenizer_wrapper.tokenizer
        self.input_builder = self.tokenizer_wrapper.input_builder
        self.postprocessor = self.tokenizer_wrapper.postprocessor
        self.vocab_size = self.config.vocab_size
        self.toolscallprocessor = self.tokenizer_wrapper.toolscallprocessor

    def tokenize(self, inputs, **kwargs):
        return self.tokenizer_wrapper.tokenize(inputs, **kwargs)