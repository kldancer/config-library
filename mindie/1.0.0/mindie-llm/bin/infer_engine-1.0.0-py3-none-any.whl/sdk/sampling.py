#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

class SamplingParams:

    def __init__(self, in_temperature=1.0, in_top_k=0, in_top_p=1.0, in_typical_p=1.0, in_do_sample=False, \
                 in_seed=1, in_repetition_penalty=1.0, in_watermark=False, in_frequency_penalty=0.0, \
                 in_presence_penalty=0.0):
        self.temperature = in_temperature
        self.top_k = in_top_k
        self.top_p = in_top_p
        self.typical_p = in_typical_p
        self.do_sample = in_do_sample
        self.seed = in_seed
        self.repetition_penalty = in_repetition_penalty
        self.watermark = in_watermark
        self.frequency_penalty = in_frequency_penalty
        self.presence_penalty = in_presence_penalty