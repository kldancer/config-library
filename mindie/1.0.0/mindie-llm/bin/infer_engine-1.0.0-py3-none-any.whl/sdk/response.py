#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from enum import Enum
from sdk import infer_engine
from sdk.request_id import RequestId
from sdk.status import Status, Code


class EndFlag(Enum):
    # 请求继续迭代执行
    RESPONSE_CONTINUE = 0
    # 请求正常结束
    RESPONSE_EOS = 1
    # 请求被主动CANCEL或STOP，用户不感知，丢弃响应
    RESPONSE_CANCEL = 2
    # 请求执行中出错，响应输出为空，err_msg非空
    RESPONSE_EXEC_ERROR = 3
    # 请求输入校验异常，响应输出为空，err_msg非空
    RESPONSE_ILLEGAL_INPUT = 4
    # 请求因达到最大序列长度而结束，响应为最后一轮迭代输出
    RESPONSE_REACH_MAX_SEQ_LEN = 5
    # 请求因达到最大输出长度（包括请求和模型粒度）而结束，响应为最后一轮迭代输出
    RESPONSE_REACH_MAX_OUTPUT_LEN = 6


class Response:
    def __init__(self, response: infer_engine.InferenceResponse):
        self.rsp = response
        self.id = RequestId(response.GetRequestId().StringValue())
        self.flag = EndFlag(self.rsp.GetFlags())
        self.eos = self.rsp.IsEOS()

    def get_output_id(self):
        """
        通过name标识获取在response里的数据, 暂时没用
        :return: status, output_ids
        """
        ret, ids = self.rsp.GetOutputIds()

        return Status(Code(ret.StatusCode().value), ret.StatusMsg()), ids

    def is_eos(self):
        """
        判断请求是否结束
        :return: 是否结束
        """
        return self.eos

    def get_flag(self):
        """
        获取请求结束标识符
        :return: 结束标识符
        """
        return self.flag

    def get_request_id(self) -> RequestId:
        """
        获取响应对应的请求标识
        :return: 请求id
        """
        return self.id