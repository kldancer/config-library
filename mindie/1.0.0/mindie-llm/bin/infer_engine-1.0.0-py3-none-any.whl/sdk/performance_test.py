#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import time
import threading
from sdk.engine import Engine
from sdk.request import Request
from sdk import infer_engine
from sdk.data import Data
from sdk.request import RequestId
import numpy as np
from sdk.dtype import DType
from sdk.sampling import SamplingParams
from sdk.response import Response


def response_callback(response: infer_engine.InferenceResponse):
    # resp 推理响应
    resp = Response(response)
    # ret: 推理返回值， ids: 推理结果
    ret, ids = resp.get_output_id()
    # request_id: 响应对应的请求id值
    request_id = resp.get_request_id()
    # is_eos: 请求是否结束
    is_eos = resp.is_eos()
    # flag: 响应结束符
    flag = resp.get_flag()


def do_forward(engine, req_id):
    # 1、创建请求
    request = Request(RequestId(req_id))
    # 2、设置请求输入数据
    data_val = [
        1, 2627, 300, 30010, 29879, 868, 4684, 6568, 29871, 29896, 29953, 29808, 639, 2462, 29889, 2296, 321, \
        1446, 2211, 363, 26044, 1432, 7250, 322, 289, 6926, 286, 3096, 1144, 363, 902, 7875, 1432, 2462, 411, \
        3023, 29889, 2296, 269, 10071, 278, 21162, 472, 278, 2215, 13269, 29915, 9999, 14218, 363, 395, 29906, \
        639, 10849, 868, 384, 19710, 29889, 1128, 1568, 297, 17208, 947, 1183, 1207, 1432, 2462, 472, 278, \
        2215, 13269, 29915, 9999, 29973
    ]
    data_size = len(data_val)
    shape = np.array([1, data_size], dtype=np.int64)
    data = Data()
    data.set_token_id(DType.TYPE_INT64, shape, np.array(data_val, dtype=np.int64))
    status1 = request.set_data_to_request(data)
    if not status1.is_ok():
        raise ValueError(f"engine set data error : {status1.get_msg()}")
    # 3、设置后处理参数
    request.set_sampling_params(SamplingParams(1.0, 0, 1.0, 1.0, False, 1, 1.0, False, 0.0, 0.0))
    # 4、执行同步推理
    status3, request_info = engine.sync_forward(request)
    if not status3.is_ok():
        raise ValueError(f"engine forward error : {status3.get_msg()}")


def sync_interface_test():
    # 编写样例
    # 1、初始化engine
    engine = Engine()
    status = engine.init()
    if not status.is_ok():
        raise ValueError(f"engine init error: {status.get_msg()}")
    # 2、资源查询
    remain_blocks, remain_prefill_slots, remain_prefill_tokens = engine.get_request_block_quotas()
    processing_num = engine.get_processing_request()
    # 3、起多线程执行同步推理
    threads = []
    for i in range(5):
        request_id = "test{}".format(i)
        t = threading.Thread(target=do_forward, args=(engine, request_id))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    # 4、析构推理引擎
    engine.finalize()


def async_interface_test():
    # 编写样例
    # 1、初始化engine
    engine = Engine()
    status = engine.init()
    if not status.is_ok():
        raise ValueError(f"engine init error: {status.get_msg()}")
    # 2、资源查询
    remain_blocks, remain_prefill_slots, remain_prefill_tokens = engine.get_request_block_quotas()
    processing_num = engine.get_processing_request()
    # 3、创建请求
    request = Request(RequestId("test"))
    # 4、 设置回调函数
    request.set_async_response_callback(response_callback)
    # 5、设置请求输入数据
    data_val = [
        1, 2627, 300, 30010, 29879, 868, 4684, 6568, 29871, 29896, 29953, 29808, 639, 2462, 29889, 2296, 321, \
        1446, 2211, 363, 26044, 1432, 7250, 322, 289, 6926, 286, 3096, 1144, 363, 902, 7875, 1432, 2462, 411, \
        3023, 29889, 2296, 269, 10071, 278, 21162, 472, 278, 2215, 13269, 29915, 9999, 14218, 363, 395, 29906, \
        639, 10849, 868, 384, 19710, 29889, 1128, 1568, 297, 17208, 947, 1183, 1207, 1432, 2462, 472, 278, \
        2215, 13269, 29915, 9999, 29973
    ]
    data_size = len(data_val)
    shape = np.array([1, data_size], dtype=np.int64)
    data = Data()
    data.set_token_id(DType.TYPE_INT64, shape, np.array(data_val, dtype=np.int64))
    status1 = request.set_data_to_request(data)
    if not status1.is_ok():
        raise ValueError(f"engine set data error : {status1.get_msg()}")
    # 6、设置后处理参数
    request.set_sampling_params(SamplingParams(1.0, 0, 1.0, 1.0, False, 1, 1.0, False, 0.0, 0.0))
    # 7、执行异步推理
    status3 = engine.async_forward(request)
    if not status3.is_ok():
        raise ValueError(f"engine forward error : {status3.get_msg()}")
    time.sleep(10)
    # 8、析构推理引擎
    engine.finalize()

if __name__ == '__main__':
    # 异步接口测试用例
    async_interface_test()
    # 同步接口测试用例
    sync_interface_test()