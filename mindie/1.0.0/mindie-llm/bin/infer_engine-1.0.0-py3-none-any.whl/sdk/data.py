#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from sdk.dtype import DType, get_data_size_by_type
import numpy as np


class Data:

    def __init__(self):
        self.name = ""
        self.type = DType.TYPE_INVALID
        self.shape = []
        self.data = []
        self.item_size = 0
        self.data_size = 0

    def set_token_id(self, data_type: DType, shape: np.ndarray, data: np.ndarray):
        """
        设置token_id
        :param data_type: 数据类型
        :param shape: 数据shape
        :param data: 具体数据，tokenId
        """
        self.name = "INPUT_IDS"
        self.type = data_type
        self.shape = shape
        self.data = data
        # 这里要保证用户传入的数据类型和array中的数据类型保持一致
        self.item_size = get_data_size_by_type(data_type)
        self.data_size = len(data)

    def get_name(self):
        return self.name

    def get_type(self):
        return self.type

    def get_data(self):
        return self.data

    def get_shape(self):
        return self.shape