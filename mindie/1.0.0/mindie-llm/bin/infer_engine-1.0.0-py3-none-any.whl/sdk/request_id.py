#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from enum import Enum


class RequestIdType(Enum):
    UINT64 = 1
    STRING = 2


class RequestId:

    def __init__(self, str_id: str):
        self.type = RequestIdType.STRING
        self.id = str_id

    def get_id_type(self):
        return self.type

    def get_id_value(self):
        return self.id