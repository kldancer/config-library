#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from enum import Enum
import numpy as np
from sdk import infer_engine


class DType(Enum):
    TYPE_INVALID = 0
    TYPE_BOOL = 1
    TYPE_UINT8 = 2
    TYPE_UINT16 = 3
    TYPE_UINT32 = 4
    TYPE_UINT64 = 5
    TYPE_INT8 = 6
    TYPE_INT16 = 7
    TYPE_INT32 = 8
    TYPE_INT64 = 9
    TYPE_FP16 = 10
    TYPE_FP32 = 11
    TYPE_FP64 = 12
    TYPE_STRING = 13
    TYPE_BF16 = 14
    TYPE_BUTT = 15


def get_dtype_by_value(n):
    for key, val in DType.__members__.items():
        if val.value == n:
            return key
    return DType.TYPE_INVALID


def get_data_size_by_type(in_type: DType):
    switcher = {
        DType.TYPE_INVALID: 0,
        DType.TYPE_BOOL: np.dtype(np.bool_).itemsize,
        DType.TYPE_UINT8: np.dtype(np.uint8).itemsize,
        DType.TYPE_UINT16: np.dtype(np.uint16).itemsize,
        DType.TYPE_UINT32: np.dtype(np.uint32).itemsize,
        DType.TYPE_UINT64: np.dtype(np.uint64).itemsize,
        DType.TYPE_INT8: np.dtype(np.int8).itemsize,
        DType.TYPE_INT16: np.dtype(np.int16).itemsize,
        DType.TYPE_INT32: np.dtype(np.int32).itemsize,
        DType.TYPE_INT64: np.dtype(np.int64).itemsize,
        DType.TYPE_FP16: 2,
        DType.TYPE_FP32: 4,
        DType.TYPE_FP64: 8,
        DType.TYPE_BF16: 2,
    }
    return switcher.get(in_type)


def get_engine_type_by_dtype(in_type: DType):
    switcher = {
        DType.TYPE_INVALID: infer_engine.LLM_ENGINE_DataType_enum.TYPE_INVALID,
        DType.TYPE_BOOL: infer_engine.LLM_ENGINE_DataType_enum.TYPE_BOOL,
        DType.TYPE_UINT8: infer_engine.LLM_ENGINE_DataType_enum.TYPE_UINT8,
        DType.TYPE_UINT16: infer_engine.LLM_ENGINE_DataType_enum.TYPE_UINT16,
        DType.TYPE_UINT32: infer_engine.LLM_ENGINE_DataType_enum.TYPE_UINT32,
        DType.TYPE_UINT64: infer_engine.LLM_ENGINE_DataType_enum.TYPE_UINT64,
        DType.TYPE_INT8: infer_engine.LLM_ENGINE_DataType_enum.TYPE_INT8,
        DType.TYPE_INT16: infer_engine.LLM_ENGINE_DataType_enum.TYPE_INT16,
        DType.TYPE_INT32: infer_engine.LLM_ENGINE_DataType_enum.TYPE_INT32,
        DType.TYPE_INT64: infer_engine.LLM_ENGINE_DataType_enum.TYPE_INT64,
        DType.TYPE_FP16: infer_engine.LLM_ENGINE_DataType_enum.TYPE_FP16,
        DType.TYPE_FP32: infer_engine.LLM_ENGINE_DataType_enum.TYPE_FP32,
        DType.TYPE_FP64: infer_engine.LLM_ENGINE_DataType_enum.TYPE_FP64,
        DType.TYPE_BF16: infer_engine.LLM_ENGINE_DataType_enum.TYPE_BF16,
    }
    return switcher.get(in_type)