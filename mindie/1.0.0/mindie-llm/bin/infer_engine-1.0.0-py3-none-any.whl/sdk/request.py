#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from sdk import infer_engine
from sdk.data import Data
from sdk.status import Status, Code
from sdk.request_id import RequestId
from sdk.sampling import SamplingParams
from sdk.dtype import get_engine_type_by_dtype


class Request:
    def __init__(self, request_id: RequestId):
        self.request_id = request_id
        req_id = infer_engine.RequestId(request_id.id)
        self.request = infer_engine.InferenceRequest(req_id)

    def set_data_to_request(self, input_data: Data) -> Status:
        """
        在request中设置传入自定义的data数据
        :param input_data: 输入数据
        :return: status
        """
        size = input_data.item_size * input_data.data_size
        ret_stat = self.request.AddOriginalInput(input_data.name, get_engine_type_by_dtype(input_data.type), \
                                                 input_data.shape, len(input_data.shape), input_data.data, size)

        return Status(Code(ret_stat.StatusCode().value), ret_stat.StatusMsg())

    def set_sampling_params(self, params: SamplingParams):
        """
        为request设置sampling参数
        :param params: sampling参数
        :return:
        """
        in_params = infer_engine.SamplingParams()
        in_params.temperature = params.temperature
        in_params.top_k = params.top_k
        in_params.top_p = params.top_p
        in_params.typical_p = params.typical_p
        in_params.do_sample = params.do_sample
        in_params.seed = params.seed
        in_params.repetition_penalty = params.repetition_penalty
        in_params.watermark = params.watermark
        in_params.frequency_penalty = params.frequency_penalty
        in_params.presence_penalty = params.presence_penalty
        self.request.SetSamplingParams(in_params)

    def set_max_output_len(self, max_output_len):
        """
        设置请求最大输出长度
        :param max_output_len: 最大输出长度
        :return:
        """
        self.request.SetMaxOutputLen(max_output_len)

    def get_request_id(self) -> RequestId:
        """
        获取请求标识id
        :return:
        """
        return self.request_id

    def set_async_response_callback(self, response_callback):
        self.request.SetAsyncForwardCallback(response_callback)