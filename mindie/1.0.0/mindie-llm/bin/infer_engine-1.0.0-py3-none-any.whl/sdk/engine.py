#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from sdk import infer_engine
from sdk.status import Status, Code
from sdk.request import Request


class Engine:
    def __init__(self):
        """
        创建一个infer_engine对象
        """
        self.engine = infer_engine.InferenceEngine()

    def init(self) -> Status:
        """
        初始化engine对象
        :return: status
        """
        ret = self.engine.Init()
        return Status(Code(ret.StatusCode().value), ret.StatusMsg())

    def finalize(self) -> Status:
        """
        析构engine对象
        :return: status
        """
        ret = self.engine.Finalize()
        return Status(Code(ret.StatusCode().value), ret.StatusMsg())

    def async_forward(self, request: Request) -> Status:
        """
        执行请求推理
        :param request: 需要推理的请求
        :return: status
        """
        ret = self.engine.AsyncForward(request.request)
        return Status(Code(ret.StatusCode().value), ret.StatusMsg())

    def sync_forward(self, request: Request) -> Status:
        """
        执行请求推理
        :param request: 需要推理的请求
        :return: status
        """
        ret, request_info = self.engine.SyncForward(request.request)
        return Status(Code(ret.StatusCode().value), ret.StatusMsg()), request_info

    def get_request_block_quotas(self):
        """
        返回 remainBlocks, remainPrefillSlots, remainPrefillTokens
        :return:
        """
        remain_blocks, remain_prefill_slots, remain_prefill_tokens = self.engine.GetRequestBlockQuotas()
        return remain_blocks, remain_prefill_slots, remain_prefill_tokens

    def get_processing_request(self):
        """
        返回 processing num
        :return:
        """
        processing_num = self.engine.GetProcessingRequest()
        return processing_num