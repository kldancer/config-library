#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

import os
import json
import time
from .log_util import logger
from .file_util import FileUtils

METRICS_PATH = "./"


class FileMetrics:
    def __init__(self, enable=True):
        self.pid = os.getpid()
        self.metric_enable = enable
        self.path = METRICS_PATH
        self.metrics = list()

    def add_event_begin(self, event_str: str, req_id=""):
        if self.metric_enable:
            metric = dict()
            metric["name"] = event_str
            metric["ph"] = "B"
            metric["pid"] = 2
            metric["tid"] = str(req_id)
            metric["ts"] = str(round(time.time_ns() / (10 ** 3)))
            self.metrics.append(metric)
        else:
            pass

    def add_event_end(self, event_str: str, req_id=""):
        if self.metric_enable:
            metric = dict()
            metric["name"] = event_str
            metric["ph"] = "E"
            metric["pid"] = 2
            metric["tid"] = str(req_id)
            metric["ts"] = str(round(time.time_ns() / (10 ** 3)))
            self.metrics.append(metric)
        else:
            pass

    def output(self):
        if not self.metric_enable:
            return
        logger.info(f"output metrics siz: {len(self.metrics)}")
        file = self.path + "metrics." + str(self.pid) + ".json"
        check_flag, err_msg, path = FileUtils.regular_file_path(file, base_dir="/", allow_symlink=False)
        if not check_flag:
            raise ValueError(err_msg)
        if os.path.exists(path):
            check_flag, err_msg = FileUtils.is_file_valid(file, mode=0o640, check_owner=True, check_permission=True)
            if not check_flag:
                raise ValueError(err_msg)
        try:
            with open(file, mode="w") as json_file:
                for index, m in enumerate(self.metrics):
                    json_str = json.dumps(m)
                    if index == 0:
                        json_str = "[" + json_str
                    json_file.write(json_str)
                    if index == len(self.metrics) - 1:
                        json_file.write("]")
                    else:
                        json_file.write(",\n")
        except Exception as e:
            logger.error(f"[METRICS]\t>>> output failed, {e}")
