#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

import numpy as np
from .common_util import ipv4_to_int, ipv4_tensor_to_int, ipv4_tensor_to_str
from .log_util import logger

SERVER_LIST = "server_list"


class Config:
    def __init__(self, model_config: dict):
        if model_config is None:
            raise ValueError(f"model_config is None!")

        self.model_config = model_config
        self.local_rank = self.parse('local_rank', required=True, to_int=True)
        self.infer_mode = self.parse('infer_mode', required=False, default_value="standard")

        self.local_server_ip_int = 0
        self.local_device_ip = ""
        self.local_device_ip = ""
        self.remote_link_device_ips = []
        self.remote_server_ip_int = []
        self.remote_link_server_ip = []
        self.remote_unlink_device_ips = []
        self.remote_unlink_server_ip_int = []

        logger.info(f"model_config {model_config}")
        if self.infer_mode == "dmi":
            self.init_dmi_config()
            logger.info("init dmi config")
        else:
            logger.info("do not init dmi config")

        self.initialize()

    def initialize(self):
        # optional
        self.model_instance_type = self.parse("model_instance_type")
        self.speculation_gamma = self.parse("speculation_gamma")
        self.backend_type = self.parse('backend_type', default_value="")
        self.plugin_params = self.parse("plugin_params", default_value="")

        # not optional
        self.model_weight_path = self.parse('model_id', required=True)
        self.rank = self.parse('rank', required=True, to_int=True)
        self.world_size = self.parse('world_size', required=True, to_int=True)
        self.npu_device_id = self.parse('npu_device_id', required=True, to_int=True)
        self.npu_device_ids = self.parse_list('npu_device_ids', required=True, to_int=True)
        self.cpu_mem_size = self.parse('cpu_mem', required=True, to_int=True)
        self.npu_mem_size = self.parse('npu_mem', required=True, to_int=True)
        self.max_seq_len = self.parse('max_seq_len', required=True, to_int=True)
        self.max_iter_times = self.parse('max_iter_times', required=True, to_int=True)
        self.max_prefill_tokens = self.parse('max_prefill_tokens', required=True, to_int=True)
        self.cache_block_size = self.parse("block_size", required=True, to_int=True)

    def init_dmi_config(self):
        self.need_switch = False
        self.role = self.parse("model_role", required=True)
        if self.role != "prefill" and self.role != "decoder":
            logger.error("pd_role should be prefill or decoder in DMI mode")
            return

        device_id = self.model_config["local_device_id"].split(",")
        local_device_ip = self.model_config["local_device_ip"].split(",")[self.local_rank]
        self.model_config["npu_device_id"] = device_id[self.local_rank]
        self.model_config["world_size"] = str(len(device_id))
        self.model_config["local_model_instance_id"] = ipv4_to_int(self.model_config['local_server_ip'])
        self.model_config["local_device_ip"] = local_device_ip

        # do not init remote info at prefill node
        if self.role == "prefill":
            return

        self.model_config["remote_model_instance_ids"] = []
        if "remote_server_ip" in self.model_config and "remote_device_ip" in self.model_config:
            server_ip = self.model_config["remote_server_ip"].split(";")
            device_ip = self.model_config["remote_device_ip"].split(";")
            server_id = []
            device_ip = []
            for cur_index, single_server_ip in enumerate(server_ip):
                server_id.append(ipv4_to_int(single_server_ip))
                device_ips = device_ip[cur_index].split(",")
                cur_device_ip = device_ips[self.local_rank]
                device_ip.append(cur_device_ip)

            self.model_config["remote_model_instance_ids"] = server_id
            self.model_config["remote_device_ips"] = ",".join(device_ip)

    def set_pd_role(self, role):
        if role == 1:
            self.role = "prefill"
        elif role == 2:
            self.role = "decoder"
        else:
            self.role = "unknown"
        logger.info(f"[Config]\t>>> Reset PD role finish. PD role is: {self.role}")

    def set_pd_link_info(self, requests):
        logger.info(f"[Config]\t>>> start to set PD link/unlink info according to the request.")
        attr_info = np.array(requests[0].get_tensor_by_name("ATTRIBUTES"), dtype=np.int64, copy=False)

        self.set_pd_role(attr_info[0][0])
        self.need_switch = (attr_info[0][1] == 1)
        link_num = attr_info[0][2]
        unlink_num = attr_info[0][3]
        logger.info(f"[Config]\t>>> PD switch is {self.need_switch}, link num : {link_num}, unlink_num : {unlink_num}")

        self.remote_link_device_ips = []
        self.remote_server_ip_int = []
        self.remote_link_server_ip = []

        self.remote_unlink_device_ips = []
        self.remote_unlink_server_ip_int = []

        if link_num == 0 and unlink_num == 0:
            return

        device_info = np.array(requests[0].get_tensor_by_name("DEVICES"), dtype=np.int64, copy=False)

        # link info
        for i in range(0, link_num):
            link_device = device_info[i]
            link_server_ip = ipv4_tensor_to_int(link_device[0])
            link_device_ip = ipv4_tensor_to_str(link_device[self.local_rank + 1])
            self.remote_link_device_ips.append(link_device_ip)
            self.remote_server_ip_int.append(link_server_ip)
            self.remote_link_server_ip.append(link_device[0])
        logger.info(
            f"[Config]\t>>> self.remote_link_server_ip is {self.remote_link_server_ip}."
            f"self.remote_link_device_ips is {self.remote_link_device_ips}.")

        # unlink info
        for i in range(link_num, link_num + unlink_num):
            unlink_device = device_info[i]
            unlink_server_ip = ipv4_tensor_to_int(unlink_device[0])
            unlink_device_ip = ipv4_tensor_to_str(unlink_device[self.local_rank + 1])
            self.remote_unlink_device_ips.append(unlink_device_ip)
            self.remote_unlink_server_ip_int.append(unlink_server_ip)
        logger.info(
            f"[Config]\t>>> self.remote_unlink_device_ips is {self.remote_unlink_device_ips}.")

    def set_release_info(self, requests):
        device_ip_info = np.array(requests[0].get_tensor_by_name("DEVICE_IP"), dtype=np.int64, copy=False)
        self.remote_unlink_server_ip_int = []
        self.remote_unlink_server_ip_int.append(ipv4_tensor_to_int(device_ip_info[0]))
        self.remote_unlink_device_ips = []
        unlink_device_ip = ipv4_tensor_to_str(device_ip_info[self.local_rank + 1])
        self.remote_unlink_device_ips.append(unlink_device_ip)

    def parse(self, item_name, required=False, to_int=False, default_value=None):
        value = self.model_config.get(item_name)
        if value is None:
            if required:
                raise ValueError(f"You should set {item_name}.")
            if default_value is not None:
                value = default_value
        elif to_int:
            value = int(value)
        return value

    def parse_list(self, item_name, split_char=',', required=False, to_int=False, default_value=None):
        value = self.model_config.get(item_name)
        if value is None:
            if required:
                raise ValueError(f"You should set {item_name}.")
            if default_value is not None:
                value = default_value
        str_list = value.split(split_char)
        if to_int:
            int_list = [int(x) for x in str_list]
            return int_list
        return str_list
