#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

from mindie_llm.modeling.backend_type import BackendType
from .log_util import logger
from .env import ENV


def set_npu_compile_mode():
    if ENV.framework_backend.lower() == BackendType.MS:
        logger.warning(f"mindspore model. no need to set set_option ")
        return

    import torch
    import torch_npu
    torch.npu.set_compile_mode(jit_compile=False)
    soc_version = torch_npu._C._npu_get_soc_version()
    if soc_version not in [104, 220, 221, 222, 223, 224]:
        logger.info("310P,some op does not support")
        option = {"NPU_FUZZY_COMPILE_BLACKLIST": "ReduceNansum"}
        torch.npu.set_option(option)
