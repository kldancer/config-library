#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.


def ipv4_to_int(ipv4_str):
    if not ipv4_str:
        return 0
    i = 0
    ip_int = 0
    for ip_part in ipv4_str.split(".")[::-1]:
        ip_int = ip_int + int(ip_part) * 256**i
        i += 1
    return ip_int


def ipv4_tensor_to_int(ipv4_tensor):
    ip_int = (ipv4_tensor[0] << 24) + (ipv4_tensor[1] << 16) + (ipv4_tensor[2] << 8) + ipv4_tensor[3]
    return int(ip_int)


def ipv4_tensor_to_str(ipv4_tensor):
    str_arr = [str(num) for num in ipv4_tensor]
    result_str = '.'.join(str_arr)
    return result_str