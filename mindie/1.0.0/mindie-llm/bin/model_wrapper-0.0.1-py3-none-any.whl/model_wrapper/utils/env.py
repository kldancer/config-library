#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
from dataclasses import dataclass


@dataclass
class EnvVar:
    """
    环境变量
    """
    # 模型框架类型， ATB 或者 MS, 默认为ATB, 和 mindie_llm 中环境变量同名
    framework_backend = os.getenv('MINDIE_LLM_FRAMEWORK_BACKEND', "ATB").lower()


ENV = EnvVar()
