#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.

from enum import Enum


class ModelWrapperErrorCode(Enum):
    SUCCESS = 0
    PD_UNLINK_ERROR = 2000
    PD_LINK_ERROR = 2001
    PD_SWITCH_ROLE_ERROR = 2002
    PD_PULL_KV_ERROR = 2003
    PD_PULL_KV_UNKNOW_ERROR = 2004
