#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

import os
import logging
from logging.handlers import RotatingFileHandler
from .file_util import FileUtils


OPEN_LOG_FILE_PERM = 0o640
ROLLOVER_LOG_FILE_PERM = 0o440


def check_env(new_env, old_env, default_val):
    new_e = os.getenv(new_env)
    if new_e:
        return new_e
    else: # 只有new_env未被设置时old_env才会生效
        return os.getenv(old_env, default_val)

log_to_file: bool = check_env("MIES_PYTHON_LOG_TO_FILE", "MINDIE_LLM_PYTHON_LOG_TO_FILE", "0") == "1"
log_to_stdout: bool = check_env("MIES_PYTHON_LOG_TO_STDOUT", "MINDIE_LLM_PYTHON_LOG_TO_STDOUT", "0") == "1"
log_level_env = check_env("MIES_PYTHON_LOG_LEVEL", "MINDIE_LLM_PYTHON_LOG_LEVEL", "INFO")
log_path = check_env("MIES_PYTHON_LOG_PATH", "MINDIE_LLM_PYTHON_LOG_PATH", None)

LOG_MAX_BYTES = int(os.getenv('MINDIE_LLM_PYTHON_LOG_MAXSIZE', "20971520"))
LOG_MAX_NUMS = int(os.getenv('MINDIE_LLM_PYTHON_LOG_MAXNUM', "10"))

if LOG_MAX_BYTES < 0 or LOG_MAX_BYTES > 524288000:
    raise ValueError("MINDIE_LLM_PYTHON_LOG_MAXSIZE should between 0 and 524288000 (500MB), "
                        f"but get {LOG_MAX_BYTES}.")
if LOG_MAX_NUMS < 0 or LOG_MAX_NUMS > 64:
    raise ValueError("MINDIE_LLM_PYTHON_LOG_MAXNUM should between 0 and 64, "
                        f"but get {LOG_MAX_NUMS}.")

LOG_PATH_MAX_LEN = 4096
LOG_LEVEL_MAP = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "FATAL": logging.FATAL
}
LOG_FORMATTER = logging.Formatter('%(asctime)s [%(levelname)s] %(filename)s:%(lineno)d - %(message)s')


def check_log_path(path):
    check_flag, err_msg, path = FileUtils.regular_file_path(path, base_dir="/", allow_symlink=False)
    if not check_flag:
        raise ValueError(err_msg)
    if os.path.exists(path):
        check_flag, err_msg = FileUtils.is_file_valid(path, mode=0o640, check_owner=True, check_permission=True)
        if not check_flag:
            raise ValueError(err_msg)
    else:
        with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT, 0o640), 'w'):
            pass


def check_log_dir():
    log_dir = os.path.dirname(log_path)
    try:
        os.makedirs(log_dir, exist_ok=True)
        os.chmod(log_dir, 0o700)
    except OSError as e:
        raise Exception("OSError when creating python log dir") from e


class MINDIERotatingFileHandler(RotatingFileHandler):
    def doRollover(self):
        super().doRollover()
        os.chmod(self.baseFilename, ROLLOVER_LOG_FILE_PERM)

    def _open(self):
        if os.path.exists(self.baseFilename):
            os.chmod(self.baseFilename, OPEN_LOG_FILE_PERM)
        open_func = self._builtin_open
        ret = open_func(self.baseFilename, self.mode, encoding=self.encoding, errors=self.errors)
        os.chmod(self.baseFilename, OPEN_LOG_FILE_PERM)
        return ret


def setup_logging():

    pid = os.getpid()
    custom_logger = logging.getLogger(f"model-wrapper-{pid}")
    custom_logger.propagate = False
    custom_logger.setLevel(LOG_LEVEL_MAP.get(log_level_env, logging.INFO))

    if log_to_file and LOG_MAX_BYTES > 0 and LOG_MAX_NUMS > 0:
        check_log_dir()
        log_file = f"{log_path}.{pid}"
        check_log_path(log_file)
        file_handle = MINDIERotatingFileHandler(
            filename=log_file,
            maxBytes=LOG_MAX_BYTES,
            backupCount=LOG_MAX_NUMS)
        file_handle.setFormatter(LOG_FORMATTER)
        custom_logger.addHandler(file_handle)
    if log_to_stdout:
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(LOG_FORMATTER)
        custom_logger.addHandler(stream_handler)
    return custom_logger


logger = setup_logging()


def is_log_enable():
    return (log_to_file and LOG_MAX_BYTES > 0 and LOG_MAX_NUMS > 0) or log_to_stdout
