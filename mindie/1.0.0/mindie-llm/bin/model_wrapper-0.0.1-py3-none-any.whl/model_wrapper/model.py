#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.
import os
import signal
import threading
import queue

import backend_utils

from .utils.config import Config
from .utils.log_util import logger, is_log_enable
from .utils.error import ModelWrapperErrorCode
from .standard_model import StandardLLMPythonModel
from .standard_model_mock import StandardMockLLMPythonModel


class LLMPythonModel:
    def __init__(self):
        self.python_model = None
        self.infer_queue = queue.Queue()
        self.transfer_queue = queue.Queue()
        self.create_work()

    def initialize(self, model_config: dict) -> dict:
        try:
            config = Config(model_config)

            if config.model_instance_type is None or config.model_instance_type == "Standard":
                self.python_model = StandardLLMPythonModel()
            elif config.model_instance_type == "StandardMock":
                self.python_model = StandardMockLLMPythonModel()
            else:
                logger.error(f"[Model]\t>>> model_instance_type {config.model_instance_type} is not supported")
                raise ValueError("unexpected role")

            return self.python_model.initialize(config)
        except Exception as e:
            logger.exception(f"[Model]\t>>> Exception:{e}")

            initialize_result = {"status": "error", "npuBlockNum": "0", "cpuBlockNum": "0"}
            logger.error(f"[Model]\t>>> return initialize error result: {initialize_result}")
            os.kill(os.getpid(), signal.SIGKILL)
            return initialize_result

    def execute(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str]):
        if not requests or self.python_model is None:
            logger.error(f"[Model]\t>>> requests is empty or python model is None")
            raise RuntimeError("requests is empty or python model is None")

        return self.python_model.execute(requests, config_map)

    def create_work(self):
        t_inference = threading.Thread(target=self.do_inference)
        t_inference.start()

    def do_task(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str], event_type):
        if is_log_enable():
            logger.debug("[py receiver] recv a task name")

        if event_type in [0, 1, 3]:
            if is_log_enable():
                logger.debug(f"[python receiver] add a task to infer_queue, task type is:{event_type}")
            self.infer_queue.put([requests, config_map, event_type])
        elif event_type == 2:
            if is_log_enable():
                logger.debug("[python receiver] add transfer task to transfer_queue")
            self.transfer_queue.put([requests, config_map])
        else:
            logger.error("unknown event_type")

    def do_inference(self):
        while True:
            if is_log_enable():
                logger.debug("[python thread: infer] waiting a task")
            requests, config_map, event_type = self.infer_queue.get()
            if is_log_enable():
                logger.debug(f"[python thread: infer] doing a task, task type is:{event_type}")
            if event_type == 0:
                initialize_result = self.initialize(config_map)
                t_transfer = threading.Thread(target=self.do_transfer)
                t_transfer.start()
                # inform master process that initialization is finished
                backend_utils.process_python_exec_result(0, 0, initialize_result, [])
            elif event_type == 1:
                responses = self.execute(requests, config_map)
                # inform master process that inference is finished
                backend_utils.process_python_exec_result(1, 0, dict(), responses)
            elif event_type == 3:
                ret = self.finalize()
                backend_utils.process_python_exec_result(3, ret, dict(), [])
            else:
                logger.error("unknown event_type")
                raise RuntimeError("python doing a unknown task type")

    def do_transfer(self):
        while True:
            if is_log_enable():
                logger.debug("[python thread: transfer] waiting a task")
            requests, config_map = self.transfer_queue.get()
            if is_log_enable():
                logger.debug("[python thread: transfer] doing transfer for task")

            if not requests or self.python_model is None:
                logger.error(f"[Model]\t>>> requests is empty or python model is None")
                raise RuntimeError("requests is empty or python model is None")

            ret, responses = self.python_model.transfer(requests, config_map)
            if ret == ModelWrapperErrorCode.SUCCESS or ret == ModelWrapperErrorCode.PD_LINK_ERROR:
                backend_utils.process_python_exec_result(2, 0, dict(), responses)
            else:
                backend_utils.process_python_exec_result(2, -1, dict(), responses)


    def finalize(self):
        if self.python_model is None:
            logger.error(f"[Model]\t>>> python model is None")
            raise RuntimeError("python model is None")
        return self.python_model.finalize()
