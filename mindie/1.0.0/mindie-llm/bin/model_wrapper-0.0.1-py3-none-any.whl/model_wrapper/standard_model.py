#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

import json
import time
import base64

import numpy as np

from mindie_llm.text_generator.generator import Generator
from mindie_llm.text_generator.utils.input_metadata import InputMetadata
from mindie_llm.utils.tensor import npu
from mindie_llm.modeling.backend_type import BackendType
from mindie_llm.utils.error import MindieLlmErrorCode

import backend_utils
from .utils.config import Config
from .utils.metrics import FileMetrics
from .utils.log_util import logger, is_log_enable
from .utils.npu_compile import set_npu_compile_mode
from .utils.env import ENV
from .utils.error import ModelWrapperErrorCode

NON_KVCACHE_TOKEN_NUM = 1
SRC_BLOCK_TABLE_KEY = "src_block_tables"
DST_BLOCK_TABLE_KEY = "dst_block_tables"
REQ_INDEX = "request_index"

SAMPLING_DTYPE = np.dtype([
    ('temperature', np.float64),
    ('top_k', np.float64),
    ('top_p', np.float64),
    ('typical_p', np.float64),
    ('do_sample', np.float64),
    ('seed', np.int64),
    ('repetition_penalty', np.float64),
    ('frequency_penalty', np.float64),
    ('presence_penalty', np.float64),
    ('watermark', np.float64),
    ('length_penalty', np.float64)])


def generate_stop_strings(request):
    batch_stop_strings_tmp = np.array(request.get_tensor_by_name("STOP_STRINGS"), copy=False)
    str_encode = ""
    try:
        for str_stop in batch_stop_strings_tmp[0]:
            str_encode += chr(str_stop)
        str_decode = base64.b64decode(str_encode.strip()).decode('utf-8')
        return json.loads(str_decode)
    except Exception:
        return []


def generate_tools_from_request(request):
    tools_temp = np.array(request.get_tensor_by_name("TOOLS"), copy=False)
    str_encode = ""
    try:
        for str_tensor in tools_temp[0]:
            str_encode += chr(str_tensor)
        str_decode = base64.b64decode(str_encode.strip()).decode('utf-8')
        return json.loads(str_decode)
    except Exception:
        logger.debug(f"failed to base64 decode tools")
        return []


def generate_tool_choice_from_request(request):
    tool_choice_temp = np.array(request.get_tensor_by_name("TOOL_CHOICE"), copy=False)
    str_encode = ""
    try:
        for str_tensor in tool_choice_temp[0]:
            str_encode += chr(str_tensor)
        str_decode = base64.b64decode(str_encode.strip()).decode('utf-8')
        return json.loads(str_decode)
    except Exception:
        logger.debug(f"failed to base64 decode tool_choice")
        return []


def generate_lora_strings(request):
    batch_lora_strings_tmp = np.array(request.get_tensor_by_name("LORA_ID"), copy=False)
    try:
        batch_lora_strings = list(map(lambda _: "".join(map(lambda __:chr(__), _)), batch_lora_strings_tmp))
    except Exception:
        batch_lora_strings = [None]
    if batch_lora_strings[0] == "None":
        batch_lora_strings = [None]
    return batch_lora_strings[0]


def generate_user_request_id_string(request):
    batch_input_id_strings_arr = np.array(request.get_tensor_by_name("USER_REQUEST_ID"), copy=False)
    try:
        batch_input_id_strings = list(map(lambda _: "".join(map(lambda __: chr(__), _)), batch_input_id_strings_arr))
    except Exception:
        batch_input_id_strings = [None]
    return batch_input_id_strings[0]


class StandardLLMPythonModel:
    def __init__(self):
        self.config = None
        self.rank = None
        self.generator = None
        self.block_size = None
        self.total_time = 0
        self.is_mix_model = False
        self.has_inited = False
        self.metrics = FileMetrics(False)

    @staticmethod
    def _get_batch_size(requests, is_prefill, is_mix):
        if is_mix:
            gmis_metadata = np.array(requests[0].get_tensor_by_name("METADATA"), dtype=np.int64, copy=False)
            is_prefill_pre_batch = gmis_metadata[1]
            total_bs = len(requests)
            prefill_bs = np.sum(is_prefill_pre_batch)
            decode_bs = total_bs - prefill_bs
        else:
            total_bs = len(requests)
            prefill_bs = 0
            decode_bs = 0
            if is_prefill:
                prefill_bs = total_bs
            else:
                decode_bs = total_bs
        return total_bs, prefill_bs, decode_bs

    def finalize(self):
        self.metrics.output()
        if ENV.framework_backend == BackendType.MS:
            # ms模型释放之后，不用显示调用device的finalize ，析构中会自动调用
            return 0

        import torch_npu
        torch_npu._C._npu_shutdown(True)
        return 0

    def initialize(self, model_config: Config) -> dict:
        self.config = model_config
        self.rank = model_config.rank
        if is_log_enable():
            logger.info(f"rank id {self.rank} get model config: {model_config.model_config}")
        self.generator = Generator(
            model_config={
                **model_config.model_config
            }
        )

        self.is_mix_model = self.generator.is_mix_model        
        self.block_size = model_config.cache_block_size
        if is_log_enable():
            logger.info(f">>>rank:{self.rank} done ibis manager to device")

        set_npu_compile_mode()

        if model_config.max_seq_len > self.generator.max_position_embeddings:
            logger.warning(f'>>>rank:{self.rank} max_seq_len({model_config.max_seq_len}) is bigger than '
                           f'max_position_embeddings({self.generator.max_position_embeddings}) from '
                           f'model({model_config.model_weight_path}). '
                           f'The accuracy of the inference result may be affected.')

        initialize_result = {
            "status": "ok",
            "npuBlockNum": str(self.generator.cache_manager.num_npu_blocks),
            "cpuBlockNum": str(self.generator.cache_manager.num_cpu_blocks),
            "maxPositionEmbeddings": str(self.generator.max_position_embeddings)
        }
        if is_log_enable():
            logger.info(f">>>rank:{self.rank}: return initialize success result: {initialize_result}")
        return initialize_result

    def execute(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str]):
        if is_log_enable():
            logger.debug(
                f"[Model]\t>>> rank-{self.rank} enter execute, batch size:{len(requests)}, config:{config_map}")
        exec_op = config_map['EXECUTE_TYPE']

        try:
            if exec_op == '1':
                return self._prefill(requests)
            elif exec_op == '2':
                return self._decode(requests)
            elif exec_op == '3':
                return self._seqctrl(requests)
            elif exec_op == '12':
                return self._mix(requests)
            else:
                logger.error("unknown exec operation")
                return []
        except Exception as e:
            logger.exception(f"[Model]\t>>>Execute type:{exec_op}, Exception:{e}")
            return []

    def transfer(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str]):
        if is_log_enable():
            logger.debug(
                f"[Model]\t>>> rank-{self.rank} enter transfer, batch size:{len(requests)}, config:{config_map}")
        exec_op = config_map['EXECUTE_TYPE']
        try:
            if exec_op == '4':
                return self._pd_role(requests)
            elif exec_op == '5':
                return self._force_p_release(requests)
            elif exec_op == '10':
                return self.__pull_kvcache(requests)
            else:
                logger.error("unknown exec operation")
                return MindieLlmErrorCode.PD_UNKNOW_ERROR, []
        except Exception as e:
            logger.exception(f"[Model]\t>>>Execute type:{exec_op}, Exception:{e}")
            return MindieLlmErrorCode.PD_UNKNOW_ERROR, []

    def _prefill(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        return self.__generate(requests, is_prefill=True, is_mix=False)

    def _decode(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        return self.__generate(requests, is_prefill=False, is_mix=False)

    def _seqctrl(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        if is_log_enable():
            logger.debug(f"[Model]\t>>> rank-{self.rank} enter seqctrl")
        eos_attr = []
        for request in requests:
            req_id_tensor = request.get_tensor_by_name("IBIS_ATTR")
            if req_id_tensor:
                req_id = np.array(req_id_tensor, copy=False)[0][0]
            else:
                raise ValueError("Failed to get 'IBIS_ATTR' value!")

            ret = self.generator.seq_ctrl([req_id])
            if ret == 0:
                if is_log_enable():
                    logger.debug(f"[Model]\t>>> rank-{self.rank} seqctrl request {req_id} success")
                eos_attr.append([2, 1])
            else:
                if is_log_enable():
                    logger.debug(f"[Model]\t>>> rank-{self.rank} seqctrl request not exists, req_id is {req_id}")
                eos_attr.append([4, 1])

        eos_attr_np = np.array(eos_attr, dtype=np.int64)
        output_ids_np = np.array([[-1] for _ in range(len(requests))], dtype=np.int64)
        merge_tensors = [
            ("IBIS_EOS_ATTR", eos_attr_np),
            ("OUTPUT_IDS", output_ids_np)
        ]
        responses = backend_utils.from_numpy_merge_tensors(merge_tensors)
        return responses

    def _pd_role(self, requests: list[backend_utils.InferenceRequest]) -> list[
        backend_utils.InferenceResponse]:
        if is_log_enable():
            logger.info(f"[Model]\t>>> rank-{self.rank} enter process pdRole")
        self.config.set_pd_link_info(requests)

        ret, fail_link_ip = self._process_assign_role()
        if is_log_enable():
            logger.info(f"[Model]\t>>> rank-{self.rank} the total failed link server ip : {fail_link_ip}")

        responses = []
        # 构造response，[fail_link_ip_num, fail_link_ip1, fail_link_ip2, ...]
        result = [np.uint16(len(fail_link_ip))] + list(np.array(fail_link_ip, dtype=np.uint16))
        result_numpy = np.array(result, dtype=np.uint16)
        result_tensor = backend_utils.Tensor("FAILED_IP_ATTR", result_numpy)
        inference_response = backend_utils.InferenceResponse([result_tensor])
        responses.append(inference_response)
        return ret, responses

    def _force_p_release(self, requests: list[backend_utils.InferenceRequest]) -> list[
        backend_utils.InferenceResponse]:
        if is_log_enable():
            logger.info(f"[Model]\t>>> rank-{self.rank} enter force P release link")
        self.config.set_release_info(requests)
        responses = []
        try:
            self.generator.unlink(self.config.remote_unlink_device_ips[0],
                self.config.remote_unlink_server_ip_int[0])
            fail_link_ip_np = np.array([[0]], dtype=np.int16)
            responses = backend_utils.from_numpy_merge_tensors([("FAILED_P_UNLINK_IP", fail_link_ip_np)])

            if is_log_enable():
                logger.info(f"[Model]\t>>> rank-{self.rank} success unlink : {self.config.remote_unlink_device_ips[0]}")
            return ModelWrapperErrorCode.SUCCESS, responses
        except Exception as e:
            logger.exception(f"[Model]\t>>> Exception:{e}")
            fail_link_ip_np = np.array([[-1]], dtype=np.int16)
            responses = backend_utils.from_numpy_merge_tensors([("FAILED_P_UNLINK_IP", fail_link_ip_np)])

            if is_log_enable():
                logger.info(f"[Model]\t>>> rank-{self.rank} fail to unlink : {self.config.remote_unlink_device_ips[0]}")
            return ModelWrapperErrorCode.PD_UNLINK_ERROR, responses

    def _process_assign_role(self):
        logger.info(f"[Config]\t>>> start to process PD switch scenario.")
        link_fail_ip_list = []
        # unlink with all peers if current decode node has inited
        if self.has_inited:
            for i, _ in enumerate(self.config.remote_unlink_server_ip_int):
                try:
                    self.generator.unlink(self.config.remote_unlink_device_ips[i],
                                        self.config.remote_unlink_server_ip_int[i])
                except Exception as e:
                    logger.exception(f"[Model]\t>>> Exception:{e}")
                    return ModelWrapperErrorCode.PD_UNLINK_ERROR, []
        if self.config.need_switch:
            try:
                self.generator.switch_role(self.config.role)
            except Exception as e:
                logger.exception(f"[Model]\t>>> Exception:{e}")
                return ModelWrapperErrorCode.PD_SWITCH_ROLE_ERROR, []
        if self.config.role == "prefill":
            return ModelWrapperErrorCode.SUCCESS, []
        res = ModelWrapperErrorCode.SUCCESS
        for i, _ in enumerate(self.config.remote_server_ip_int):
            self.generator.unlink(self.config.remote_link_device_ips[i], self.config.remote_server_ip_int[i])
            link_ret = self.generator.link(self.config.remote_link_device_ips[i], self.config.remote_server_ip_int[i])
            if link_ret != MindieLlmErrorCode.SUCCESS:
                res = ModelWrapperErrorCode.PD_LINK_ERROR
                link_fail_ip_list.extend(self.config.remote_link_server_ip[i])
                logger.error(f"[Config]\t>>> ip: {self.config.remote_link_server_ip[i]} link fail.")
        if (not self.has_inited) and res == ModelWrapperErrorCode.SUCCESS:
            self.has_inited = True
        return res, link_fail_ip_list

    def _mix(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        gmis_metadata = np.array(requests[0].get_tensor_by_name("METADATA"), dtype=np.int64, copy=False)
        is_prefill_pre_batch = gmis_metadata[1]
        first_batch_is_prefill = is_prefill_pre_batch[0]
        last_batch_is_prefill = is_prefill_pre_batch[-1]
        if first_batch_is_prefill != last_batch_is_prefill:
            return self.__generate(requests, is_prefill=True, is_mix=True)
        elif first_batch_is_prefill:
            return self.__generate(requests, is_prefill=True, is_mix=False)
        else:
            return self.__generate(requests, is_prefill=False, is_mix=False)


    def __generate(self, requests: list[backend_utils.InferenceRequest],
        is_prefill: bool = False, is_mix: bool = False) -> \
            list[backend_utils.InferenceResponse]:
        if is_log_enable():
            start_time = int(round(time.time() * 1000))
            logger.debug(f"[Model]\t>>> Enter generate()")
        responses = []
        
        request_tokens_np, eos_np, truncation_indices = self.__handle_requests(requests, is_prefill, is_mix)
        if self.rank == 0:
            responses = [None] * len(requests)
            if is_log_enable():
                output_start_time = int(round(time.time() * 1000))
            merge_tensors_pb = [
                ("OUTPUT_IDS", request_tokens_np),
                ("IBIS_EOS_ATTR", eos_np),
                ("TRUNCATION_INDICES", truncation_indices)
            ]
            responses = backend_utils.from_numpy_merge_tensors(merge_tensors_pb)
            if is_log_enable():
                spend_time = int(round(time.time() * 1000)) - output_start_time
                logger.debug(
                    f"[Model]\t>>>create response spend time: {spend_time}, batch size: {len(requests)}")


        if is_log_enable():
            stage = "decode"
            if is_prefill:
                stage = "prefill"
            spend_time = int(round(time.time() * 1000)) - start_time
            logger.debug(f"[Model]\t>>> rank-{self.rank} exec func spend time: {spend_time}, "
                        f"batch size: {len(requests)}, stage: {stage}, is_Mix is {is_mix}")
            self.total_time += spend_time
            logger.debug(f"[Model]\t>>> rank-{self.rank} total spend time: {self.total_time}")
        return responses

    def __get_input_metadata(self, is_prefill, requests, deep_copy=False):
        batch_input_ids = np.array([])
        batch_sampling = np.array([])
        batch_stop_token_ids = []
        batch_stop_strings = []
        batch_ignore_eos = []
        batch_skip_special_tokens = []
        batch_include_stop = []
        adapter_ids = []
        batch_tools = []
        batch_tool_choice = []
        block_op = requests[0].get_tensor_by_name("IBIS_BLOCK_OP")
        if block_op:
            self.generator.swap(block_op)

        gmis_metadata = np.array(requests[0].get_tensor_by_name("METADATA"), dtype=np.int64, copy=deep_copy)
        block_tables = np.array(requests[0].get_tensor_by_name("IBIS_BLOCK_TABLE"), copy=deep_copy)[0]
        batch_user_request_ids = None
        if is_prefill:
            batch_stop_strings = list(map(generate_stop_strings, requests))
            batch_input_ids = np.array(requests[0].get_tensor_by_name("INPUT_IDS"), dtype=np.int64, copy=deep_copy)
            batch_sampling = np.frombuffer(requests[0].get_tensor_by_name("SAMPLING"), dtype=SAMPLING_DTYPE).copy()
            for request in requests:
                stop_ids = np.array(request.get_tensor_by_name("STOP_TOKEN_IDS"), copy=deep_copy).tolist()
                batch_stop_token_ids.append(stop_ids[0] if stop_ids is not None else None)
                ignore = request.get_tensor_by_name("IGNORE_EOS")
                batch_ignore_eos.append(ignore.as_numpy()[0][0] if ignore is not None else None)
                special = request.get_tensor_by_name("SKIP_SPECIAL_TOKENS")
                batch_skip_special_tokens.append(special.as_numpy()[0][0] if special is not None else None)
                stop = request.get_tensor_by_name("INCLUDE_STOP_STR_IN_OUTPUT")
                batch_include_stop.append(stop.as_numpy()[0][0] if stop is not None else None)
            batch_user_request_ids = list(map(generate_user_request_id_string, requests))
            adapter_ids = list(map(generate_lora_strings, requests))
        batch_ignore_eos = np.array(batch_ignore_eos)
        batch_skip_special_tokens = np.array(batch_skip_special_tokens)
        batch_include_stop = np.array(batch_include_stop)

        computed_blocks = None
        computed = requests[0].get_tensor_by_name("IBIS_COMPUTED_NUM")
        if computed:
            computed_blocks = np.array(computed, copy=deep_copy)[0]
            if np.count_nonzero(computed_blocks) == 0:
                computed_blocks = None

        batch_req_ids = gmis_metadata[0]
        batch_seq_len = gmis_metadata[1]
        max_output_len = gmis_metadata[2]
        total_seq_len = sum(batch_seq_len)

        metadata = InputMetadata(
            batch_size=len(requests),
            batch_request_ids=batch_req_ids,
            batch_max_output_lens=max_output_len,
            block_tables=block_tables,
            max_block_size=self.block_size,
            has_sampling=True,
            is_prefill=is_prefill,
            input_ids_list=batch_input_ids,
            batch_seq_len=batch_seq_len,
            total_seq_num=total_seq_len,
            batch_sampling_param=batch_sampling,
            batch_stop_strings=batch_stop_strings,
            batch_stop_token_ids=batch_stop_token_ids,
            computed_blocks=computed_blocks,
            adapter_ids=adapter_ids,
            batch_tools=batch_tools,
            batch_tool_choice=batch_tool_choice,
            batch_ignore_eos=batch_ignore_eos,
            batch_skip_special_tokens=batch_skip_special_tokens,
            batch_include_stop=batch_include_stop,
            user_request_ids=batch_user_request_ids
        )
        return metadata

    def __pull_kvcache(self, requests):
        dst_block_tables = np.array(requests[0].get_tensor_by_name("IBIS_BLOCK_TABLE"), copy=False)[0]
        src_block_tables = np.array(requests[0].get_tensor_by_name("SRC_IBIS_BLOCK_TABLE"), copy=False)[0]
        gmis_metadata = np.array(requests[0].get_tensor_by_name("METADATA"), dtype=np.int64, copy=False)
        batch_req_ids = gmis_metadata[0]
        batch_seq_len = gmis_metadata[1]
        p_ip_block_table_map = {}
        for i, request in enumerate(requests):
            # compute req needed block num
            req_block_num = (batch_seq_len[i] + self.block_size - NON_KVCACHE_TOKEN_NUM - 1) // self.block_size
            src_block_table = src_block_tables[i][:req_block_num]
            dst_block_table = dst_block_tables[i][:req_block_num]

            if is_log_enable():
                logger.debug(
                    f"[Model]\t>>> rank-{self.rank} req_id: {batch_req_ids[i]} "
                    f"src_block_table: {src_block_table}, dst_block_table:{dst_block_table}")
            ibis_attr = np.array(request.get_tensor_by_name("IBIS_ATTR"), copy=False)[0]
            p_ip_int = ibis_attr[4]
            if p_ip_int not in p_ip_block_table_map.keys():
                p_ip_block_table_map[p_ip_int] = {}
                p_ip_block_table_map[p_ip_int][SRC_BLOCK_TABLE_KEY] = []
                p_ip_block_table_map[p_ip_int][DST_BLOCK_TABLE_KEY] = []
                p_ip_block_table_map[p_ip_int][REQ_INDEX] = []
            p_ip_block_table_map[p_ip_int][SRC_BLOCK_TABLE_KEY].extend(src_block_table)
            p_ip_block_table_map[p_ip_int][DST_BLOCK_TABLE_KEY].extend(dst_block_table)
            p_ip_block_table_map[p_ip_int][REQ_INDEX].append(i)

        pull_kv_items = []
        for p_ip_int, block_table in p_ip_block_table_map.items():
            p_src_block_tables = list(map(int, block_table[SRC_BLOCK_TABLE_KEY]))
            d_src_block_tables = list(map(int, block_table[DST_BLOCK_TABLE_KEY]))
            pull_kv_items.append((int(p_ip_int), p_src_block_tables, d_src_block_tables))
        metadata = self.__get_input_metadata(True, requests, True)
        total_receive_event = "rank_[" + str(self.rank) + "]," + "total_receive_time_batch[" + str(len(requests)) + "]"

        self.metrics.add_event_begin(total_receive_event)
        ret, remote_server_int = self.generator.pull_kv(metadata, pull_kv_items)
        self.metrics.add_event_end(total_receive_event)

        pull_kv_np = np.zeros((len(requests), 1), dtype=np.uint16)
        error = ModelWrapperErrorCode.SUCCESS
        if ret != MindieLlmErrorCode.SUCCESS:
            logger.error("pull kvcache failed!")
            error = ModelWrapperErrorCode.PD_PULL_KV_UNKNOW_ERROR if ret == MindieLlmErrorCode.PD_UNKNOW_ERROR else \
                ModelWrapperErrorCode.PD_PULL_KV_ERROR
            for index in p_ip_block_table_map.get(remote_server_int, {}).get(REQ_INDEX, []):
                if 0 <= index < len(requests):
                    pull_kv_np[index] = error.value
                else:
                    logger.error("pull kvcache failed request index is out of range")

        merge_tensors_pb = [("PULL_KV_RESULT", pull_kv_np)]
        responses = backend_utils.from_numpy_merge_tensors(merge_tensors_pb)
        return error, responses

    def __handle_requests(self, requests: list[backend_utils.InferenceRequest], is_prefill: bool, is_mix: bool = False):
        if is_log_enable():
            start_time = int(round(time.time() * 1000))
        if is_prefill:
            event_name = "rank [" + str(self.rank) + "]," + "req_prefill_batch[" + str(len(requests)) + "]"
        else:
            event_name = "rank [" + str(self.rank) + "]," + "req_decode_batch[" + str(len(requests)) + "]"
        self.metrics.add_event_begin(event_name)
        if self.is_mix_model:
            metadata = self.__get_input_metadata(is_prefill, requests, True)
            metadata = self.__update_mix_metadata(requests, metadata, is_prefill, is_mix)
        else:
            metadata = self.__get_input_metadata(is_prefill, requests)

        if is_log_enable():
            spend_time = int(round(time.time() * 1000)) - start_time
            logger.debug(
                f"[Model]\t>>> rank-{self.rank} make metadata spend time: {spend_time} "
                f"batch size: {len(requests)} "
                f"reqid is: {metadata.batch_request_ids}")
            if self.is_mix_model:
                logger.debug(
                f"[Model]\t>>> startpos is {metadata.split_start_position} endpos is {metadata.split_end_position}"
                f"reqid is: {metadata.batch_request_ids}")
            begin_time = time.time_ns()

        request_tokens_np, eos_np, _, truncation_indices = self.generator.generate_token(metadata)
        
        if request_tokens_np is None or eos_np is None:
            logger.error("request_tokens_np or eos_np is none")
            raise ValueError("request_tokens_np or eos_np is none")

        if request_tokens_np.shape is None or eos_np.shape is None:
            logger.error("request_tokens_np or eos_np shape is none")
            raise ValueError("request_tokens_np or eos_np shape is none")

        if request_tokens_np.shape[0] == 0 or eos_np.shape[0] == 0:
            logger.error("request_tokens_np or eos_np shape[0] must be not 0")
            raise ValueError("request_tokens_np or eos_np shape[0] must be not 0")

        if not np.all((request_tokens_np >= 0) & (request_tokens_np < 2**32)) or \
            not np.all((eos_np >= 0) & (eos_np < 2**32)):
            logger.error("request_tokens_np or eos_np data must be uint32")
            raise ValueError("request_tokens_np or eos_np data must be uint32")

        if is_log_enable():
            logger.debug(f"[Model]\t>>> rank-{self.rank} model spend time: { time.time_ns() - begin_time}")

        return request_tokens_np, eos_np, truncation_indices

    def __update_mix_metadata(self, requests, metadata, is_prefill, is_mix):
        _, _, decode_bs = self._get_batch_size(requests, is_prefill, is_mix)
        gmis_metadata = np.array(requests[0].get_tensor_by_name("METADATA"), dtype=np.int64, copy=True)
        is_prefill_pre_batch = gmis_metadata[1]
        split_start_pos = gmis_metadata[3]
        split_end_pos = gmis_metadata[4]
        batch_last_prompt = gmis_metadata[5]
        batch_seq_len = split_end_pos - split_start_pos
        total_seq_len = sum(batch_seq_len)

        # 相比PD竞争需要刷新的参数
        metadata.total_seq_num = total_seq_len
        metadata.batch_seq_len = batch_seq_len

        # 相比PD竞争需要新增的参数
        metadata.is_mix = is_mix
        metadata.mix_decode_bs = decode_bs
        metadata.split_start_position = split_start_pos
        metadata.split_end_position = split_end_pos
        metadata.batch_last_prompt = batch_last_prompt
        metadata.batch_is_prefill = is_prefill_pre_batch
        
        # 重新计算max_seq_len和block_table
        metadata.max_seq_len = max(metadata.split_end_position)
        max_block_num = np.count_nonzero(metadata.block_tables > -1, axis=-1).max()
        metadata.batch_block_tables = metadata.block_tables[:, :max_block_num].astype(np.int32)

        if is_log_enable():
            logger.debug(f"[Model]\t>>> Total TokenNum in this batch is {total_seq_len}")
        return metadata