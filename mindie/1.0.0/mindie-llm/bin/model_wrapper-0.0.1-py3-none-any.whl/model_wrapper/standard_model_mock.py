#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2024. All rights reserved.

import random
import numpy as np

import backend_utils
from .utils.log_util import logger, is_log_enable
from .utils.config import Config
from .utils.error import ModelWrapperErrorCode

RESPONSE_DEFAULT = 0
RESPONSE_EOS = 1
RESPONSE_CANCEL = 2


class StandardMockLLMPythonModel:
    def __init__(self):
        self.rank = 0
        self.eos_token = 2
        self.role = "None"

    def initialize(self, model_config: Config) -> dict[str, str]:
        if is_log_enable():
            logger.info(f"[Mock]\t rank-{self.rank}: model_config: {model_config}")
        self.rank = model_config.rank
        initialize_result = {
            "status": "ok",
            "npuBlockNum": "1024",
            "cpuBlockNum": "128",
            "maxPositionEmbeddings": "1048576"
        }
        if is_log_enable():
            logger.info(f"[Mock]\t rank-{self.rank}: return initialize result: {initialize_result}")
        return initialize_result

    def generate(self, requests: list[backend_utils.InferenceRequest]) -> list[
        backend_utils.InferenceResponse]:

        bs = len(requests)
        
        # 随机数模拟模型推理一轮后产生一个token
        random_int = random.randint(0, 20)
        eos = RESPONSE_EOS if random_int == self.eos_token else RESPONSE_DEFAULT

        out = np.array([[random_int] for _ in range(bs)], dtype=np.int64)

        # IBIS_EOS_ATTR 二维，第一位是flag，第二位是生成的token数量
        eos = np.array([[eos, out.shape[1]] for _ in range(bs)], dtype=np.int64)

        # TRUNCATION_INDICES 二维，假模型不支持停止词
        truncation_indices = np.array([[0, 0] for _ in range(bs)], dtype=np.int64)

        merge_tensors_pb = [
            ("OUTPUT_IDS", out), 
            ("IBIS_EOS_ATTR", eos), 
            ("TRUNCATION_INDICES", truncation_indices)
        ]

        responses = backend_utils.from_numpy_merge_tensors(merge_tensors_pb)

        return responses

    def execute(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str]):
        if is_log_enable():
            logger.info(
                f"[Mock]\t rank-{self.rank} enter execute, batch size:{len(requests)}, config:{config_map}")
        exec_op = config_map['EXECUTE_TYPE']

        if exec_op == '1':
            return self.prefill(requests)
        elif exec_op == '2':
            return self.decode(requests)
        elif exec_op == '3':
            return self.seqctrl(requests)
        else:
            if is_log_enable():
                logger.info("unknown exec operation")
            return []

    def transfer(self, requests: list[backend_utils.InferenceRequest], config_map: dict[str:str]):
        if is_log_enable():
            logger.info(
                f"[Model]\t>>> rank-{self.rank} enter transfer, batch size:{len(requests)}, config:{config_map}")
        exec_op = config_map['EXECUTE_TYPE']
        if exec_op == '4':
            return self.pd_role(requests, config_map)
        elif exec_op == '5':
            return self.force_p_release(requests, config_map)
        elif exec_op == '10':
            return self.pull_data(requests)
        else:
            logger.error("unknown exec operation")
            return []

    def pull_data(self, requests: list[backend_utils.InferenceRequest]):
        # 通知c++线程pull完成
        pull_kv_np = np.zeros((len(requests), 1), dtype=np.int8)

        merge_tensors_pb = [("PULL_KV_RESULT", pull_kv_np)]
        responses = backend_utils.from_numpy_merge_tensors(merge_tensors_pb)
        return ModelWrapperErrorCode.SUCCESS, responses

    def prefill(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        return self.generate(requests)

    def decode(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        return self.generate(requests)

    def warmup(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        for request in requests:
            req_id = np.array(request.get_tensor_by_name("IBIS_ATTR"), copy=False)[0][0]
            if is_log_enable():
                logger.info(f"[Mock]\t rank-{self.rank} enter execute, {req_id} do warm up")

        eos_np = np.array([[RESPONSE_CANCEL, 0] for _ in range(len(requests))], dtype=np.int64)
        responses = backend_utils.from_numpy_merge_tensors([("IBIS_EOS_ATTR", eos_np)])
        return responses

    def seqctrl(self, requests: list[backend_utils.InferenceRequest]) -> list[backend_utils.InferenceResponse]:
        for request in requests:
            req_id = np.array(request.get_tensor_by_name("IBIS_ATTR"), copy=False)[0][0]
            if is_log_enable():
                logger.info(f"[Mock]\t rank-{self.rank} enter execute, {req_id} do sequence ctrl")

        eos_np = np.array([[RESPONSE_CANCEL, 0] for _ in range(len(requests))], dtype=np.int64)
        responses = backend_utils.from_numpy_merge_tensors([("IBIS_EOS_ATTR", eos_np)])
        return responses

    def pd_role(self, requests: list[backend_utils.InferenceRequest], config_map) -> list[
        backend_utils.InferenceResponse]:
        responses = []
        result_numpy = np.array([0], dtype=np.int16)
        result_tensor = backend_utils.Tensor("FAILED_IP_ATTR", result_numpy)
        inference_response = backend_utils.InferenceResponse([result_tensor])
        responses.append(inference_response)

        return ModelWrapperErrorCode.SUCCESS, responses

    def force_p_release(self, requests: list[backend_utils.InferenceRequest], config_map) -> list[
        backend_utils.InferenceResponse]:
        responses = []
        result_numpy = np.array([0], dtype=np.int16)
        result_tensor = backend_utils.Tensor("FAILED_IP_ATTR", result_numpy)
        inference_response = backend_utils.InferenceResponse([result_tensor])
        responses.append(inference_response)

        return ModelWrapperErrorCode.SUCCESS, responses

    def set_pd_role(self, role):
        if role == 1:
            self.role = "prefill"
        elif role == 2:
            self.role = "decode"
        else:
            self.role = "unknown"

        if is_log_enable():
            logger.info(f"[Config]\t>>> set PD role finish. PD role is: {self.role}")


    def finalize(self):
        del self.eos_token
        del self.rank
        if is_log_enable():
            logger.info("Cleaning up...")
        return 0
