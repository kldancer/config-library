#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import os
import time
import uuid
from abc import abstractmethod, ABC
from collections import defaultdict

import numpy
from gevent.pool import Pool

from mindiebenchmark.common.tokenizer import BenchmarkTokenizer
from mindiebenchmark.common.config import Config
from mindiebenchmark.common.datasetloaders.base_loader import BaseLoader, extract_dataset_type_info
from mindiebenchmark.common.logging import Logger
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.inference.middle_result import MiddleResult


class BaseClient(ABC):
    """Base client of benchmark.

    This class is the abstract of different clients. Its duty includes reading data from dataloader,
    sending request to server, receiving response from server, recording some information to
    calculate performance metrics and saving the inference results etc.
    """
    def __init__(self, client_config: Config, result_container: ResultData, gevent_pool_size: int = 16,
                 dataloader: BaseLoader | None = None):
        """Initialize the instance of benchmarker that in client mode.

        Args:
            client_config (Config): Configuration for client instance.
            result_container (ResultData): It stores the generated information during inference to
                calculate the metrics.
            gevent_pool_size(int): Maximum coroutines at the same time during pressure test. It
                should be less than maximum connections allowed.
            dataloader (BaseLoader | None): The dataloader load data and convert to specific format.
        """

        def new_middle():
            return MiddleResult()

        self.max_conn = client_config.get_config("MAX_LINK_NUM")
        self.logger = Logger().logger
        self._config = client_config
        self.results = result_container
        self.model_name = client_config.get_command_line_arg("ModelName")
        model_version = client_config.get_command_line_arg("ModelVersion")
        self.model_version = model_version if model_version else ""
        self.max_new_token = client_config.get_command_line_arg("MaxOutputLen")
        self.server_url = client_config.get_command_line_arg("Http")
        self.warm_up_size = client_config.get_command_line_arg("WarmupSize")
        self.management_url = client_config.get_command_line_arg("ManagementHttp")
        self._client_instance = self.init_client()
        pool_size = min(gevent_pool_size, self.max_conn)
        self._geven_group = Pool(size=pool_size)
        self.dataloader = dataloader
        self.do_sampling = client_config.get_command_line_arg("DoSampling")
        if self.do_sampling:
            self.logger.info("DoSampling enable.")
        else:
            self.logger.info("DoSampling is disabled")
        self.sample_params = client_config.get_command_line_arg("SamplingParams")
        self.logger.info("sampling params is %s", self.sample_params)
        self.validate_sample_parameters()
        self.result_caching = defaultdict(new_middle)
        self.dataset_type = client_config.get_command_line_arg("DatasetType")
        self.dataset_path = client_config.get_command_line_arg("DatasetPath")
        self.req_result_data = {}

        self.test_acc = client_config.get_command_line_arg("TestAccuracy")
        self.logger.info("Client init finished. Gevent pool size is %d, max connection for mindie-client is %d.",
                         pool_size, self.max_conn)
        if self.dataloader.dataset_type == "synthetic":
            self.logger.warning("--MaxOutputLen will be ignored when --DatasetType is 'synthetic'")

    @abstractmethod
    def init_client(self):
        pass

    @abstractmethod
    def validate_sample_parameters(self):
        pass

    @abstractmethod
    def request(self, req_id: str, data):
        """Send request to server based on given data.

        Args:
            req_id (str): Unique request id.
            data (any): The data will send to server to execute reference.
        """
        pass

    def inc_total_req(self):
        if self.results.total_req % 10 == 0:
            self.logger.info("Total %d requests are sent to server, %d returned, %d empty.",
                             self.results.total_req,
                             self.results.returned_req, self.results.empty_req)
        self.results.add_total_req()

    def process_input_data(self, data, rrid: str):
        if not isinstance(data, str):
            return data
        if self.dataloader:
            self.result_caching[rrid].num_input_tokens = len(
                BenchmarkTokenizer.encode(data, self.results.tokenizer_time))
        else:
            self.result_caching[rrid].num_input_tokens = len(data)
        self.result_caching[rrid].num_input_chars = len(data)
        return data

    def prepare_input(self, data_dict: dict):
        """Prepare data according to input data dict, ready for connection with endpoint.

        Args:
            data_dict (dict): It should have keys `data` and `id`.

        Returns:
            rrid (str): Unique identifier for each request.
            data (ndarray or string): The input text ro token-ids that will input to server.
        """
        if not all(key in data_dict for key in ("data", "id")):
            raise RuntimeError(f"Input data must have `id` and `data` key but got {data_dict.keys()}")
        data = data_dict.get("data")
        rrid = uuid.uuid4().hex
        self.result_caching[rrid].request_id = rrid
        self.result_caching[rrid].data_id = data_dict.get("id")
        self.result_caching[rrid].input_data = data
        self.result_caching[rrid].data_option = data_dict.get("options", [])
        return rrid, self.process_input_data(data, rrid)

    def report_results(self):
        """After finishing the task, convert the cached content to final result."""
        if not self.result_caching:
            self.logger.error("[MIE01E000005] All requests failed, please check dataset path or other settings.")
            return
        total_start = min([item.start_time for _, item in self.result_caching.items()])
        total_end = max([item.end_time for _, item in self.result_caching.items()])
        self.logger.info("Converting middle results to final results...")
        self.results.total_time_elapsed = total_end - total_start
        all_results = [result.convert_to_standard() for _, result in self.result_caching.items()]
        self.results.add_req_res(all_results)
        self.results.extract_results_per_request(self.req_result_data)

    def data_handler(self, data_dict: dict):
        self.inc_total_req()
        req_id, data = self.prepare_input(data_dict)
        try:
            self.result_caching[req_id].start_time = time.time()
            self.request(req_id, data)
            self.result_caching[req_id].end_time = time.time()
            self.result_caching[req_id].req_latency = \
                (self.result_caching[req_id].end_time - self.result_caching[req_id].start_time) * 1000
            self.results.add_returned_req()
            if self.result_caching[req_id].num_generated_tokens:
                self.results.add_success_req()
            else:
                self.logger.error("[MIE01E000009] Request with data id %s encounters empty response!",
                                  data_dict.get("id", "<Unknown-id>"))
                self.result_caching.pop(req_id)
                self.results.add_empty_req()
            self.save_req_result_data(req_id)
            if self.results.returned_req % 10 == 0:
                self.logger.info("Total %d requests are sent to server, %d returned, %d empty.",
                                 self.results.total_req,
                                 self.results.returned_req, self.results.empty_req)
        except Exception as e:
            self.logger.error("[MIE01E000008] Request %s occurs error with message %s. Invalid response format, "
                              "please check the message in mindie-client.", req_id, e)
            self.result_caching.pop(req_id, None)
            return ""
        return self.result_caching[req_id].output

    def run_sync_task(self, data_queue):
        """Run inference task synchronously.

        This is the entrance of run inference task, it will choose specific handler according to
        the client type.

        Args:
            data_queue (Queue): Data queue, a `get` method will be used to pop the front data in queue.
        """
        data_handler = self.data_handler
        if self.warm_up_size:
            self._warm_up(self.warm_up_size)
        self._delay_request(data_handler, data_queue)
        self._geven_group.join()
        self.logger.info("Handling %d requests, failed %d",
                         self.results.total_req, (self.results.total_req - self.results.success_req))
        self.save_results()
        # to sync results to Results
        self.report_results()

    def save_results(self):
        pass

    def save_req_result_data(self, req_id: str):
        pass

    def _warm_up(self, warm_up_size: int):
        pass

    def _delay_request(self, data_handler, data_queue):
        def get_request_type_and_rate():
            request_send_rate = self._config.command_line_args.get("RequestRate")
            if not request_send_rate:
                return None, None
            rate = request_send_rate[self.results.result_id]
            if not rate:
                raise ValueError("Request Rate must be > 0, failed to send request.")
            request_send_type = self._config.command_line_args.get("Distribution")
            if request_send_type not in ['uniform', 'poisson']:
                raise ValueError("Distribution must be uniform or poisson, failed to send request.")
            return request_send_type, rate

        def multi_rounds_handler(data_handler, data_dict: dict):
            hist_arr = []
            data_str = 'data'
            id_str = 'id'
            for i in range(len(data_dict[data_str])):
                turn_id = str(data_dict[id_str]) + '_' + str(i)
                hist_arr.append(data_dict[data_str][i])
                input_data = {
                    'id': turn_id,
                    'data': ''.join(hist_arr),
                    'options': []
                }
                hist_arr.append(data_handler(input_data))

        try:
            request_send_type, rate = get_request_type_and_rate()
        except ValueError as e:
            self.logger.error(e)
            return
        data_dict = data_queue.get()
        dataset_name, _ = extract_dataset_type_info(self.dataset_type)
        while data_dict is not None:
            if dataset_name == 'mtbench':
                self._geven_group.spawn(multi_rounds_handler, data_handler, data_dict)
            else:
                self._geven_group.spawn(data_handler, data_dict)
            if request_send_type == 'uniform':
                time.sleep(numpy.random.uniform(0, 1.0 / rate * 2))
            elif request_send_type == 'poisson':
                time.sleep(numpy.random.exponential(1.0 / rate))
            data_dict = data_queue.get()
