#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import json
import os
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field

import numpy
from gevent.pool import Pool
from text_generation import Client

from mindiebenchmark.common.tokenizer import BenchmarkTokenizer
from mindiebenchmark.common.datasetloaders import CocotestLoader
from mindiebenchmark.common.datasetloaders.base_loader import BaseLoader
from mindiebenchmark.common.file_utils import PathCheck
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.common.config import Config
from mindiebenchmark.common.logging import Logger


class TGIClient():
    """A class for tgi(text-generation-inference) inference.

    This class provides api to send request in tgi format to server and get the returned data. The
    request and response information (e.g. send request time) will be recorded to calculate the
    metrics of inference.
    """
    # prepare_input 从 dataloader 读取数据 放到 MiddleResult
    # 每推理完一个token，根据MiddleResult的id存放对应的数据和性能
    @dataclass
    class MiddleResult:
        data_id: str = ''
        input_data: str = ''
        num_input_tokens: int = 0
        num_input_chars: int = 0
        num_generated_tokens: int = 0
        num_generated_chars: int = 0
        prefill_latency: float = .0
        decode_cost: list[float] = field(default_factory=list)
        req_latency: float = .0
        decode_batch_size: list[int] = field(default_factory=list)
        prefill_batch_size: int = 0
        post_process_time: float = .0
        tokenized_time: float = .0
        detokenized_time: float = .0
        queue_wait_time: list[float] = field(default_factory=list)
        data_option: list = field(default_factory=list)
        output: str = ""
        output_token_id: list[int] = field(default_factory=list)
        start_time: float = .0
        end_time: float = .0
        request_id: str = ''

        def is_valid(self):
            """To ensure valid results"""
            return all([self.num_input_tokens, self.num_input_chars,
                        self.num_generated_tokens, self.num_generated_chars, self.decode_cost])

        def convert_to_standard(self) -> dict:
            try:
                chars = self.num_generated_chars / self.num_generated_tokens
            except ZeroDivisionError:
                chars = 0.0
            return {
                "id": self.data_id,
                "input_data": self.input_data,
                'prefill_latencies': self.prefill_latency,
                'decode_token_latencies': self.decode_cost[:],
                'decode_max_token_latencies': max(self.decode_cost) if self.decode_cost else .0,
                'seq_latencies': self.req_latency,
                'input_tokens_len': self.num_input_tokens,
                'generate_tokens_len': self.num_generated_tokens,
                'generate_characters_len': self.num_generated_chars,
                'prefill_batch_size': self.prefill_batch_size,
                'decode_batch_size': self.decode_batch_size[:],
                'queue_wait_time': self.queue_wait_time[:],
                'post_processing_time': self.post_process_time,
                'tokenizer_time': self.tokenized_time,
                'detokenizer_time': self.detokenized_time,
                'output': self.output,
                'output_token_id': self.output_token_id,
                'characters_per_token': chars,
                'request_id': self.request_id,
            }

    def __init__(self, client_config: Config, result_container: ResultData, dataloader: BaseLoader,
                 concurrency: int):
        """Initialize tgi client.

        Args:
            client_config (Config): Configuration for client instance.
            result_container (ResultData): It stores the generated information during inference to
                calculate the metrics.
            dataloader (BaseLoader): The dataloader of benchmark.
            concurrency (int): The concurrency means the number of connections between client and
                server.
        """
        self.logger = Logger().logger
        self._config = client_config
        self.max_new_token = client_config.get_command_line_arg("MaxOutputLen")
        url = client_config.get_command_line_arg("Http")
        self.tgi_client = Client(url, timeout=60)

        def new_middle():
            return TGIClient.MiddleResult()

        self.result_caching = defaultdict(new_middle)

        self.results = result_container
        self.dataloader = dataloader
        self._geven_group = Pool(size=concurrency)

    def run_tgi_sync_task(self, data_queue):
        data_dict = data_queue.get()
        while data_dict is not None:
            self._geven_group.spawn(self.generate_text_stream, data_dict)
            data_dict = data_queue.get()
        self._geven_group.join()
        self.logger.info("Handling %d requests, failed %d",
                         self.results.total_req, (self.results.total_req - self.results.success_req))
        if self._config.get_command_line_arg("DatasetType") == "cocotest":
            self.save_cocotest_result()
        # to sync results to Results
        self.report_results()

    def save_cocotest_result(self):
        result_dict = {}
        for _, result in self.result_caching.items():
            file_path = result.input_data[len(CocotestLoader.TGI_PREFIX): -len(CocotestLoader.TGI_POSIX)]
            result_dict[os.path.basename(file_path)] = result.output
        save_path = os.path.join(self._config.get_command_line_arg("DatasetPath"), "result.json")
        ret, infos = PathCheck.check_path_link(save_path)
        if not ret:
            raise ValueError(f"Invalid Cocotest result path: {infos}")
        with os.fdopen(os.open(save_path, os.O_CREAT | os.O_WRONLY, 0o640), "w") as file:
            json.dump(result_dict, file)

    def report_results(self):
        """After finishing the task, convert the cached content to final result."""
        total_start = min([item.start_time for _, item in self.result_caching.items()])
        total_end = max([item.end_time for _, item in self.result_caching.items()])
        self.logger.info("Converting middle results to final results...")
        self.results.total_time_elapsed = total_end - total_start
        all_results = [result.convert_to_standard() for _, result in self.result_caching.items()]
        self.results.add_req_res(all_results)

    def prepare_input(self, data_dict: dict):
        if all(key in data_dict for key in ("data", "id")):
            data = data_dict.get("data")
            data_id = data_dict.get("id")
        else:
            raise RuntimeError(f"Input data must have `id` and `data` key but got {data_dict.keys()}")
        options = data_dict.get("options", [])
        rrid = uuid.uuid4().hex
        self.result_caching[rrid].request_id = rrid
        self.result_caching[rrid].data_id = data_id
        self.result_caching[rrid].input_data = data
        self.result_caching[rrid].data_option = options[:]
        if isinstance(data, list):
            # convert list to ndarray
            data = numpy.array(data, dtype=int)
            if data.ndim == 1:
                data = numpy.expand_dims(data, axis=0)
            num_tokens = data.shape[-1]
            self.result_caching[rrid].num_input_tokens = num_tokens
            self.result_caching[rrid].num_input_chars = num_tokens
        elif isinstance(data, str):
            if self.dataloader is None:
                self.result_caching[rrid].num_input_tokens = len(data)
            else:
                encode_out = BenchmarkTokenizer.encode(data)
                self.result_caching[rrid].num_input_tokens = len(encode_out)
            self.result_caching[rrid].num_input_chars = len(data)
        elif isinstance(data, numpy.ndarray):
            num_tokens = data.shape[-1]
            self.result_caching[rrid].num_input_tokens = num_tokens
            self.result_caching[rrid].num_input_chars = num_tokens

        return rrid, data

    def inc_total_req(self):
        if self.results.total_req % 10 == 0:
            self.logger.info("Total %d requests are sent to server, %d returned, %d empty.",
                             self.results.total_req,
                             self.results.returned_req, self.results.empty_req)
        self.results.add_total_req()

    def get_sampling_params(self):
        do_sample = self._config.get_command_line_arg("DoSampling")
        param_cfg = self._config.get_command_line_arg("SamplingParams")
        if not param_cfg:
            param_cfg = {}
        if do_sample:
            self.logger.info("DoSampling enable.")
            param_cfg["do_sample"] = True
        return param_cfg

    def generate_text_stream(self, data_dict: dict):
        """Run stream inference for tgi.

        This method will send request and get the returned data from server.

        Args:
            data_dict (dict): The data that will send to server as json format. It includes full
                request information, e.g. prompt and sampling parameters. The dict follows the
                format provides by TGI.
        """
        req_id, prompt = self.prepare_input(data_dict)
        gen_params = self.get_sampling_params()
        gen_params.update({"max_new_tokens": self.max_new_token})
        self.inc_total_req()
        first_token_time = None
        decoded_times = []
        num_generated_chars = 0
        num_generated_tokens = 0
        outputs = []
        output_token_id = []
        self.result_caching[req_id].start_time = generate_start = start = time.time()
        for response in self.tgi_client.generate_stream(prompt=prompt, **gen_params):
            if response.token.special:
                break
            outputs.append(response.token.text)
            output_token_id.append(response.token.id)
            time_elapsed = time.time() - start
            if num_generated_tokens == 0:
                first_token_time = time_elapsed
            else:
                decoded_times.append(time_elapsed)
            num_generated_tokens += 1
            num_generated_chars += len(response.token.text)
            start = time.time()
        self.result_caching[req_id].end_time = generate_end = time.time()
        self.results.add_returned_req()
        output_str = "".join(outputs)
        if first_token_time is None:
            self.logger.error("Request with data id %s encounter empty response !",
                              data_dict.get("id", "<Unknown-id>"))
            self.result_caching.pop(req_id)
            self.results.add_empty_req()
            return
        self.result_caching[req_id].num_input_chars = len(prompt)
        self.result_caching[req_id].prefill_latency = first_token_time * 1000
        self.result_caching[req_id].req_latency = (generate_end - generate_start) * 1000
        self.result_caching[req_id].num_generated_tokens = num_generated_tokens
        self.result_caching[req_id].num_generated_chars = num_generated_chars
        self.result_caching[req_id].decode_cost = [cost * 1000 for cost in decoded_times]
        self.result_caching[req_id].output = output_str
        self.result_caching[req_id].output_token_id = output_token_id
        self.results.add_success_req()
