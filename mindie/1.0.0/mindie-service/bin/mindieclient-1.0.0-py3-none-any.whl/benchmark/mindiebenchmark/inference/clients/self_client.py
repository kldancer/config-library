#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import json
import os
import time
import uuid
import copy
from abc import ABC, abstractmethod

import signal
from threading import Lock
from collections import defaultdict

import gevent

import urllib3

from mindiebenchmark.common.config import Config
from mindiebenchmark.common.datasetloaders.base_loader import BaseLoader
from mindiebenchmark.common.exceptions import BenchmarkServerException
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.common.logging import Logger
from mindiebenchmark.common.params_check import check_keys, check_type_and_range

from mindieclient.python.httpclient.utils import MindIEClientException
from mindieclient.python.httpclient import MindIEHTTPClient
from .base_client import BaseClient


class MindHTTPClientPatch(MindIEHTTPClient):
    """MindIE http client.

    This class encapsulates the mindie http client provided by mindieclient package.
    """
    def __init__(
            self,
            url,
            greenlet_size=None,
            ssl_options=None,
            network_timeout=600.0,
            connection_timeout=600.0,
            concurrency=1,
            verbose=False,
            enable_management=False,
            management_url="https://127.0.0.2:1026",
    ):
        """Initialize.

        Args:
            url (str): The request url, it's the server listen url as well.
            greenlet_size (_type_, optional): _description_. Defaults to None.
            ssl_options (_type_, optional): _description_. Defaults to None.
            network_timeout (float, optional): _description_. Defaults to 600.0.
            connection_timeout (float, optional): _description_. Defaults to 600.0.
            concurrency (int, optional): _description_. Defaults to 1.
            verbose (bool, optional): _description_. Defaults to False.
            enable_management (bool, optional): _description_. Defaults to False.
            management_url (str, optional): _description_. Defaults to "https://127.0.0.2:1026".
        """
        super().__init__(url, greenlet_size=greenlet_size, ssl_options=ssl_options, enable_ssl=url.startswith("https"),
                         network_timeout=network_timeout, connection_timeout=connection_timeout,
                         concurrency=concurrency, verbose=verbose, enable_management=enable_management,
                         management_url=management_url)
        self.table = defaultdict(float)
        self.lock = Lock()
        self._net_timeout = network_timeout
        self._conn_timeout = connection_timeout
        self.total_url = url

    def get_latency(self, rid: str):
        return self.table.get(rid, None)

    def get_requests_list(self):
        requests_list = super()._get_requests_list()
        if requests_list is not None:
            Logger().logger.info("Success to get requests list.")
        else:
            Logger().logger.error("Failed to get requests list.")
        return requests_list

    def _post(self, request_uri, request_body):
        start = time.time()
        resp = super()._post(request_uri=request_uri, request_body=request_body)
        delta = time.time() - start
        rrid = json.loads(request_body).get("id")
        with self.lock:
            self.table[rrid] = delta
        return resp


class SelfClient(BaseClient, ABC):
    """MindIE client.

    This client can communicate with mindie server.
    """
    def __init__(self, client_config: Config, result_container: ResultData, gevent_pool_size: int = 16,
                 dataloader: BaseLoader | None = None):
        self.enable_management = client_config.get_config("ENABLE_MANAGEMENT")
        super().__init__(client_config, result_container, gevent_pool_size, dataloader)
        self.reset_states()
        self.check_if_ready()
        # 优雅退出，检测Ctrl+C
        gevent.signal_handler(signal.SIGINT, self.graceful_exit)

    def validate_sample_parameters(self):
        pass

    def graceful_exit(self):
        self.logger.info("Detected Ctrl+C. Begin to graceful exit.")
        urllib3.PoolManager().clear()
        self.dataloader.stop_load()
        requests_list = copy.deepcopy(self._client_instance.get_requests_list())
        cancel_idx = 0
        for requests in requests_list:
            self._client_instance.cancel(self.model_name, requests)
            if (cancel_idx + 1) % 10 == 0:
                self.logger.info("Already cancel %d/%d requests from requests lists.",
                                cancel_idx + 1, len(requests_list))
            cancel_idx += 1
        self.logger.info("Already send %d cancel requests from requests lists.", len(requests_list))
        pid_id = os.getpid()
        self.logger.info("Begin to terminate pid with id: %d", pid_id)
        os.kill(pid_id, signal.SIGTERM)

    def get_ssl_options(self):
        def check_single(fn: str) -> bool:
            return fn is not None and os.path.exists(fn) and os.path.isfile(fn)

        ssl_options = {}
        enable_ssl = self.server_url.startswith("https")
        if not enable_ssl:
            return ssl_options

        ssl_config_key_map = {
            "ca_certs": "CA_CERT",
            "keyfile": "KEY_FILE",
            "certfile": "CERT_FILE",
            "crlfile": "CRL_FILE"
        }
        for ssl_key, config_key in ssl_config_key_map.items():
            config_val = self._config.get_config(config_key)
            if check_single(config_val):
                ssl_options[ssl_key] = config_val
        if all(ssl_key in ssl_options.keys() for ssl_key in list(ssl_config_key_map.keys())[:3]):
            return ssl_options
        raise RuntimeError("Invalid ssl options when using https protocol.")

    def init_client(self):
        try:
            return MindHTTPClientPatch(
                url=self.server_url,
                ssl_options=self.get_ssl_options(),
                concurrency=self.max_conn,
                enable_management=self.enable_management,
                management_url=self.management_url
            )
        except MindIEClientException as e:
            self._client_instance = None
            raise RuntimeError(f"Client instance initialization error with message "
                               f"{e.get_message()} Please check your config!") from e
        except Exception as e:
            self._client_instance = None
            raise RuntimeError(f"Client instance initialization error with message "
                               f"{e} Please check your config!") from e

    def reset_states(self):
        self.logger.info("Reset states...")
        self.results.total_req = 0
        self.results.success_req = 0
        self.results.empty_req = 0
        self.results.returned_req = 0
        self.result_caching.clear()

    def check_if_ready(self):
        if not self.enable_management:
            self.logger.warning("[MIE01W000102] Do not check the status of server because management port is disabled")
            return
        if not self._client_instance.is_server_ready():
            raise BenchmarkServerException(f"Server {self.server_url} is not ready !!!")
        if not self._client_instance.is_server_live():
            raise BenchmarkServerException(f"Server {self.server_url} is not alive !!!")
        if not self._client_instance.is_model_ready(self.model_name, self.model_version):
            raise BenchmarkServerException(f"Model {self.model_name} ver. {self.model_version} is not ready on "
                                           f"server {self.server_url} !!!")

    def save_req_result_data(self, req_id: str):
        self.req_result_data[self.result_caching[req_id].data_id] = {
            "input_len": self.result_caching[req_id].num_input_tokens,
            "output_len": max(self.result_caching[req_id].num_generated_tokens, 1),
            "prefill_bsz": self.result_caching[req_id].prefill_batch_size,
            "decode_bsz": self.result_caching[req_id].decode_batch_size,
            "req_latency": self.result_caching[req_id].req_latency,
            "latency": [self.result_caching[req_id].prefill_latency] + self.result_caching[req_id].decode_cost,
            "queue_latency": self.result_caching[req_id].queue_wait_time,
            "input_data" : self.result_caching[req_id].input_data,
            "output": self.result_caching[req_id].output
        }

    def _warm_up(self, warm_up_size: int):
        self.logger.info("Warm up start...")
        question = ("Claire makes a 3 egg omelet every morning for breakfast.  "
                    "How many dozens of eggs will she eat in 4 weeks?")
        data_dict = {"id": "warm_up", "data": question, "options": []}
        count = 0
        warm_start = time.time()
        for _ in range(warm_up_size):
            new_data_dict = data_dict.copy()
            new_data_dict["id"] = f"warm_up_{count}_{uuid.uuid4().hex}"
            self._geven_group.spawn(self._warm_up_func, new_data_dict)
            count += 1
        self._geven_group.join()
        time_elasped = time.time() - warm_start
        self.logger.info("Warm up finished. Handling %d requests, cost warm up time %.3f seconds",
                         warm_up_size, time_elasped)

    def _warm_up_func(self, data_dict):
        req_id, prompt = data_dict["id"], data_dict["data"]
        try:
            self._client_instance.generate(model_name=self.model_name, prompt=prompt,
                                           parameters=self.sample_params,
                                           request_id=req_id, model_version=self.model_version)
        except MindIEClientException as e:
            self.logger.error("[MIE01E000108] Warm up request failed, request %s occurs error with message %s.",
                              req_id, e.get_message())
            return
        except Exception as e:
            self.logger.error("[MIE01E000108] Warm up request failed, request %s occurs error with message %s. "
                              "Please check the response in mindieclient",
                              req_id, str(e))
            return
