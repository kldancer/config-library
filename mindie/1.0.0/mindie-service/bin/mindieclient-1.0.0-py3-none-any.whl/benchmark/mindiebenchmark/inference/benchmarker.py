#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import queue
import os
import time

from mindiebenchmark.common.tokenizer import BenchmarkTokenizer
from mindiebenchmark.common.datasetloaders import DatasetLoaderFactory
from mindiebenchmark.common.logging import Logger
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.common.config import Config
from mindiebenchmark.inference.clients import ClientFactory
from mindiebenchmark.inference.vllm_client import VLLMClient
from mindiebenchmark.inference.triton_client import TritonClient
WAITING_MASTER_NODE_FINISH = 10


class BaseBenchmark:
    def __init__(self, config: Config):
        self.logger = Logger().logger
        self.config = config
        self.test_type = self.config.get_command_line_arg("TestType")
        self.generate_stream = self.config.get_command_line_arg("GenerateStream")
        self.model_name = self.config.get_command_line_arg("ModelName")
        self.tokenizer = self.config.get_command_line_arg("Tokenizer")
        self.test_accuracy = self.config.get_command_line_arg("TestAccuracy")
        self.dataset_type = self.config.get_command_line_arg("DatasetType")
        self.concurrency = self.config.get_command_line_arg("Concurrency")
        self.task_kind = self.config.get_command_line_arg("TaskKind")
        self.results = ResultData(config.command_line_args)
        BenchmarkTokenizer.init(
            model_path=self.config.get_command_line_arg("ModelPath"),
            trust_remote_code=self.config.get_command_line_arg("TrustRemoteCode")
        )
        self.queue = queue.Queue(1000)
        self.loader = DatasetLoaderFactory.make_dataset_loader_instance(
            self.config.command_line_args, self.queue, self.results)
        self.loader.start()
        self.results.set_loader(self.loader)


    def run(self) -> bool:
        self.logger.info("Starting benchmark...")
        if self.test_type == "engine":
            self.run_engine()
            return True
        else:
            self.run_client()
            return True

    def run_engine(self):
        pass

    def run_client(self):
        pass


class GPTBenchmark(BaseBenchmark):
    def __init__(self, config: Config):
        super().__init__(config)
        self.infer_engine = None
        self.is_multi_nodes_infer = False
        self.is_master_ip = False

        try:
            if self.config.get_command_line_arg("TestType") in ("engine", "client"):
                self.is_multi_nodes_infer = self.config.validate_multi_nodes_infer()

            if self.is_multi_nodes_infer:
                self.is_master_ip = self.config.validate_master_ip()
                self.logger.info("MULTI MACHINE is running")
                if self.is_master_ip:
                    self.logger.info("Multi machine is running in [master] machine node")
                else:
                    self.logger.info("Multi machine is running in [slave] machine node")
            else:
                self.logger.info("SINGLE MACHINE is running")
        except Exception as error:
            self.logger.error(f'[MIE01E000002] Failed to initialize benchmark, please check benchmark '
                              f'and server settings')
            self.loader.stop_load()
            self.loader.join()
            raise RuntimeError("Failed to initialize benchmark, please check benchmark and server settings") from error

    def run(self) -> bool:
        is_ok = super().run()
        self.results.save_eval_results()
        return is_ok

    def init_infer_engine(self):
        from mindiebenchmark.inference.async_inference_engine import InferenceEngine
        self.logger.info("Starting initializing benchmark[engine mode]")
        self.infer_engine = InferenceEngine(self.config, self.queue, self.loader, self.results)

    def infer_engine_finalize(self):
        self.logger.info("Starting finalizing benchmark[engine mode]")
        self.infer_engine.finalize()

    def run_engine(self):
        self.logger.info("Starting run engine inference")
        try:
            if self.is_master_ip or not self.is_multi_nodes_infer:
                self.infer_engine.async_forward()
            else:
                while True:
                    self.logger.info("Waiting for master machine to finish infer...")
                    time.sleep(WAITING_MASTER_NODE_FINISH)
        except Exception as error:
            self.logger.error(f'[MIE01E000009] {str(error)}')
            self.loader.stop_load()
            self.loader.join()
            if self.infer_engine:
                self.infer_engine.stop_infer()

    def run_client(self):
        try:
            if self.test_type == "tgi_client":
                self.logger.info("Starting run TGI inference")
                from mindiebenchmark.inference.tgi_client import TGIClient
                client = TGIClient(self.config, result_container=self.results,
                                dataloader=self.loader, concurrency=self.concurrency)
                client.run_tgi_sync_task(self.queue)
            elif self.test_type == "vllm_client":
                self.logger.info("Starting run vllm inference")
                client = VLLMClient(self.config, result_container=self.results, dataloader=self.loader)
                client.run_vllm_sync_task(self.queue)
            elif self.test_type == "triton_client":
                self.logger.info("Starting run triton inference")
                client = TritonClient(self.config, result_container=self.results, dataloader=self.loader)
                client.run_triton_sync_task(self.queue)
            else:
                self.logger.info("Starting run mindie-client inference")
                client = ClientFactory.make_client_instance(self.config, self.results, self.concurrency, self.loader)
                client.run_sync_task(self.queue)
        except Exception as error:
            self.logger.error(f'[MIE01E000009] {str(error)}')
            self.loader.stop_load()
            self.loader.join()
            raise RuntimeError("Failed to run client") from error
