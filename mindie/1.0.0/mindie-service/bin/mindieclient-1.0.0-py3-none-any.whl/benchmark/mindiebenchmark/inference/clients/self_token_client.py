#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import numpy

from mindiebenchmark.common.params_check import check_type_and_range
from .self_client import SelfClient


class SelfTokenClient(SelfClient):
    """This class is a client that supports send token-ids (instead of text) to server.
    """
    def process_input_data(self, data, rrid: str):
        data_arr = numpy.array(data, dtype=numpy.uint32)
        if data_arr.ndim == 1:
            data_arr = numpy.expand_dims(data_arr, axis=0)
        self.result_caching[rrid].num_input_tokens = data_arr.shape[-1]
        self.result_caching[rrid].num_input_chars = data_arr.shape[-1]
        return data_arr

    def get_inference_params(self):
        params = {
            "details": True,
            "max_new_tokens": self.max_new_token,
            "do_sample": self.do_sampling
        }
        params.update(self.sample_params)
        return params

    def request(self, req_id: str, data: list):
        outputs = []
        for res_ in self._client_instance.generate_stream_self(token=data, request_id=req_id,
                                                               parameters=self.get_inference_params()):
            text_output = res_["token"]["text"]
            if text_output is None:
                break
            outputs.append(text_output)
            if not self.result_caching[req_id].num_generated_tokens:
                self.result_caching[req_id].prefill_latency = res_["prefill_time"]
            else:
                self.result_caching[req_id].decode_cost.append(res_["decode_time"])
            self.result_caching[req_id].num_generated_tokens += 1
            self.result_caching[req_id].num_generated_chars += len(text_output)

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "temperature":        ((float, int), ''),
            "top_k":              ((int, ), int32_range),
            "top_p":              ((float, int), ''),
            "seed":               ((int, ), int64_range),
            "repetition_penalty": ((float, int), '(0.0, +inf)'),
            "typical_p":          ((float, int), ''),
            "watermark":          ((bool, ), ''),
            "priority":           ((int, ), int64_range),
            "timeout":            ((int, ), int64_range)
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)
