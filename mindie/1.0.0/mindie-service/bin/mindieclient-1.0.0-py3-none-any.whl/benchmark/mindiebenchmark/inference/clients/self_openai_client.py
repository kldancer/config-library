#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import json

from mindiebenchmark.common.params_check import check_type_and_range
from .self_client import SelfClient

TEXT_OUTPUT_STR = "text_output"


class SelfOpenaiTextClient(SelfClient):
    """MindIE developed client which supports OpenAI full text inference.

    Reference of openai rest api: https://platform.openai.com/docs/api-reference/making-requests
    """
    def get_inference_params(self):
        params = {
            "max_tokens": self.max_new_token
        }
        params.update(self.sample_params)
        return params

    def request(self, req_id: str, data):
        result = self._client_instance.generate_chat(model_name=self.model_name, prompt=data,
                                                     parameters=self.get_inference_params(), request_id=req_id)
        content = json.loads(result)
        self.result_caching[req_id].output = content["choices"][0]["message"]["content"]
        self.result_caching[req_id].num_generated_chars = len(self.result_caching[req_id].output)
        self.result_caching[req_id].num_generated_tokens = content["usage"]["completion_tokens"]
        self.result_caching[req_id].prefill_latency = content["prefill_time"]
        self.result_caching[req_id].decode_cost = content["decode_time_arr"]

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "model":               ((str, ), ''),
            "presence_penalty":    ((float, int), ''),
            "frequency_penalty":   ((float, int), ''),
            "repetition_penalty":  ((float, int), ''),
            "temperature":         ((float, int), ''),
            "top_p":               ((float, int), ''),
            "top_k":               ((int, ), int32_range),
            "seed":                ((int, ), int64_range),
            "include_stop_str_in_output": ((bool, ), ''),
            "skip_special_tokens": ((bool, ), ''),
            "ignore_eos":          ((bool, ), ''),
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)


class SelfOpenaiStreamClient(SelfClient):
    """MindIE developed client which supports OpenAI stream inference.

    Reference of openai rest api: https://platform.openai.com/docs/api-reference/making-requests
    """
    def get_inference_params(self):
        params = {
            "max_tokens": self.max_new_token
        }
        params.update(self.sample_params)
        return params

    def request(self, req_id: str, data):
        outputs = []
        for res_ in self._client_instance.generate_chat_stream(model_name=self.model_name, prompt=data,
                                                               request_id=req_id,
                                                               parameters=self.get_inference_params()):
            outputs.append(res_[TEXT_OUTPUT_STR])
            if not self.result_caching[req_id].num_generated_tokens:
                self.result_caching[req_id].prefill_latency = res_["prefill_time"]
            else:
                self.result_caching[req_id].decode_cost.append(res_["decode_time"])
            self.result_caching[req_id].num_generated_tokens += 1
            self.result_caching[req_id].num_generated_chars += len(res_[TEXT_OUTPUT_STR])
        self.result_caching[req_id].output = "".join(outputs)

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "model":               ((str, ), ''),
            "presence_penalty":    ((float, int), ''),
            "frequency_penalty":   ((float, int), ''),
            "repetition_penalty":  ((float, int), ''),
            "temperature":         ((float, int), ''),
            "top_p":               ((float, int), ''),
            "top_k":               ((int, ), int32_range),
            "seed":                ((int, ), int64_range),
            "include_stop_str_in_output": ((bool, ), ''),
            "skip_special_tokens": ((bool, ), ''),
            "ignore_eos":          ((bool, ), ''),
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)
