#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import os
import json
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from urllib.parse import urljoin

from gevent.pool import Pool
import urllib3
import numpy

from mindiebenchmark.common.tokenizer import BenchmarkTokenizer
from mindiebenchmark.common.datasetloaders.base_loader import BaseLoader
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.common.config import Config
from mindiebenchmark.common.logging import Logger
from mindiebenchmark.common.utils import sample_one_value
from mindiebenchmark.common.params_check import check_type_and_range
from mindieclient.python.httpclient.utils import raise_error

END_OF_SEQ = "</s>"
DEFAULT_SMPL_PARAM = {
    "temperature": 0.5,
    "top_k": 10,
    "top_p": 0.9,
    "repetition_penalty": 1,
    "seed": 1
}


class VLLMClient():
    """A class for vllm inference.

    This class provides api to send request in vllm format to server and get the returned data. The
    request information (e.g. send request time) will be recorded to calculate the metrics of
    inference.
    """
    @dataclass
    class MiddleResult:
        data_id: str = ''
        input_data: str = ''
        num_input_tokens: int = 0
        num_input_chars: int = 0
        num_generated_tokens: int = 0
        num_generated_chars: int = 0
        prefill_latency: float = .0
        decode_cost: list[float] = field(default_factory=list)
        req_latency: float = .0
        decode_batch_size: list[int] = field(default_factory=list)
        prefill_batch_size: int = 0
        post_process_time: float = .0
        tokenized_time: float = .0
        detokenized_time: float = .0
        queue_wait_time: list[float] = field(default_factory=list)
        data_option: list = field(default_factory=list)
        output: str = ""
        start_time: float = .0
        end_time: float = .0
        request_id: str = ''

        def is_valid(self):
            """To ensure valid results"""
            return all([self.num_input_tokens, self.num_input_chars,
                        self.num_generated_tokens, self.num_generated_chars, self.decode_cost])

        def convert_to_standard(self) -> dict:
            try:
                chars = self.num_generated_chars / self.num_generated_tokens
            except ZeroDivisionError:
                chars = 0.0
            return {
                "id": self.data_id,
                "input_data": self.input_data,
                'prefill_latencies': self.prefill_latency,
                'decode_token_latencies': self.decode_cost[:],
                'decode_max_token_latencies': max(self.decode_cost) if self.decode_cost else .0,
                'seq_latencies': self.req_latency,
                'input_tokens_len': self.num_input_tokens,
                'generate_tokens_len': self.num_generated_tokens,
                'generate_characters_len': self.num_generated_chars,
                'prefill_batch_size': self.prefill_batch_size,
                'decode_batch_size': self.decode_batch_size[:],
                'queue_wait_time': self.queue_wait_time[:],
                'post_processing_time': self.post_process_time,
                'tokenizer_time': self.tokenized_time,
                'detokenizer_time': self.detokenized_time,
                'output': self.output,
                'characters_per_token': chars,
                'request_id': self.request_id,
            }

    def __init__(self, client_config: Config, result_container: ResultData, dataloader: BaseLoader):
        """Initialize triton client.

        Args:
            client_config (Config): Configuration for client instance.
            result_container (ResultData): It stores the generated information during inference to
                calculate the metrics.
            dataloader (BaseLoader): The dataloader of benchmark.
        """
        self.logger = Logger().logger
        self.config = client_config
        self.concurrency = self.config.command_line_args.get("Concurrency")
        self.task_kind = self.config.command_line_args.get("TaskKind")
        self.model_path = self.config.command_line_args.get("ModelPath")
        self.max_tokens = self.config.command_line_args.get("MaxOutputLen")
        self.results = result_container
        self.dataloader = dataloader
        self._geven_group = Pool(size=self.concurrency)
        self.sample_params = self.config.command_line_args.get("SamplingParams")
        self.validate_sample_parameters()
        if self.sample_params:
            self.logger.info("DoSampling enable with params:\n%s", self.sample_params)
        self._http_pool_manager = urllib3.PoolManager()
        self._timeout = 600
        self.url = client_config.get_command_line_arg("Http")
        self.management_url = client_config.get_command_line_arg("ManagementHttp")
        self.is_mindie_backend = self.endpoint_vllm_is_active()
        if self.is_mindie_backend:
            self.url += "/generate"
        else:
            self.url += "/v1/completions"
        self.done_flag = "[DONE]"

        def new_middle():
            return VLLMClient.MiddleResult()
        self.result_caching = defaultdict(new_middle)

    def endpoint_vllm_is_active(self):
        try:
            health_url = urljoin(self.management_url, "/health")
            response = self._http_pool_manager.request("GET",
                health_url, body=json.dumps({}).encode(),
                timeout=self._timeout, preload_content=False
            )
            return response.status == 200
        except urllib3.exceptions.TimeoutError:
            self.logger.info("Timeout occurred and the status code is {}.".format(response.status))
        except urllib3.exceptions.RequestError as err:
            self.logger.info("Request failed and the reason is {}.".format(err))
        return False

    def run_vllm_sync_task(self, data_queue):
        if self.task_kind != "stream":
            raise_error('Only support --TaskKind "stream" when using --TestType "vllm_client".')

        data_dict = data_queue.get()
        while data_dict is not None:
            self._geven_group.spawn(self.vllm_generate_text_stream, data_dict)
            data_dict = data_queue.get()
        self._geven_group.join()
        self.logger.info("Handling %d requests, failed %d",
                         self.results.total_req, (self.results.total_req - self.results.success_req))
        # to sync results to Results
        self.report_results()

    def inc_total_req(self):
        if self.results.total_req % 10 == 0:
            self.logger.info("Total %d requests are sent to server, %d returned, %d empty.",
                             self.results.total_req,
                             self.results.returned_req, self.results.empty_req)
        self.results.add_total_req()

    def prepare_input(self, data_dict: dict):
        """Prepare data according to input data dict, ready for connection with endpoint.

        Args:
            data_dict (dict): It should have keys `data` and `id`.

        Returns:
            rrid (str): Unique identifier for each request.
            data (ndarray or string): The input text ro token-ids that will input to server.
        """
        if all(key in data_dict for key in ("data", "id")):
            data = data_dict.get("data")
            data_id = data_dict.get("id")
        else:
            raise RuntimeError(f"Input data must have `id` and `data` key but got {data_dict.keys()}")
        options = data_dict.get("options", [])
        rrid = uuid.uuid4().hex
        self.result_caching[rrid].request_id = rrid
        self.result_caching[rrid].data_id = data_id
        self.result_caching[rrid].input_data = data
        self.result_caching[rrid].data_option = options[:]
        if isinstance(data, list):
            # convert list to ndarray
            data = numpy.array(data, dtype=numpy.uint32)
            if data.ndim == 1:
                data = numpy.expand_dims(data, axis=0)
            num_tokens = data.shape[-1]
            self.result_caching[rrid].num_input_tokens = num_tokens
            self.result_caching[rrid].num_input_chars = num_tokens
        elif isinstance(data, str):
            if self.dataloader is None:
                self.result_caching[rrid].num_input_tokens = len(data)
            else:
                encode_out = BenchmarkTokenizer.encode(data)
                self.result_caching[rrid].num_input_tokens = len(encode_out)
            self.result_caching[rrid].num_input_chars = len(data)
        elif isinstance(data, numpy.ndarray):
            num_tokens = data.shape[-1]
            self.result_caching[rrid].num_input_tokens = num_tokens
            self.result_caching[rrid].num_input_chars = num_tokens

        lora_adapter_list = self.config.config.get("lora_adapter_list")
        if lora_adapter_list:
            data_with_lora_adapter = {"prompt": data, "model": lora_adapter_list.get(str(data_id))}
            return rrid, data_with_lora_adapter
        return rrid, data

    def report_results(self):
        if not self.result_caching:
            self.logger.warning("All requests failed, return.")
            return
        total_start = min([item.start_time for _, item in self.result_caching.items()])
        total_end = max([item.end_time for _, item in self.result_caching.items()])
        self.logger.info("Converting middle results to final results...")
        self.results.total_time_elapsed = total_end - total_start
        all_results = [result.convert_to_standard() for _, result in self.result_caching.items()]
        self.results.add_req_res(all_results)

    def vllm_stream_get_output(self, response, req_id: int):
        for byte_line in response.stream():
            if byte_line == b"\n":
                continue
            cur_line = byte_line.decode()

            if not self.is_mindie_backend:
                if cur_line.startswith("data:"):
                    json_objec = cur_line.lstrip("data:").rstrip("\n")
                    if (json_objec.strip() == self.done_flag):
                        continue
                    try:
                        json_content = json.loads(json_objec)
                        response_str = json_content['choices'][0]['text']
                        response_usage = json_content['usage']
                        yield response_str, response_usage
                    except (TypeError, json.JSONDecodeError) as e:
                        raise_error(f"Parse data failed, data returned by server is: {cur_line}. Error message: {e}")
                else:
                    raise_error("The tokens generation of request id {} might be incomplete.".format(req_id))
            else:
                try:
                    json_content = json.loads(cur_line.rstrip("\0"))
                    yield json_content.get("text")[0], False
                except (TypeError, json.JSONDecodeError) as e:
                    raise_error(f"Parse data failed, data returned by server is: {cur_line}. Error message: {e}")

    def vllm_generate_text_stream(self, data_dict: dict):
        """Run stream inference for vllm.

        This method will send request and get the returned data from server.

        Args:
            data_dict (dict): The data that will send to server as json format. It includes full
                request information, e.g. prompt and sampling parameters. The dict follows the
                format provides by vLLM.
        """
        req_id, prompt = self.prepare_input(data_dict)

        pload = {
            "temperature": 0.0,
            "max_tokens": self.max_tokens,
            "stream": True,
            "ignore_eos": (self.dataloader.dataset_type == "synthetic")
        }
        if isinstance(prompt, dict):
            pload.update(prompt)
        else:
            pload.update({"prompt": prompt, "model": self.model_path})
        pload.update(self.sample_params)

        if self.dataloader.dataset_type == "synthetic":
            output_config = self.dataloader.SYNTHETIC_CONFIG["Output"]
            value = sample_one_value(output_config["Method"], output_config["Params"])
            pload.update({'max_tokens': value})

        self.inc_total_req()
        first_token_time = None
        decoded_times = []
        num_generated_chars = 0
        num_generated_tokens = 0
        outputs = []
        self.result_caching[req_id].start_time = generate_start = start = time.time()

        try:
            response = self._http_pool_manager.request("POST",
                    self.url, body=json.dumps(pload).encode(),
                    timeout=self._timeout, preload_content=False
                )
        except urllib3.exceptions.TimeoutError:
            raise_error("Timeout occurred and the status code is {}.".format(response.status))
        except urllib3.exceptions.RequestError as err:
            raise_error("Request failed and the reason is {}.".format(err))
        except Exception as e:
            raise_error("{}".format(e))

        num_tokens = 0
        for res, usage in self.vllm_stream_get_output(response, req_id):
            if usage:
                num_tokens = usage.get('completion_tokens')
            if res == END_OF_SEQ:
                break
            outputs.append(res)
            delta = time.time() - start
            if num_generated_tokens == 0:
                first_token_time = delta
            else:
                decoded_times.append(delta)
            num_generated_tokens += 1
            num_generated_chars += len(res)
            start = time.time()

        self.result_caching[req_id].end_time = generate_end = time.time()
        self.results.add_returned_req()
        output_str = "".join(outputs)
        if first_token_time is None:
            self.logger.error("Request with data id %s encounter empty response !",
                              data_dict.get("id", "<Unknown-id>"))
            self.result_caching.pop(req_id)
            self.results.add_empty_req()
            return
        self.result_caching[req_id].num_input_chars = len(prompt)
        self.result_caching[req_id].prefill_latency = first_token_time * 1000
        self.result_caching[req_id].req_latency = (generate_end - generate_start) * 1000
        self.result_caching[req_id].num_generated_tokens = num_tokens if usage else num_generated_tokens
        self.result_caching[req_id].num_generated_chars = num_generated_chars
        self.result_caching[req_id].decode_cost = [cost * 1000 for cost in decoded_times]
        self.result_caching[req_id].output = output_str
        self.results.add_success_req()

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "presence_penalty":   ((float, int), ''),
            "frequency_penalty":  ((float, int), ''),
            "repetition_penalty": ((float, int), ''),
            "top_k":              ((int, ), int32_range),
            "top_p":              ((float, int), ''),
            "temperature":        ((float, int), ''),
            "seed":               ((int, ), int64_range),
            "include_stop_str_in_output": ((bool, ), ''),
            "skip_special_tokens": ((bool, ), ''),
            "ignore_eos":          ((bool, ), '')
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)
