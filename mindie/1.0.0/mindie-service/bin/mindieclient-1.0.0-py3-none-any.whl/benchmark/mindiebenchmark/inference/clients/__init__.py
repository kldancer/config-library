#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from mindiebenchmark.common.config import Config
from mindiebenchmark.common.datasetloaders.base_loader import BaseLoader
from mindiebenchmark.common.results import ResultData

from .self_openai_client import SelfOpenaiTextClient, SelfOpenaiStreamClient
from .self_token_client import SelfTokenClient
from .self_triton_client import SelfTritonTextClient, SelfTritonStreamClient


client_map = {
    "openai": {
        "text": SelfOpenaiTextClient,
        "stream": SelfOpenaiStreamClient
    },
    "client": {
        "text": SelfTritonTextClient,
        "stream": SelfTritonStreamClient,
        "stream_token": SelfTokenClient,
    }
}


class ClientFactory:
    @staticmethod
    def make_client_instance(client_config: Config, result_container: ResultData, gevent_pool_size: int = 16,
                             dataloader: BaseLoader | None = None):
        test_type = client_config.get_command_line_arg("TestType")
        task_kind = client_config.get_command_line_arg("TaskKind").lower()
        if task_kind not in client_map.get(test_type):
            raise ValueError(f"{test_type} doesn't support {task_kind}")
        return client_map.get(test_type).get(task_kind)(client_config, result_container, gevent_pool_size, dataloader)
