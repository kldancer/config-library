#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import Dict
from pydantic import ValidationError

from mindiebenchmark.inference.schemas import TextResponse
from mindiebenchmark.common.params_check import check_keys, check_type_and_range
from .self_client import SelfClient

END_OF_SEQ = "</s>"
TEXT_OUTPUT_STR = "text_output"


class SelfTritonTextClient(SelfClient):
    """MindIE developed client that support full text inference.

    This client can interact with mindie server with triton format api.
    """
    def get_inference_parameters(self) -> Dict:
        params = {
            "details": True,
            "max_new_tokens": self.max_new_token,
            "do_sample": self.do_sampling,
            "perf_stat": True
        }
        params.update(self.sample_params)
        return params

    def request(self, req_id: str, data):

        response = self._client_instance.generate(model_name=self.model_name, prompt=data,
                                                  parameters=self.get_inference_parameters(), request_id=req_id,
                                                  model_version=self.model_version)
        try:
            content = TextResponse.model_validate(response.get_response())
        except ValidationError as e:
            self.logger.error("[MIE01E000108] Request %s failed with response format error:\n %s",
                              req_id, e.errors())
            return
        self.result_caching[req_id].num_generated_tokens = content.details.generated_tokens
        self.result_caching[req_id].num_generated_chars = len(content.text_output)
        self.result_caching[req_id].output = content.text_output
        self.result_caching[req_id].prefill_latency = content.details.perf_stat[0][1]
        self.result_caching[req_id].decode_cost = [content.details.perf_stat[i + 1][1]
                                                   for i in range(len(content.details.perf_stat) - 1)]

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "repetition_penalty": ((float, int), ''),
            "seed":               ((int, ), int64_range),
            "temperature":        ((float, int), ''),
            "top_k":              ((int, ), int32_range),
            "top_p":              ((float, int), ''),
            "batch_size":         ((int, ), int32_range),
            "typical_p":          ((float, ), ''),
            "watermark":          ((bool, ), ''),
            "firstTokenCost":     ((int, ), int64_range),
            "decodeTime":         ((list, ), '')
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)


class SelfTritonStreamClient(SelfClient):
    """MindIE developed client that support stream inference.

    This client can interact with mindie server with triton format api.
    """
    def get_inference_parameters(self) -> Dict:
        params = {
            "details": True,
            "max_new_tokens": self.max_new_token,
            "do_sample": self.do_sampling
        }
        params.update(self.sample_params)
        return params

    def request(self, req_id: str, data):
        outputs = []
        for res_ in self._client_instance.generate_stream_with_details(model_name=self.model_name, prompt=data,
                                                                       request_id=req_id,
                                                                       parameters=self.get_inference_parameters()):
            if res_[TEXT_OUTPUT_STR] == END_OF_SEQ:
                break
            outputs.append(res_[TEXT_OUTPUT_STR])
            if not self.result_caching[req_id].num_generated_tokens:
                self.result_caching[req_id].prefill_latency = res_["prefill_time"]
                self.result_caching[req_id].prefill_batch_size = res_["batch_size"]
            else:
                self.result_caching[req_id].decode_cost.append(res_["decode_time"])
                self.result_caching[req_id].decode_batch_size.append(res_["batch_size"])
            self.result_caching[req_id].num_generated_tokens += 1
            self.result_caching[req_id].num_generated_chars += len(res_[TEXT_OUTPUT_STR])
            self.result_caching[req_id].queue_wait_time.append(res_["queue_wait_time"])
        self.result_caching[req_id].output = "".join(outputs)

    def validate_sample_parameters(self):
        int32_range = '(-2147483647, 2147483647]'
        int64_range = '(-18446744073709551615, 18446744073709551615]'
        support_sample_params = {
            "repetition_penalty": ((float, int), ''),
            "seed":               ((int, ), int64_range),
            "temperature":        ((float, int), ''),
            "top_k":              ((int, ), int32_range),
            "top_p":              ((float, int), ''),
            "batch_size":         ((int, ), int32_range),
            "typical_p":          ((float, ), ''),
            "watermark":          ((bool, ), ''),
            "firstTokenCost":     ((int, ), int64_range),
            "decodeTime":         ((list, ), '')
        }

        for key, value in self.sample_params.items():
            if key not in support_sample_params:
                self.logger.warning(f"These parameters '{key}' is not support in --SamplingParams. "
                                     "Please remove it from --SamplingParams.")
            else:
                types, value_range = support_sample_params.get(key)
                check_type_and_range(key, value, types, value_range)
