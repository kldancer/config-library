#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import copy
import glob
import json
import os
import queue
import threading
from abc import abstractmethod, ABC
from pathlib import Path

from jsonlines import jsonlines

from mindiebenchmark.common.logging import Logger
from mindiebenchmark.common.results import ResultData
from mindiebenchmark.common.file_utils import PathCheck

DATASET_TYPE_SEP = "_"
DATA_FILE_SIZE_LIMITATION = 100 * 1024 * 1024  # 限制读取的dataset文件大小为100M
DATA_FILE_NUM_SIZE_LIMITATION = 30000           # 限制读取dataset文件数量为1000


def check_file_num(file_list: list):
    if len(file_list) >= DATA_FILE_NUM_SIZE_LIMITATION:
        raise ValueError(f"The nums of dataset file must less than {DATA_FILE_NUM_SIZE_LIMITATION}.")


def check_file(dataset_path: str):
    ret, infos = PathCheck.check_path_full(path=dataset_path, max_file_size=DATA_FILE_SIZE_LIMITATION)
    if not ret:
        raise ValueError(infos)


def extract_dataset_type_info(dataset_type: str):
    arr = dataset_type.split(DATASET_TYPE_SEP)
    return arr[0], arr[1:]


class BaseLoader(threading.Thread):
    JSONL_POSIX = "jsonl"
    JSON_POSIX = "json"
    CSV_POSIX = "csv"
    PARQUET_POSIX = "parquet"
    JPG_POSIX = "jpg"
    WAV_POSIX = "wav"
    logger = Logger().logger

    def __init__(self, command_line_args: dict, data_queue: queue.Queue, result: ResultData):
        super().__init__()
        self.data_queue = copy.copy(data_queue)
        self.dataset_path = command_line_args.get("DatasetPath")
        self.dataset_type = command_line_args.get("DatasetType")
        self.model_path = command_line_args.get("ModelPath")
        self.model_name = command_line_args.get("ModelName")
        self.test_accuracy = command_line_args.get("TestAccuracy")

        self.result = result
        self.gt_answer = result.gt_answer
        self.tokenizer_time = result.tokenizer_time
        self.detokenizer_time = result.detokenizer_time
        self.stop = False
        self.choices = ["A", "B", "C", "D"]
        self.id_count = 0

    @classmethod
    def validate_dataset_args(cls, dataset_type: str, command_line_args: dict):
        if DATASET_TYPE_SEP in dataset_type:
            raise ValueError(f"argument --DatasetType: {dataset_type} should not contain {DATASET_TYPE_SEP}")

    @abstractmethod
    def read_file(self, file_path: str):
        pass

    @abstractmethod
    def get_file_posix(self) -> str:
        pass

    def get_sub_dir_name(self) -> str:
        return ""

    def get_file_list(self) -> list:
        if str("." + self.get_file_posix()) in self.dataset_path:
            return [self.dataset_path]
        dir_path = self.dataset_path
        sub_dir_name = self.get_sub_dir_name()
        if sub_dir_name:
            dir_path = os.path.join(dir_path, sub_dir_name)
        return glob.glob((Path(dir_path) / ("*." + self.get_file_posix())).as_posix())

    def stop_load(self):
        self.logger.info("Stopping loading dataset...")
        self.stop = True
        while not self.data_queue.empty():
            self.data_queue.get()
        self.data_queue.put(None)
        self.logger.info("Finished loading dataset")

    def run(self):
        try:
            self.logger.info("Reading dataset...")
            file_list = self.get_file_list()
            check_file_num(file_list)
            for file_path in file_list:
                check_file(file_path)
                if self.stop:
                    return
                self.read_file(file_path)
            self.data_queue.put(None)
            self.logger.info("Finished loading dataset...")
        except Exception as err:
            self.logger.error(f"Loading dataset failed, {err}")
            self.stop_load()
            raise {"DatasetLoader process failed"} from err

    def splice_ques_options(self, data_dict, with_ans=False):
        ques_key = "question"
        ques = data_dict[ques_key]
        options = [data_dict["A"], data_dict["B"], data_dict["C"], data_dict["D"]]
        comp_choice = ""
        for choice, op in zip(self.choices, options):
            comp_choice += f"{choice}. {op}\n"

        complete_ques = ques + "\n" + comp_choice

        if with_ans:
            complete_ques += "Answer: " + data_dict["answer"] + "\n"
        return complete_ques

    def put_data_dict(self, data):
        """Put prepared data to data queue."""
        data_dict = {
            "id": str(self.id_count),
            "data": data,
            "options": []
        }
        if isinstance(data, dict):
            for key, val in data_dict.items():
                data_dict[key] = data.get(key, val)
        self.data_queue.put(data_dict)
        self.id_count += 1


class JsonlLoader(BaseLoader, ABC):
    @abstractmethod
    def read_line(self, line):
        pass

    def get_file_posix(self) -> str:
        return self.JSONL_POSIX

    def read_file(self, file_path: str):
        with jsonlines.open(file_path) as reader:
            for line in reader:
                if self.stop:
                    return
                self.put_data_dict(self.read_line(line))


class MultiJsonLoader(BaseLoader, ABC):
    @abstractmethod
    def read_line(self, line):
        pass

    def get_file_posix(self) -> str:
        return self.JSON_POSIX

    def read_file(self, file_path: str):
        with open(file_path, mode="r", encoding="utf-8") as file:
            data = json.load(file)
            for line in data.items():
                if self.stop:
                    return
                self.put_data_dict(self.read_line(line))