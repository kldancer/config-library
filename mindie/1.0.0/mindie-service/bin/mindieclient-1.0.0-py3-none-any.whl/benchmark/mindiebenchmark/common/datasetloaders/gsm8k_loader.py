#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from .base_loader import JsonlLoader


class Gsm8kLoader(JsonlLoader):
    def read_line(self, line):
        if self.test_accuracy:
            self.gt_answer[str(self.id_count)] = line["answer"].split(" ")[-1]

        return line["question"]
