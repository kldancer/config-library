#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from typing import Union

from .base_loader import BaseLoader


class VocalsoundLoader(BaseLoader):
    @staticmethod
    def get_qwen2_audio_queries(file_path, prompt):
        data = [
                {"type": "audio_url", "audio_url": file_path},
                {"type": "text", "text": prompt}
        ]
        return data
    
    def read_file(self, file_path) -> Union[str, dict]:
        self.gt_answer[str(self.id_count)] = file_path.split('.')[0].split('_')[-1]
        
        prompt_head = "In this audio, what kind of sound can you hear? "
        prompt_body1 = "A: Laughter, B: Sigh, C: Cough, D: Throat clearing, E: Sneeze, F: Sniff, "
        prompt_body2 = "Please select the one closest to the correct answer. ASSISTANT:"
        prompt = prompt_head + prompt_body1 + prompt_body2
        
        func_map = {
            "qwen2_audio": "get_qwen2_audio_queries",
        }
        try:
            func_name = func_map[self.model_name]
        except KeyError as e:
            raise KeyError(f"Unsupported! Please choose from [{func_map.keys()}].") from e
        func = getattr(self, func_name)
        data = func(file_path, prompt)
    
        self.put_data_dict(data)
        
    def get_file_posix(self) -> str:
        return self.WAV_POSIX