#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from .base_loader import JsonlLoader


class TextVQALoader(JsonlLoader):
    @staticmethod
    def get_qwen_vl_queries(line):
        queries = {
            "id": line["question_id"],
            "data":
                [
                    {"type": "text", "text": line["question"] + " Answer:"},
                    {"type": "image_url", "image_url": line["image"]}
                ]
        }
        return queries
    
    @staticmethod
    def get_qwen2_vl_queries(line):
        queries = {
            "id": line["question_id"],
            "data":
                [
                    {"type": "text", "text":"I will give you a picture and the corresponding question,"
                                        + " please answer the answer directly, do not repeat the question."},
                    {"type": "image_url", "image_url": line["image"]},
                    {"type": "text", "text": line["question"] + " Answer:"}
                ]
        }
        return queries
    
    @staticmethod
    def get_internvl_queries(line):
        queries = {
            "id": line["question_id"],
            "data":
                [
                    {"type": "text", "text": line["question"] + " Answer the question using a single word or phrase."},
                    {"type": "image_url", "image_url": line["image"]}
                ]
        }
        return queries
    
    def read_line(self, line):
        func_map = {
            "qwen_vl": "get_qwen_vl_queries",
            "qwen2_vl": "get_qwen2_vl_queries",
            "internvl": "get_internvl_queries"
        }
        try:
            func_name = func_map[self.model_name]
        except KeyError as e:
            raise KeyError(f"Unsupported! Please choose from [{func_map.keys()}].") from e
        func = getattr(self, func_name)
        return func(line)