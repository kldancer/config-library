#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import re
from typing import Dict, Any, Tuple, Set, Iterable
from dataclasses import dataclass


@dataclass
class NumberRange:
    lower: tuple[int, float] = None
    upper: tuple[int, float] = None
    lower_inclusive: bool = True
    upper_inclusive: bool = True


def check_type_and_range(name, value, types, value_range):
    """
    Validate a parameter's type and range.

    Args:
        name: The name of the variable (str).
        value: The value of the variable (int, float, or bool).
        types: A tuple of allowed types (e.g., (int, float)).
        value_range: A string defining the allowed range (e.g., "(0.0, +inf)").
                        Parentheses () mean exclusive, brackets [] mean inclusive.
    Raises:
        ValueError: If the value's type or range is invalid.
    """
    # Validate type
    if not isinstance(value, types):
        raise ValueError(f"{name} check failed: expect one of {types}, but got {type(value)}")
    if not value_range:
        return

    # Parse value_range
    match = re.match(
        r"^([\[\(])\s*(-?inf|\+?inf|[-+]?\d*\.?\d+)\s*,\s*(-?inf|\+?inf|[-+]?\d*\.?\d+)\s*([\]\)])$",
        value_range)
    if not match:
        raise ValueError(f"{name} check failed: invalid range format '{value_range}'")
    left_bracket, lower_bound, upper_bound, right_bracket = match.groups()

    # Convert bounds to float
    lower_bound = float("-inf") if lower_bound == "-inf" else float(lower_bound)
    upper_bound = float("inf") if upper_bound == "+inf" else float(upper_bound)

    # Check value within range
    in_range = (
        (lower_bound < value if left_bracket == '(' else lower_bound <= value) and
        (value < upper_bound if right_bracket == ')' else value <= upper_bound)
    )

    if not in_range:
        raise ValueError(
            f"{name} check failed: value {value} not in range {value_range}"
        )


def check_type(name: str, value: Any, types: Tuple):
    if not isinstance(value, types):
        raise ValueError(f"Parameter {name} should have type {types}, but got {type(value)}.")


def check_keys(got_keys: Iterable[str], support_keys: Iterable[str]) -> None:
    """
    Check if got_keys contains unsupported keys based on support_keys.
    Raise ValueError if unsupported keys are found, indicating which keys are unsupported
    and listing the supported keys.

    Args:
        got_keys: An iterable of keys provided.
        support_keys: An iterable of supported keys.

    Raises:
        ValueError: If unsupported keys are found.
    """
    got_keys_set = set(got_keys)
    support_keys_set = set(support_keys)
    # Calculate unsupported keys
    unsupported_keys = got_keys_set - support_keys_set
    return unsupported_keys


def check_range(name: str, value: Any, param: NumberRange):
    lower, upper = param.lower, param.upper
    lower_inclusive, upper_inclusive = param.lower_inclusive, param.upper_inclusive
    # 构造区间的字符串表示
    lower_bound = '[' if lower_inclusive else '('
    upper_bound = ']' if upper_inclusive else ')'
    lower_str = str(lower) if lower is not None else '-inf'
    upper_str = str(upper) if upper is not None else '+inf'

    # 构造完整区间表示字符串
    interval_str = f"{lower_bound}{lower_str}, {upper_str}{upper_bound}"

    # 检查下限
    if lower is not None:
        lt = (lower_inclusive and value < lower)
        le = (not lower_inclusive and value <= lower)
        if le or lt:
            raise ValueError(f"Parameter {name} is {value}, not within the required range {interval_str}")
    # 检查上限
    if upper is not None:
        gt = (upper_inclusive and value > upper)
        ge = (not upper_inclusive and value >= upper)
        if gt or ge:
            raise ValueError(f"Parameter {name} is {value}, not within the required range {interval_str}")


SAMPLING_PARAMS_CHECK = {
    "temperature": {
        "types": (int, float),
        "range": NumberRange(lower=0, upper=2.0, lower_inclusive=False, upper_inclusive=True)
    },
    "top_k": {
        "types": (int,),
        "range": NumberRange(lower=0, upper=2**32 - 1, lower_inclusive=True, upper_inclusive=True)
    },
    "top_p": {
        "types": (int, float),
        "range": NumberRange(lower=0.0, upper=1.0, lower_inclusive=False, upper_inclusive=True)
    },
    "typical_p": {
        "types": (int, float),
        "range": NumberRange(lower=0.0, upper=1.0, lower_inclusive=False, upper_inclusive=True),
    },
    "seed": {
        "types": (int,),
        "range": NumberRange(lower=0, upper=2**64 - 1, lower_inclusive=True, upper_inclusive=True),
    },
    "repetition_penalty": {
        "types": (int, float),
        "range": NumberRange(lower=0, lower_inclusive=False, upper_inclusive=False)
    },
    "presence_penalty": {
        "types": (int, float),
        "range": NumberRange(lower=-2.0, upper=2.0, lower_inclusive=True, upper_inclusive=True)
    },
    "frequency_penalty": {
        "types": (int, float),
        "range": NumberRange(lower=0.0, upper=2.0, lower_inclusive=False, upper_inclusive=True)
    },
    "ignore_eos": {
        "types": (bool,)
    },
    "watermark": {
        "types": (bool,)
    },
    "truncate": {
        "types": (int,),
        "range": NumberRange(lower=1, upper=2**32 - 1, lower_inclusive=True, upper_inclusive=True)
    }
}


def check_sampling_params(params: Dict):
    """Check the sampling parameters.

    Remember not all keys validated will surely appeared in the `params`.
    """
    if not params:
        return

    for key, value in params.items():
        if key not in SAMPLING_PARAMS_CHECK:
            raise ValueError(f"Parameter {key} is not supported.")
        if "types" in SAMPLING_PARAMS_CHECK.get(key):
            check_type(key, value, SAMPLING_PARAMS_CHECK.get(key).get("types"))
        if "range" in SAMPLING_PARAMS_CHECK.get(key):
            check_range(key, value, SAMPLING_PARAMS_CHECK.get(key).get("range"))
