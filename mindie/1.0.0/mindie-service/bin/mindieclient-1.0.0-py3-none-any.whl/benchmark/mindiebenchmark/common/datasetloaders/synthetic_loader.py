#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import json
import numpy as np

from mindiebenchmark.common.utils import sample_one_value
from mindiebenchmark.common.params_check import check_range
from mindiebenchmark.common.params_check import check_type
from mindiebenchmark.common.params_check import NumberRange
from mindiebenchmark.common.file_utils import PathCheck
from .base_loader import BaseLoader


def _check_keys_equal(got_keys, true_keys, comment):
    for key in got_keys:
        if key not in true_keys:
            raise ValueError(f"{key} is not a valid key for {comment}.")
    if got_keys != true_keys:
        raise ValueError(f"Expect keys {true_keys} for {comment}, but got keys {set(got_keys)}.")


class SyntheticLoader(BaseLoader):
    SYNTHETIC_CONFIG = {}

    @classmethod
    def validate_dataset_args(cls, dataset_type: str, command_line_args: dict):
        config_path = command_line_args.get("SyntheticConfigPath")
        ret, infos = PathCheck.check_path_full(config_path)
        if not ret:
            raise ValueError(f"{infos} Got path: {config_path}")
        try:
            with open(config_path, mode="r", encoding="utf-8") as file:
                cls.SYNTHETIC_CONFIG = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            raise ValueError(f"Failed to load JSON config from `SyntheticConfigPath`") from e

        input_str = "Input"
        output_str = "Output"
        request_count_str = "RequestCount"
        _check_keys_equal(cls.SYNTHETIC_CONFIG.keys(), {input_str, output_str, request_count_str}, "SyntheticConfig")

        request_count = cls.SYNTHETIC_CONFIG.get(request_count_str)
        check_type(request_count_str, request_count, (int,))
        check_range(request_count_str, request_count, NumberRange(1, 2**20))

        for key in (input_str, output_str):
            conf = cls.SYNTHETIC_CONFIG.get(key, "")
            _check_keys_equal(conf.keys(), {"Method", "Params"}, 'SyntheticConfig["{key}"]')
            method = conf.get("Method")
            params = conf.get("Params")
            uniform_str = "uniform"
            gaussian_str = "gaussian"
            zipf_str = "zipf"
            min_value_str = "MinValue"
            max_value_str = "MaxValue"
            mean_str = "Mean"
            var_str = "Var"
            alpha_str = "Alpha"

            if method == uniform_str:
                _check_keys_equal(params.keys(), {min_value_str, max_value_str}, uniform_str)
            elif method == gaussian_str:
                _check_keys_equal(params.keys(), {mean_str, var_str, min_value_str, max_value_str}, gaussian_str)
            elif method == zipf_str:
                _check_keys_equal(params.keys(), {alpha_str, min_value_str, max_value_str}, zipf_str)
            else:
                raise ValueError(f'Method should be one of {{{uniform_str, gaussian_str, zipf_str}}}, '
                                 f'but got {method}.')
            min_float32_value = -3.0e38
            max_float32_value = 3.0e38
            for param_name, param_value in params.items():
                desc_name = key + " " + param_name
                if param_name in (min_value_str, max_value_str):
                    check_type(desc_name, param_value, types=(int,))
                    check_range(desc_name, param_value, NumberRange(1, 2**20))    # 2**20 = 1M
                elif param_name == mean_str:
                    check_type(desc_name, param_value, types=(int, float))
                    check_range(desc_name, param_value, NumberRange(min_float32_value, max_float32_value))
                elif param_name == var_str:
                    check_type(desc_name, param_value, types=(int, float))
                    check_range(desc_name, param_value, NumberRange(0, max_float32_value))
                elif param_name == alpha_str:
                    check_type(desc_name, param_value, types=(int, float))
                    check_range(desc_name, param_value, NumberRange(1.0, 10.0, lower_inclusive=False))
            min_value = params.get(min_value_str)
            max_value = params.get(max_value_str)
            if min_value > max_value:
                raise ValueError(f'MinValue should less than MaxValue, '
                                 f'but got MinValue is {min_value}, and MaxValue is {max_value}.')

    def read_file(self, file_path: str):
        # Synthetic data has no file
        pass

    def get_file_posix(self) -> str:
        # Synthetic data has no file
        pass

    def generate_line(self):
        default_str = "A"
        input_config = self.SYNTHETIC_CONFIG.get("Input", "")
        if not input_config:
            raise ValueError("SyntheticConfig has no key: Input.")
        method = input_config.get("Method", "")
        params = input_config.get("Params", "")
        if (not method) or (not params):
            raise ValueError("The method or params of SyntheticConfig['Input'] is invalid.")
        input_num_tokens = sample_one_value(method, params)
        data = " ".join([default_str] * input_num_tokens)
        return {
            "data": data,
            "options": [],
        }

    def run(self):
        try:
            self.logger.info("Generating dataset...")
            request_count = self.SYNTHETIC_CONFIG.get("RequestCount", 0)
            for _ in range(request_count):
                if self.stop:
                    return
                self.put_data_dict(self.generate_line())
            self.data_queue.put(None)
            self.logger.info("Finished generating dataset...")
        except Exception as err:
            self.logger.error(f"Generating dataset failed, {err}")
            self.stop_load()
            raise {"DatasetLoader process failed"} from err
