#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from .base_loader import JsonlLoader


class HumanevalLoader(JsonlLoader):
    def read_line(self, line):
        return {
            "id": line["task_id"],
            "data": line["prompt"].strip(),
        }
