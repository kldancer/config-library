#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from .base_loader import MultiJsonLoader


class VideoBenchLoader(MultiJsonLoader):
    @staticmethod
    def get_question(item):
        length = len(item["choices"])
        text_map = {
            2: 'two', 
            3: 'three', 
            4: 'four', 
            5: 'five', 
            6: 'six', 
        }

        if length not in text_map.keys():
            raise KeyError(f"The length of item[\"choices\"] must in {text_map.keys()}")
        
        question = item['question']
        if length == 6:
            question += "Choices: "
        else:
            question += " "
        choices_list = ['A', 'B', 'C', 'D', 'E', 'F']
        for i in range(length):
            choice = choices_list[i]
            question += (choice + '.' + item["choices"][choice] + ' ')
        op_list = ', '.join(choices_list[:length])
        question += (
        f'\n Among the {text_map.get(length)} options {op_list} above,'
        f' the one closest to the correct answer is:'
        )

        if length in [2, 3, 5]:
            question += " "

        question += (
            " Please respond with only the corresponding options and do not provide any explanations" 
            + " or additional information. ASSISTANT:"
        )
        return question
    
    @staticmethod
    def get_qwen2_vl_queries(vid_path, question):
        queries = [
            {"type": "video_url", "video_url": vid_path},
            {"type": "text", "text": question}
        ]
        return queries

    def read_line(self, line):
        qid, item = line
        vid_path = item['vid_path']
        sub_dataset_name = vid_path.split('/')[-2]
        self.gt_answer[self.id_count] = self.result.vb_gt_answer[sub_dataset_name][qid]["answer"]
        question = self.get_question(item)
        func_map = {
            "qwen2_vl": "get_qwen2_vl_queries",
        }
        try:
            func_name = func_map[self.model_name]
        except KeyError as e:
            raise KeyError(f"Unsupported! Please choose from [{func_map.keys()}].") from e
        func = getattr(self, func_name)
        return func(vid_path, question)