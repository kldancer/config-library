#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import time
import numpy as np


def sample_one_value(method: str, params: dict) -> int:
    # Sample one value, the args have been checked before
    min_value = params["MinValue"]
    max_value = params["MaxValue"]
    if method == "uniform":
        value = np.random.uniform(min_value, max_value)
    elif method == "gaussian":
        mean = params["Mean"]
        stddev = np.sqrt(params["Var"])
        value = np.random.normal(mean, stddev)
        value = np.clip(value, min_value, max_value)
    elif method == "zipf":
        alpha = params["Alpha"]
        value = np.random.zipf(alpha)
        value = np.clip(value, min_value, max_value)
    else:
        raise ValueError(f"Unknown method: {method}, method should be one of {{uniform, gaussian, zipf}}.")
    return int(value)


def get_time_stamp_ms() -> str:
    ct = time.time()
    local_time = time.localtime(ct)
    date_s = time.strftime("%Y%m%d%H%M%S", local_time)
    date_ms = (ct - int(ct)) * 1000
    time_stmap = "%s%03d" % (date_s, date_ms)
    return time_stmap