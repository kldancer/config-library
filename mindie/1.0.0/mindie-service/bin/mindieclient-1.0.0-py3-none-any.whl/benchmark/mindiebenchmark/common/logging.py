#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.


import os
import time
import stat
import logging
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler


RUNTIME_LOG = 'benchmark_run.log'
DEFAULT_LOG_LEVEL = 'INFO'


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class NoNewlineFormatter(logging.Formatter):
    def format(self, record):
        special_chars = [
            '\n', '\r', '\f', '\t', '\v', '\b',
            '\u000A', '\u000D', '\u000C',
            '\u000B', '\u0008', '\u007F',
            '\u0009', '    ',
        ]
        for c in special_chars:
            record.msg = str(record.msg).replace(c, ' ')
        if record.levelname == "WARNING":
            record.levelname = "WARN"
        return super(NoNewlineFormatter, self).format(record)

    def formatTime(self, record, datefmt=None):
        timezone_offset = time.timezone
        offset_hours = -timezone_offset // 3600
        dt = datetime.fromtimestamp(record.created, timezone(timedelta(hours=offset_hours)))
        timestamp = dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        offset = dt.strftime("%z")
        offset = f"{offset[:3]}:{offset[3:]}"
        return f"{timestamp}{offset} DST" if time.daylight else f"{timestamp}{offset}"


def change_to_readonly(file_name):
    current_permissions = os.stat(file_name).st_mode
    new_permissions = current_permissions & ~(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
    os.chmod(file_name, new_permissions)


def create_log_file(log_file):
    mode = 0o640
    if not os.path.exists(log_file):
        with os.fdopen(os.open(log_file, os.O_CREAT, mode), "w"):
            pass
    else:
        clean_path = os.path.normpath(log_file)
        if os.path.islink(clean_path):
            err_msg = f"Check log file path failed because it's a symbolic."
            raise ValueError(err_msg)
        if len(clean_path) > 1024:
            err_msg = f"Path of log file is too long, it should not exceed 1024 character."
            raise ValueError(err_msg)
    os.chmod(log_file, mode)


class CustomRotatingFileHandler(RotatingFileHandler):
    def rotate(self, source, dest):
        super().rotate(source, dest)
        change_to_readonly(dest)
        create_log_file(source)


# 定义日志封装类
class Logger(metaclass=Singleton):

    def __init__(self,
                 log_path='./instance',
                 max_bytes=1024 * 1024,
                 backup_count=1,
                 log_level=DEFAULT_LOG_LEVEL,
                 open_stream_handler=True):
        self._logger = logging.getLogger('benchmark')
        self._logger.propagate = False
        if self._logger.handlers:
            return
        self.log_level = log_level
        levels = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        # 根据配置的日志级别设置日志记录器的级别
        self._logger.setLevel(levels.get(self.log_level.upper(), logging.INFO))

        # 设置日志格式
        file_logging_format = NoNewlineFormatter(
            '[%(asctime)s] [%(process)d] [%(thread)d] [%(name)s] [%(levelname)s] '
            '[%(filename)s:%(lineno)s] %(message)s'
        )

        if self.log_level == "INFO":
            file_logging_format = NoNewlineFormatter(
                '[%(asctime)s] [%(process)d] [%(thread)d] [%(name)s] [%(levelname)s] '
                '[%(filename)s:%(lineno)s] %(message)s'
            )
        # 创建文件处理器并将日志写入到指定的文件中
        self.make_dirs_if_not_exist(input_dir=log_path)
        self.log_file = os.path.join(log_path, RUNTIME_LOG)
        create_log_file(self.log_file)
        os.chmod(self.log_file, 0o640)
        file_handler = CustomRotatingFileHandler(os.path.join(log_path, RUNTIME_LOG), mode='a', maxBytes=max_bytes,
                                           backupCount=backup_count)
        file_handler.setLevel(self.log_level)
        file_handler.setFormatter(file_logging_format)

        # 添加文件处理器到日志记录器
        self._logger.addHandler(file_handler)

        # 添加控制台输出
        if open_stream_handler:
            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(file_logging_format)
            self._logger.addHandler(stream_handler)


    @property
    def logger(self):
        return self._logger

    @staticmethod
    def make_dirs_if_not_exist(input_dir):
        if not os.path.exists(input_dir):
            os.makedirs(input_dir)
        os.chmod(input_dir, 0o750)

    def set_log_level(self, log_level):
        self.log_level = log_level
        self._logger.setLevel(log_level)

    def set_log_path(self, log_path):
        self.make_dirs_if_not_exist(log_path)
        file_handler = CustomRotatingFileHandler(os.path.join(log_path, RUNTIME_LOG),
                                           mode='a',
                                           maxBytes=1024 * 1024,
                                           backupCount=1)
        # 添加文件处理器到日志记录器
        self._logger.addHandler(file_handler)

    def set_log_file_permission(self, perm=0o440):
        # 结束后修改日志权限
        os.chmod(self.log_file, perm)
