#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

class BenchmarkException(Exception):
    pass


class BenchmarkServerException(BenchmarkException):
    pass


class StorageException(BenchmarkException):
    pass


class StorageConnectionException(StorageException):
    pass


class MetadataException(StorageException):
    pass


class ConfigException(BenchmarkException):
    pass


class ParamException(BenchmarkException):
    pass