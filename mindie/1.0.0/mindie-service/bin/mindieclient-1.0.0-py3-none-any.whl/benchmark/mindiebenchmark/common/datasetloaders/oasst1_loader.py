#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import os.path
import pyarrow.parquet as pq

from .base_loader import BaseLoader


class Oasst1Loader(BaseLoader):
    def read_file(self, file_path: str):
        data_dict = pq.read_table(file_path).to_pandas()
        data_dict = data_dict[data_dict["lang"] == "zh"]
        ques_list = data_dict["text"].to_list()
        file_name = os.path.basename(file_path).split("-")[0]
        for i, ques in enumerate(ques_list):
            if self.stop:
                return
            key = file_name + str(i)
            self.put_data_dict({"id": key, "data": ques})

    def get_file_posix(self) -> str:
        return self.PARQUET_POSIX
