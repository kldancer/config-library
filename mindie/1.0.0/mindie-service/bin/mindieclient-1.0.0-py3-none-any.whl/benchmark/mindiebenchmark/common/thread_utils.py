# coding=utf-8/# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.

import os
import signal

from mindiebenchmark.common.logging import Logger


def signal_interrupt_handler(signum, frame):
    Logger().logger.info(f"Received SIGINT or SIGTERM signal with signum [{signum}]")
    while True:
        pid, status = os.waitpid(0, os.WNOHANG)
        if pid > 0:
            Logger().logger.info(f"Thread with pid {pid} is over, status {status}")
        else:
            break
    os.killpg(os.getpgrp(), signal.SIGKILL)


def signal_chld_handler(signum, frame):
    Logger().logger.info(f"Received SIGCHLD signal with signum [{signum}]")
    exit_flag = False
    while True:
        try:
            pid, status = os.waitpid(0, os.WNOHANG)
            if pid == 0:
                break
            Logger().logger.info(f"Thread with pid {pid} is over, status {status}")
            if not os.WIFEXITED(status):
                exit_flag = True
        except ChildProcessError:
            break
    if exit_flag:
        os.killpg(os.getpgrp(), signal.SIGKILL)


def register_signal():
    try:
        signal.signal(signal.SIGINT, signal_interrupt_handler)
        signal.signal(signal.SIGTERM, signal_interrupt_handler)
        signal.signal(signal.SIGCHLD, signal_chld_handler)
    except ValueError:
        Logger().logger.info("Error registering signal handlers.")
    except Exception as e:
        Logger().logger.info(f"An unexpected error occurred: {e}")
