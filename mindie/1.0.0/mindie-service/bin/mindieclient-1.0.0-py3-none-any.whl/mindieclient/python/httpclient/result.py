#!/usr/bin/env python3
# coding=utf-8

# Copyright (c) 2024 Huawei Technologies Co., Ltd
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import rapidjson as json
import numpy as np

# append mindie service path
python_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mindieservice_path = os.path.dirname(os.path.dirname(python_path))
sys.path.append(mindieservice_path)
from mindieclient.python.common.logging import Log
from .utils import raise_error

logger = Log(__name__).getlog()


class Result:
    def __init__(self, response, verbose):
        json_content = response.decode()
        if len(json_content) > (10 * 1024 * 1024):
            raise_error("Response size is larger than 10MB.")
        if verbose:
            logger.info("The json response is {}".format(json_content))
        self._result_dict = json.loads(json_content)

    def retrieve_output_index_to_numpy(self, index):
        output_str = "outputs"
        if self._result_dict.get(output_str) is None:
            raise_error("Result dict does not contain outputs key!")
        if index < 0 or len(self._result_dict[output_str]) <= index:
            raise_error("The index should be in range [0, output_num], \
                but got {}".format(index))
        output = self._result_dict[output_str][index]
        arr = np.array(output["data"], dtype=np.uint32)
        return arr.reshape(output["shape"])

    def retrieve_output_name_to_numpy(self, name):
        if self._result_dict.get("outputs") is None:
            raise_error("Result dict does not contain outputs key!")
        for output in self._result_dict["outputs"]:
            if output["name"] == name:
                arr = np.array(output["data"], dtype=np.uint32)
                return arr.reshape(output["shape"])
            else:
                raise_error(
                    "The name {} is not equal to the response output name {}!".format(
                        name, output["name"]
                    )
                )
        return None

    def get_response(self):
        return self._result_dict
