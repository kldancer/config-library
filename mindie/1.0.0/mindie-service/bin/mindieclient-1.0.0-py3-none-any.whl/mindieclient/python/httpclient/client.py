#!/usr/bin/env python3
# coding=utf-8

# Copyright (c) 2024 Huawei Technologies Co., Ltd
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re
import os
import stat
import sys
import gc
import getpass
import ctypes
import time
import urllib.parse
from ssl import Purpose, create_default_context
import uuid
from typing import List
from urllib.parse import quote, urlparse
import urllib3
import gevent
import gevent.pool
import rapidjson as json
from geventhttpclient.url import URL
import numpy as np


# append mindie service path
python_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mindieservice_path = os.path.dirname(os.path.dirname(python_path))
sys.path.append(mindieservice_path)
from mindieclient.python.common.logging import Log
from .sampling_params_checker import check_sampling_parameters
from .result import Result
from .utils import (
    generate_request_body,
    generate_request_body_token,
    check_response,
    raise_error,
    get_infer_request_uri,
    validate_model_string,
    check_password,
    PathCheck
)

logger = Log(__name__).getlog()

SSL_MUST_KEYS = ["ca_certs", "certfile", "keyfile"]
CRL_FILE = "crlfile"


def _check_variable_type(variable_map: {}, types: ()):
    for name, val in variable_map.items():
        if not isinstance(val, types):
            raise_error(f"The {name}'s type should be {types} but got {type(val)}")


class AsyncRequest:
    """Implement a class that process asynchronous responses in triton token inference mode
    """
    def __init__(self, greenlet, verbose=False):
        """
        Args:
            _res_verbose: show processing information in detail
            _greenlet: the size of gevent pool
        """
        self._res_verbose = verbose
        self._greenlet = greenlet

    def get_result(self, timeout=None):
        """Process the asynchronous responses

        Args:
            timeout: time out
        """
        if timeout is not None:
            _check_variable_type({'timeout': timeout}, (int, float))
            if timeout <= 0:
                raise_error("The timeout should be more than 0!")
        try:
            response = self._greenlet.get(timeout=timeout)
        except gevent.Timeout:
            raise_error("Failed to obtain inference response!")
        check_response(response)
        return Result(response.data, self._res_verbose)


def _check_invalid_url(url, enable_ssl):
    if not isinstance(url, str):
        raise_error("[MIE02E000002] URL version should be a string!")
    parse_res = urlparse(url)
    if enable_ssl and parse_res.scheme != "https":
        raise_error("[MIE02E000002] The scheme should be https when ssl enable!")
    if not enable_ssl and parse_res.scheme != "http":
        raise_error("[MIE02E000002] The scheme should be http when ssl disable!")
    if not parse_res.netloc:
        raise_error("[MIE02E000002] URL should contain netloc!")


def _check_directory_permissions(cur_path):
    cur_stat = os.stat(cur_path)
    cur_mode = stat.S_IMODE(cur_stat.st_mode)
    if cur_mode != 0o700:
        raise_error("The permission of ssl directory should be 700")


def _check_invalid_ssl_filesize(ssl_options):
    def check_size(path: str):
        size = os.path.getsize(path)
        if size > max_size:
            raise_error(f"SSL file should not exceed 10MB!")

    max_size = 10 * 1024 * 1024  # 最大文件大小为10MB
    for ssl_key in SSL_MUST_KEYS:
        check_size(ssl_options[ssl_key])


def _check_invalid_ssl_path(ssl_options):
    def check_single(key: str, path: str):
        is_path_valid, infos = PathCheck.check_cert_path(path)
        if not is_path_valid:
            logger.error(f'[MIE02E000000] {infos} Please check ssl path.')
            raise_error(f"Enum {key} path is invalid")
        _check_directory_permissions(os.path.dirname(path))

    if not isinstance(ssl_options, dict):
        raise_error("ssl_options should be a dict!")
    for ssl_key in SSL_MUST_KEYS:
        if ssl_key not in ssl_options.keys():
            raise_error(f"{ssl_key} should be provided when ssl enable!")
        check_single(ssl_key, ssl_options[ssl_key])


def _check_ca_cert(ssl_options, plain_text):
    server_dir = os.getenv('MIES_INSTALL_PATH')
    if server_dir is None:
        raise_error("[MIE02E000002] Not Found $MIES_INSTALL_PATH, please source mindie set_env.sh firstly.")
    cert_util_path = os.path.join(server_dir, "scripts")
    if not os.path.exists(cert_util_path):
        raise_error("Cert utils path is not found.")
    if cert_util_path not in sys.path:
        sys.path.append(cert_util_path)

    from utils import CertUtil

    ca = "ca_certs"
    cert = "certfile"
    key = "keyfile"

    if not CertUtil.validate_ca_certs(ssl_options[ca]):
        raise_error("CA check failed.")
    if CRL_FILE in ssl_options.keys():
        if not CertUtil.validate_ca_crl(ssl_options[ca], ssl_options[CRL_FILE]):
            raise_error("CRL check failed")
    if not CertUtil.validate_cert_and_key(ssl_options[cert], ssl_options[key], plain_text):
        raise_error("Client Cert check failed.")


def _check_prompt(prompt):
    if not isinstance(prompt, str) and not isinstance(prompt, List):
        raise_error("[MIE02E000002] The prompt should be a string or a list!")
    if len(prompt) < 1 or len(prompt) > 512000:
        raise_error(" The length of prompt should be in range [1, 512000], but got {}!".format(len(prompt)))


def _stream_data_split(stream_data_line):
    stream_data_line = stream_data_line.lstrip("data:").rstrip("\n")
    stream_data_line = re.sub(r'\}\s*data:{', '} ,{', stream_data_line)
    stream_data_line = '[' + stream_data_line + ']'
    json_obj_arr = json.loads(stream_data_line)
    return json_obj_arr


class MindIEHTTPClient:
    """Implement a class that Send requests and receive responses in different mode
    """
    def __init__(
        self,
        url,
        greenlet_size=None,
        enable_ssl=True,
        ssl_options=None,
        network_timeout=600.0,
        connection_timeout=600.0,
        concurrency=1,
        verbose=False,
        enable_management=False,
        management_url="https://127.0.0.2:1026",
    ):
        """
        Args:
            url: business address of server
            greenlet_size: the size of gevent pool
            enable_ssl: the symbol indicates whether the communication uses https protocal or not
            ssl_options: ssl options while communication uses https protocal
            network_timeout: network time out /s
            connection_timeout: connect time out /s
            concurrency: request count
            verbose: show processing information in detail
            enable_management: use managment address to query server status
            management_url: managment address of server
        """
        _check_variable_type({
            "enable_ssl": enable_ssl,
            "verbose": verbose
        }, bool)
        _check_invalid_url(url, enable_ssl)
        if enable_management:
            _check_invalid_url(management_url, enable_ssl)
        # 1000 is the maximum number of connections the server supports
        if greenlet_size is not None:
            _check_variable_type({"greenlet_size": greenlet_size}, int)
            if greenlet_size <= 0 or greenlet_size > 1e9:
                raise_error(
                    "[MIE02E000005] The value of greenlet_size should be in range [1, 1000000000]!"
                )
        _check_variable_type({
            "network_timeout": network_timeout,
            "connection_timeout": connection_timeout
        }, (int, float))
        if concurrency <= 0 or concurrency > 1000:
            raise_error(
                "The number of connections create for client should be  in range [1, 1000]!"
            )
        if connection_timeout <= 0 or network_timeout <= 0:
            raise_error("Connection timeout and network timeout should be more than 0!")

        self.valid_url = URL(url)
        self.manage_url = management_url
        self._common_url = url
        self._context = None
        if enable_ssl:
            if CRL_FILE in ssl_options.keys():
                SSL_MUST_KEYS.append(CRL_FILE)
            _check_invalid_ssl_path(ssl_options)
            _check_invalid_ssl_filesize(ssl_options)
            password = getpass.getpass("Please enter the password: ")
            check_password(password)
            _check_ca_cert(ssl_options, bytes(password, 'utf-8'))
            self._context = create_default_context(Purpose.SERVER_AUTH)
            self._context.load_verify_locations(cafile=ssl_options["ca_certs"])
            self._context.load_cert_chain(
                certfile=ssl_options["certfile"],
                keyfile=ssl_options["keyfile"],
                password=password
            )
            password_len = len(password)
            password_offset = sys.getsizeof(password) - password_len - 1
            ctypes.memset(id(password) + password_offset, 0, password_len)
        else:
            logger.warning("[MIE02W000007] SSL authentication is disabled!")
        try:
            if enable_ssl:
                self._http_pool_manager = urllib3.PoolManager(ssl_context=self._context)
            else:
                self._http_pool_manager = urllib3.PoolManager()
        except Exception as e:
            logger.error("[MIE02E000007] HTTPClient init failed! Please check http settings.")
            raise e
        self._enable_ssl = enable_ssl
        self._ssl_options = ssl_options
        self._pool = gevent.pool.Pool(greenlet_size)
        self._verbose = verbose
        self._requests_list = set()
        self._timeout = min(network_timeout, connection_timeout)

    def __del__(self):
        self.close()

    def is_server_live(self):
        """check if server is still alive
        """
        request_uri = self.manage_url + "/v2/health/live"
        response = self._get(request_uri)
        return response.status == 200

    def is_server_ready(self):
        """check if server is ready to process request
        """
        request_uri = self.manage_url + "/v2/health/ready"
        response = self._get(request_uri)
        return response.status == 200

    def get_server_metadata(self):
        """check metadata in server
        """
        request_uri = "/v2"
        request_uri = self._common_url + request_uri
        response = self._get(request_uri)
        check_response(response)
        json_content = response.data.decode()
        return json.loads(json_content)

    def is_model_ready(self, model_name, model_version=""):
        """check if the specific model is supported by server

        Args:
            model_name: the name of model
            model_version: the version of model
        """
        validate_model_string(model_name, model_version)

        if model_version != "":
            request_uri = self.manage_url + "/v2/models/{}/versions/{}/ready".format(
                quote(model_name), model_version
            )
        else:
            request_uri = self.manage_url + "/v2/models/{}/ready".format(quote(model_name))
        response = self._get(request_uri)
        return response.status == 200

    def get_model_metadata(self, model_name, model_version=""):
        """Get model metadata from server

        Args:
            model_name: the name of model
            model_version: the version of model
        """
        validate_model_string(model_name, model_version)

        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}".format(quote(model_name))
        request_uri = str(self.valid_url) + request_uri
        response = self._get(request_uri)
        check_response(response)
        json_content = response.data.decode()
        return json.loads(json_content)

    def get_model_config(self, model_name, model_version=""):
        """Get model config message from server

        Args:
            model_name: the name of model
            model_version: the version of model
        """
        validate_model_string(model_name, model_version)

        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}/config".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}/config".format(quote(model_name))
        request_uri = str(self.valid_url) + request_uri
        response = self._get(request_uri)
        check_response(response)
        json_content = response.data.decode()
        return json.loads(json_content)

    def close(self):
        """close the gevent pool and close all connection in the pool
        """
        self._http_pool_manager.clear()

    def infer(
        self,
        model_name,
        inputs,
        model_version="",
        outputs=None,
        request_id="",
        parameters=None,
    ):
        """triton token inference mode

        Args:
            model_name: the name of model
            inputs: input tokens
            model_version: the version of model
            outputs: output tokens
            request_id: id of current request
            parameters: inference parameters
        """
        validate_model_string(model_name, model_version)
        if len(inputs) != 1:
            raise_error("The size of inputs only supports 1!")
        if outputs is not None and len(outputs) != 1:
            raise_error("The size of requested outputs only supports 1")

        request_id = self._check_request_id(request_id)

        infer_request_body = generate_request_body(
            inputs=inputs,
            request_id=request_id,
            outputs=outputs,
            parameters=parameters,
        )

        infer_request_uri = str(self.valid_url) + \
            get_infer_request_uri(model_name, model_version)

        response = self._post(
            request_uri=infer_request_uri, request_body=infer_request_body
        )
        try:
            check_response(response)
            return Result(response.data, self._verbose)
        finally:
            self._requests_list.remove(request_id)

    def async_infer(
        self,
        model_name,
        inputs,
        model_version="",
        outputs=None,
        request_id="",
        parameters=None,
    ):
        """triton token asynchronous inference

        Args:
            model_name: the name of model
            inputs: input tokens
            model_version: the version of model
            outputs: output tokens
            request_id: id of current request
            parameters: inference parameters
        """
        validate_model_string(model_name, model_version)
        if len(inputs) != 1:
            raise_error("The size of inputs only supports 1!")
        if outputs is not None and len(outputs) != 1:
            raise_error("The size of requested outputs only supports 1")

        request_id = self._check_request_id(request_id)

        def post_func(request_uri, request_body):
            return self._post(request_uri, request_body)

        async_request_body = generate_request_body(
            inputs=inputs,
            request_id=request_id,
            outputs=outputs,
            parameters=parameters,
        )

        async_request_uri = str(self.valid_url) + \
            get_infer_request_uri(model_name, model_version)

        g = self._pool.apply_async(post_func, (async_request_uri, async_request_body))
        g.start()
        gevent.sleep(0.01)

        if self._verbose:
            logger.info("Current Post Request_id is: %s", request_id)
        self._requests_list.remove(request_id)
        return AsyncRequest(g, self._verbose)

    def generate(
        self,
        model_name,
        prompt,
        model_version="",
        request_id="",
        parameters=None,
    ):
        """triton text inference

        Args:
            model_name: the name of model
            prompt: input text
            model_version: the version of model
            request_id: id of current request
            parameters: inference parameters
        """
        validate_model_string(model_name, model_version)
        _check_prompt(prompt)
        check_sampling_parameters(parameters, "client")

        request_id = self._check_request_id(request_id)
        request_body = generate_request_body(
            inputs=prompt,
            request_id=request_id,
            parameters=parameters,
            is_generate=True,
        )

        if not isinstance(model_version, str):
            self._raise_error_with_clear("Model version should be a string!", request_id)
        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}/generate".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}/generate".format(quote(model_name))
        final_uri = str(self.valid_url) + request_uri

        response = self._post(request_uri=final_uri, request_body=request_body)
        try:
            check_response(response)
            return Result(response.data, self._verbose)
        finally:
            self._requests_list.remove(request_id)

    def generate_stream(
        self,
        model_name,
        prompt,
        model_version="",
        request_id="",
        parameters=None,
    ):
        """triton text inference in stream mode

        Args:
            model_name: the name of model
            prompt: input text
            model_version: the version of model
            request_id: id of current request
            parameters: inference parameters
        """
        validate_model_string(model_name, model_version)
        _check_prompt(prompt)
        check_sampling_parameters(parameters, "client")

        request_id = self._check_request_id(request_id)

        stream_request_body = generate_request_body(
            inputs=prompt, request_id=request_id,
            parameters=parameters, is_generate=True,
        )

        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}/generate_stream".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}/generate_stream".format(quote(model_name))

        if self._verbose:
            logger.info("POST %s \n %s", request_uri, stream_request_body)

        final_uri = str(self.valid_url) + request_uri

        try:
            response = self._http_pool_manager.request("POST",
                                                       final_uri, body=stream_request_body,
                                                       timeout=self._timeout, preload_content=False,
                                                       )
        except urllib3.exceptions.TimeoutError:
            self._raise_error_with_clear("Post request timeout in generate_stream.", request_id)
        except Exception as err:
            self._raise_error_with_clear("Request failed and the reason is {}.".format(err), request_id)

        total_response = ""
        for byte_line in response.stream():
            if byte_line == b"\n":
                continue
            cur_line = byte_line.decode()
            if cur_line.startswith("data:"):
                for json_content in _stream_data_split(cur_line):
                    total_response += json_content["text_output"]
                    yield json_content["text_output"]
            elif cur_line == "engine callback timeout.":
                self._raise_error_with_clear(
                    f"[MIE02E000407]Engine time out. The tokens generation of {request_id} might be incomplete. "
                    f"Please check server log.", request_id)
            else:
                self._raise_error_with_clear(
                    f"[MIE02E000407]Response of {request_id} is wrong: {cur_line}", request_id)
        if self._verbose:
            logger.info("Post response: %s", total_response)
        self._requests_list.remove(request_id)

    def generate_stream_self(
        self,
        token,
        request_id,
        parameters,
    ):
        """mindie token inference in stream mode

        Args:
            token: input tokens
            request_id: id of current request
            parameters: inference parameters
        """
        if not isinstance(token, np.ndarray):
            raise_error("[MIE02E000102] After data preprocess input token should be a ndarray!")
        if token.shape[-1] < 1 or token.shape[-1] > 512000:
            raise_error("[MIE02E000102] The length of prompt should be in range [1, 512000], "
                        "but got {}!".format(token.shape[-1]))

        check_sampling_parameters(parameters, "client_token")
        request_id = self._check_request_id(request_id)

        stream_request_body = generate_request_body_token(
            token=token, is_stream=True,
            parameters=parameters
        )

        request_uri = "/infer_token"

        if self._verbose:
            logger.info("POST %s \n %s", request_uri, stream_request_body)

        final_uri = str(self.valid_url) + request_uri
        try:
            response = self._http_pool_manager.request("POST",
                    final_uri, body=stream_request_body,
                    timeout=self._timeout, preload_content=False,
                )
        except urllib3.exceptions.TimeoutError:
            self._raise_error_with_clear(f"The post request timeout in generate_stream_with_details", request_id)
        except Exception as err:
            self._raise_error_with_clear(f"Request failed and the reason is {err}.", request_id)

        text_output = "token"
        for byte_line in response.stream():
            if byte_line == b"\n":
                continue
            cur_line = byte_line.decode()
            if cur_line == "engine callback timeout.":
                self._raise_error_with_clear(
                    f"Engine time out. The tokens generation of {request_id} might be incomplete.", request_id)
            try:
                for json_content in _stream_data_split(cur_line):
                    response_dict = {text_output: json_content[text_output]}
                    response_dict["decode_time"] = json_content["decode_time"]
                    response_dict["prefill_time"] = json_content["prefill_time"]
                    yield response_dict
            except Exception as error:
                self._raise_error_with_clear(
                    f"Request failed and the reason is {error}, response from server is: {cur_line}", request_id)
        self._requests_list.remove(request_id)

    def generate_stream_with_details(
        self,
        model_name,
        prompt,
        model_version="",
        request_id="",
        parameters=None,
    ):
        """triton text inference in stream mode with detailed message

        Args:
            model_name: the name of model
            prompt: input text
            model_version: the version of model
            request_id: id of current request
            parameters: inference parameters
        """
        validate_model_string(model_name, model_version)
        _check_prompt(prompt)
        check_sampling_parameters(parameters, "client")

        request_id = self._check_request_id(request_id)

        stream_request_body = generate_request_body(
            inputs=prompt, request_id=request_id,
            parameters=parameters, is_generate=True,
        )

        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}/generate_stream".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}/generate_stream".format(quote(model_name))

        if self._verbose:
            logger.info("POST %s \n %s", request_uri, stream_request_body)

        final_uri = str(self.valid_url) + request_uri
        try:
            response = self._http_pool_manager.request("POST",
                    final_uri, body=stream_request_body,
                    timeout=self._timeout, preload_content=False,
                )
        except urllib3.exceptions.TimeoutError:
            self._raise_error_with_clear(f"The post request timeout in generate_stream_with_details", request_id)
        except Exception as err:
            self._raise_error_with_clear(f"[MIE02E000407] Request failed and the reason is {err}.", request_id)

        text_output = "text_output"
        details = "details"
        for byte_line in response.stream():
            if byte_line == b"\n":
                continue
            cur_line = byte_line.decode()
            if cur_line == "engine callback timeout.":
                self._raise_error_with_clear(
                    f"[MIE02E000407] Engine time out. "
                    f"The tokens generation of {request_id} might be incomplete.", request_id)

            try:
                for json_content in _stream_data_split(cur_line):
                    response_dict = {text_output: json_content[text_output]}
                    if details in parameters and parameters[details]:
                        response_dict["batch_size"] = json_content[details]["batch_size"]
                        response_dict["queue_wait_time"] = json_content[details]["queue_wait_time"]
                        response_dict["decode_time"] = json_content["decode_time"]
                        response_dict["prefill_time"] = json_content["prefill_time"]
                    yield response_dict
            except Exception as error:
                self._raise_error_with_clear(
                    f"[MIE02E000407] Request failed and the reason is {error}, "
                    f"response from server is: {cur_line}", request_id)
        self._requests_list.remove(request_id)

    def generate_chat(
        self,
        model_name,
        prompt,
        request_id="",
        parameters=None
    ):
        """openai text inference

        Args:
            model_name: the name of model
            prompt: input text
            request_id: id of current request
            parameters: inference parameters
        """
        try:
            return self._prepare_chat(model_name, prompt, request_id, parameters, is_stream=False).data.decode()
        finally:
            self._requests_list.remove(request_id)

    def generate_chat_stream(
        self,
        model_name,
        prompt,
        request_id="",
        parameters=None
    ):
        """openai text inference in stream mode

        Args:
            model_name: the name of model
            prompt: input text
            request_id: id of current request
            parameters: inference parameters
        """
        last_time_point = time.time()
        time_name = "prefill_time"
        end_sign = "data: [DONE]"
        for byte_line in self._prepare_chat(model_name, prompt, request_id, parameters, is_stream=True).stream():
            if byte_line == b"\n":
                continue
            cur_line = byte_line.decode()
            if end_sign in cur_line:
                cur_line = cur_line[:cur_line.find(end_sign)]
            try:
                for json_content in _stream_data_split(cur_line):
                    cur_time_point = time.time()
                    response_dict = {
                        "text_output": json_content["choices"][0]["delta"]["content"],
                        time_name: (cur_time_point - last_time_point) * 1000
                    }
                    yield response_dict
                    time_name = "decode_time"
                    last_time_point = time.time()
            except Exception as error:
                self._raise_error_with_clear(
                    f"Request failed and the reason is {error}, response from server is: {cur_line}", request_id)
        self._requests_list.remove(request_id)

    def cancel(
        self,
        model_name,
        request_id,
        model_version="",
    ):
        """cancel all inference in server

        Args:
            model_name: the name of model
            request_id: id of current request
            model_version: the version of model
        """
        validate_model_string(model_name, model_version)

        if model_version != "":
            request_uri = "/v2/models/{}/versions/{}/stopInfer".format(
                quote(model_name), model_version
            )
        else:
            request_uri = "/v2/models/{}/stopInfer".format(quote(model_name))
        request_uri = str(self.valid_url) + request_uri
        infer_request = {"id": request_id}
        request_body = json.dumps(infer_request)
        response = self._post(
            request_uri=request_uri,
            request_body=request_body,
        )
        if response.status == 422:
            return True
        check_response(response)
        body = response.data.decode("utf-8")
        result = json.loads(body)
        if response.status == 200 and result["id"] == request_id:
            logger.info("Cancel %s succeed!", request_id)
            return True
        else:
            logger.error("[MIE02E000407] Cancel %s falied! Please check the status of server.", request_id)
            return False

    def get_slot_count(self, model_name, model_version=""):
        """query the slot count of server

        Args:
            model_name: the name of model
            model_version: the version of model
        """
        validate_model_string(model_name, model_version)

        if model_version != "":
            request_uri = self.manage_url + "/v2/models/{}/versions/{}/getSlotCount".format(
                quote(model_name), model_version
            )
        else:
            request_uri = self.manage_url + "/v2/models/{}/getSlotCount".format(quote(model_name))
        response = self._get(request_uri)
        check_response(response)
        return Result(response.data, self._verbose)

    def _prepare_chat(
            self,
            model_name,
            prompt,
            request_id="",
            parameters=None,
            is_stream=True
    ):
        _check_prompt(prompt)
        check_sampling_parameters(parameters, "openai")
        self._check_request_id(request_id)

        request_body = {
            "model": model_name,
            "messages": [{
                "role": "user",
                "content": prompt
            }],
            "stream": is_stream
        }
        request_body.update(parameters)
        request_body = json.dumps(request_body).encode()
        final_uri = urllib.parse.urljoin(str(self.valid_url), "/v1/chat/completions")
        return self._http_pool_manager.request("POST", final_uri, body=request_body, timeout=self._timeout,
                                               preload_content=not is_stream)

    def _raise_error_with_clear(self, message, request_id=""):
        if request_id in self._requests_list:
            self._requests_list.remove(request_id)
        raise_error(message)

    def _get(self, request_uri):
        if self._verbose:
            logger.info("GET %s", request_uri)
        try:
            response = self._http_pool_manager.request(
                "GET",
                request_uri,
                timeout=self._timeout,
            )
        except urllib3.exceptions.TimeoutError:
            raise_error("The get http request timeout.")
        except urllib3.exceptions.RequestError as err:
            raise_error("Request failed and the reason is {}.".format(err))
        if self._verbose:
            logger.info("Get response: %s", response.data.decode())
        return response

    def _post(self, request_uri, request_body):
        def generate_error_code(request_uri):
            if "v2/models" in request_uri:
                return "[MIE02E000407]"
            else:
                return ""
        if self._verbose:
            logger.info("POST %s \n %s", request_uri, request_body)
        try:
            response = self._http_pool_manager.request("POST",
                                                       request_uri, body=request_body,
                                                       timeout=self._timeout,
                                                       )
        except urllib3.exceptions.TimeoutError:
            raise_error("POST request timeout occurred.")
        except urllib3.exceptions.RequestError as err:
            raise_error(f"{generate_error_code(request_uri)}Request failed and the reason is {err}.")
        if self._verbose:
            logger.info("Post response: %s", response.data.decode())
        return response

    def _check_request_id(self, request_id):
        _check_variable_type({"request_id": request_id}, str)
        if len(request_id) > 1000:
            raise_error("[MIE02E000002]The length of request_id should be no more than 1000, "
                        "but got {}".format(len(request_id)))
        if request_id in self._requests_list:
            raise_error("Duplicate request_id {}, please change!".format(request_id))
        if not request_id:
            request_id = uuid.uuid4().hex
            logger.info("Request_id %s is generated for this request", request_id)
        self._requests_list.add(request_id)
        return request_id

    def _get_requests_list(self):
        return self._requests_list
