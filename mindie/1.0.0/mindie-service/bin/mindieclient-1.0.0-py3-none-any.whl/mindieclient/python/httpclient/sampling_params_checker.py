#!/usr/bin/env python3
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import re
from typing import Dict
from mindieclient.python.common.logging import Log

logger = Log(__name__).getlog()

INT32_RANGE = '(-2147483647, 2147483647]'
INT64_RANGE = '(-18446744073709551615, 18446744073709551615]'

support_sample_params_map = {
    "openai": {
        "model":               ((str, ), ''),
        "stream":              ((bool, ), ''),
        "presence_penalty":    ((float, int), ''),
        "frequency_penalty":   ((float, int), ''),
        "repetition_penalty":  ((float, int), ''),
        "temperature":         ((float, int), ''),
        "top_p":               ((float, int), ''),
        "top_k":               ((int, ), INT32_RANGE),
        "seed":                ((int, ), INT64_RANGE),
        "include_stop_str_in_output": ((bool, ), ''),
        "skip_special_tokens": ((bool, ), ''),
        "ignore_eos":          ((bool, ), ''),
        "max_tokens":          ((int, ), INT32_RANGE)
    },
    "client": {
        "details":             ((bool, ), ''),
        "do_sample":           ((bool, ), ''),
        "max_new_tokens":      ((int, ), INT32_RANGE),
        "repetition_penalty":  ((float, int), ''),
        "seed":                ((int, ), INT64_RANGE),
        "temperature":         ((float, int), ''),
        "top_k":               ((int, ), INT32_RANGE),
        "top_p":               ((float, int), ''),
        "batch_size":          ((int, ), INT32_RANGE),
        "typical_p":           ((float, ), ''),
        "watermark":           ((bool, ), ''),
        "perf_stat":           ((bool, ), ''),
        "firstTokenCost":      ((int, ), INT64_RANGE),
        "decodeTime":          ((list, ), '')
    },
    "client_token": {
        "stream":              ((bool, ), ''),
        "temperature":         ((float, int), ''),
        "top_k":               ((int, ), INT32_RANGE),
        "top_p":               ((float, int), ''),
        "max_new_tokens":      ((int, ), INT32_RANGE),
        "do_sample":           ((bool, ), ''),
        "seed":                ((int, ), INT64_RANGE),
        "repetition_penalty":  ((float, int), ''),
        "details":             ((bool, ), ''),
        "typical_p":           ((float, int), ''),
        "watermark":           ((bool, ), ''),
        "priority":            ((int, ), INT64_RANGE),
        "timeout":             ((int, ), INT64_RANGE)
    }
}


def check_type_and_range(name, value, types, value_range):
    """
    Validate a parameter's type and range.

    Args:
        name: The name of the variable (str).
        value: The value of the variable (int, float, or bool).
        types: A tuple of allowed types (e.g., (int, float)).
        value_range: A string defining the allowed range (e.g., "(0.0, +inf)").
                        Parentheses () mean exclusive, brackets [] mean inclusive.
    Raises:
        ValueError: If the value's type or range is invalid.
    """
    # Validate type
    if not isinstance(value, types):
        raise ValueError(f"{name} check failed: expect one of {types}, but got {type(value)}")
    if not value_range:
        return

    # Parse value_range
    match = re.match(
        r"^([\[\(])\s*(-?inf|\+?inf|[-+]?\d*\.?\d+)\s*,\s*(-?inf|\+?inf|[-+]?\d*\.?\d+)\s*([\]\)])$",
        value_range)
    if not match:
        raise ValueError(f"{name} check failed: invalid range format '{value_range}'")
    left_bracket, lower_bound, upper_bound, right_bracket = match.groups()

    # Convert bounds to float
    lower_bound = float("-inf") if lower_bound == "-inf" else float(lower_bound)
    upper_bound = float("inf") if upper_bound == "+inf" else float(upper_bound)

    # Check value within range
    in_range = (
        (lower_bound < value if left_bracket == '(' else lower_bound <= value) and
        (value < upper_bound if right_bracket == ')' else value <= upper_bound)
    )

    if not in_range:
        raise ValueError(
            f"{name} check failed: value {value} not in range {value_range}"
        )


def check_sampling_parameters(sample_params: Dict, test_type: str):
    """Check sample parameters.

    Args:
        sample_params (Dict): The parameters need to check.
        test_type (str): The specific interface c
    """
    if not sample_params:
        logger.warning("Input parameter is empty, skip to check parameters.")
        return
    if test_type not in support_sample_params_map:
        raise ValueError(f"Support input of check sample parameters are: {support_sample_params_map.keys()}, but "
                         f"got {test_type}.")
    support_sample_params = support_sample_params_map.get(test_type)
    for key, value in sample_params.items():
        if key not in support_sample_params:
            logger.warning(f"Parameter '{key}' is not support, please remove it.")
        else:
            types, value_range = support_sample_params.get(key)
            check_type_and_range(key, value, types, value_range)
