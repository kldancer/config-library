#!/usr/bin/env python3
# coding=utf-8

# Copyright (c) 2024 Huawei Technologies Co., Ltd
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import re
import stat
from typing import Tuple
from dataclasses import dataclass
from urllib.parse import quote
import rapidjson as json

# append mindie service path
python_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mindieservice_path = os.path.dirname(os.path.dirname(python_path))
sys.path.append(mindieservice_path)
from mindieclient.python.common.logging import Log

logger = Log(__name__).getlog()


class MindIEClientException(Exception):
    def __init__(self, message):
        super().__init__()
        if len(message) == 0 or len(message) > 512000:
            raise_error("The length of message should be in range[1, 512000], \
                but got {}".format(len(message)))
        self._error_message = message

    def get_message(self):
        return self._error_message


def generate_request_body(
    inputs,
    request_id,
    parameters,
    outputs=None,
    is_generate=False,
):
    request_dict = {}
    request_dict["id"] = request_id
    if is_generate:
        request_dict["text_input"] = inputs
    else:
        request_dict["inputs"] = []
        for cur_input in inputs:
            request_dict["inputs"].append(cur_input.get_input_tensor())

        request_dict["outputs"] = []
        for cur_output in outputs:
            request_dict["outputs"].append(cur_output.get_output_tensor())

    if parameters != {}:
        request_dict["parameters"] = parameters

    request_body = json.dumps(request_dict)
    return request_body.encode()


def generate_request_body_token(
    token,
    is_stream,
    parameters
):
    request_dict = {}
    request_dict["input_id"] = token[0].tolist()
    request_dict["stream"] = is_stream

    if parameters != {}:
        request_dict["parameters"] = parameters

    request_body = json.dumps(request_dict)
    return request_body.encode()


def get_infer_request_uri(model_name, model_version):
    if not isinstance(model_version, str):
        raise_error("Model version should be a string!")
    if model_version != "":
        request_uri = "/v2/models/{}/versions/{}/infer".format(
            quote(model_name), model_version
        )
    else:
        request_uri = "/v2/models/{}/infer".format(quote(model_name))
    return request_uri


def check_response(response):
    if response.status != 200:
        try:
            json_content = response.data.decode("utf-8")
            response_dict = json.loads(json_content)
            if response_dict.get("error") is None:
                error = MindIEClientException(
                    message=f"Error status code: {response.status_code}"
                )
            else:
                error = MindIEClientException(message=response_dict["error"])
        except Exception as e:
            error = MindIEClientException(
                message=f"An exception occurred in client while decoding the response: {e}"
            )
        logger.error("[MIE02W00006] Get response failed : %s", error.get_message())
        raise error


def validate_model_string(model_name, model_version):
    if len(model_name) > 1000:
        raise_error("The length of model name should be no more than 1000!")
    if len(model_version) > 1000:
        raise_error("The length of model version should be no more than 1000!")
    pattern = r"^[a-zA-Z_0-9.-]+$"
    if not isinstance(model_name, str) or not re.match(pattern, model_name):
        raise_error("Model name should be a string and valid!")
    if not isinstance(model_version, str) or (
        model_version != "" and not re.match(pattern, model_name)
    ):
        raise_error("Model version should be a string and valid!")


def raise_error(message):
    logger.error(message)
    raise MindIEClientException(message=message) from None


def check_password(password):
    min_pass_len = 8
    if len(password) < min_pass_len:
        raise_error("The length of password must be >= 8.")

    # uppercase, lowercase, digit, symbol
    types = [0, 0, 0, 0]
    special_characters = set("~!@#$%^&*()-_=+\\|[{}];:'\",<.>/? ")
    for char in password:
        if char.isupper():
            types[0] = 1
        elif char.islower():
            types[1] = 1
        elif char.isdigit():
            types[2] = 1
        elif char in special_characters:
            types[3] = 1
        else:
            raise_error("Password check failed.")

    # 检查是否至少包括两种类型的字符
    if sum(types) < 2:
        raise_error("Password check failed.")


class PathCheck(object):

    @classmethod
    def check_path_full(cls, path: str, is_support_root: bool = True) -> Tuple[bool, str]:
        # 检查路径是否合法
        ret, infos = cls.check_path_valid(path)
        if not ret:
            return ret, infos

        # 检查是否为软链接
        ret, infos = cls.check_path_link(path)
        if not ret:
            return ret, infos

        # 检查路径是否存在
        ret, infos = cls.check_path_exists(path)
        if not ret:
            return ret, infos

        # 检查路径属组
        return cls.check_path_owner_group_valid(path, is_support_root)

    @classmethod
    def check_cert_path(cls, path: str) -> Tuple[bool, str]:
        ret, infos = cls.check_path_full(path)
        if not ret:
            return ret, infos

        # 检查mode
        ret1, _ = cls.check_path_mode(0o400, path)
        ret2, _ = cls.check_path_mode(0o600, path)
        if ret1 or ret2:
            return True, ""
        return False, "Cert path mode should be 600 or 400."

    @classmethod
    def check_path_valid(cls, path: str) -> Tuple[bool, str]:
        if not path:
            return False, "The path is empty."
        if len(path) > 1024:
            return False, " The length of path exceeds 1024 characters."

        pattern_name = re.compile(r"[^0-9a-zA-Z_./-]")
        match_name = pattern_name.findall(path)
        if match_name or ".." in path:
            return False, "The path contains special characters."

        return True, ""

    @classmethod
    def check_path_exists(cls, path: str) -> Tuple[bool, str]:
        if not os.path.exists(path):
            return False, "The path is not exists."
        return True, ""

    @classmethod
    def check_path_link(cls, path: str) -> Tuple[bool, str]:
        if os.path.islink(os.path.normpath(path)):
            return False, "The path is a soft link."
        return True, ""

    @classmethod
    def check_path_mode(cls, mode: int, path: str) -> Tuple[bool, str]:
        cur_stat = os.stat(path)
        cur_mode = stat.S_IMODE(cur_stat.st_mode)
        if cur_mode != mode:
            return False, "Check the path mode failed."
        return True, ""

    @classmethod
    def check_path_owner_group_valid(cls, path: str, is_support_root: bool = True) -> Tuple[bool, str]:
        cur_user_id = os.getuid()
        cur_user_grp_id = os.getgid()

        file_info = os.stat(path)
        file_user_id = file_info.st_uid
        file_user_grp_id = file_info.st_gid

        flag = file_user_id == cur_user_id and file_user_grp_id == cur_user_grp_id
        if is_support_root:
            flag = flag or (file_user_id == 0 and file_user_grp_id == 0)
        if flag:
            return True, ""
        error_strs = []
        if file_user_id != cur_user_id:
            error_strs.append("Check the path owner failed.")
        if file_user_grp_id != cur_user_grp_id:
            error_strs.append("Check the path group failed.")
        return False, " ".join(error_strs)
