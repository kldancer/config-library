#!/usr/bin/env python3
# coding=utf-8

# Copyright (c) 2024 Huawei Technologies Co., Ltd
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import time
import stat
import logging
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler


class NoNewlineFormatter(logging.Formatter):
    def format(self, record):
        special_chars = [
            '\n', '\r', '\f', '\t', '\v', '\b',
            '\u000A', '\u000D', '\u000C',
            '\u000B', '\u0008', '\u007F',
            '\u0009', '    ',
        ]
        for c in special_chars:
            record.msg = str(record.msg).replace(c, ' ')
        if record.levelname == "WARNING":
            record.levelname = "WARN"
        return super(NoNewlineFormatter, self).format(record)

    def formatTime(self, record, datefmt=None):
        timezone_offset = time.timezone
        offset_hours = -timezone_offset // 3600
        dt = datetime.fromtimestamp(record.created, timezone(timedelta(hours=offset_hours)))
        timestamp = dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        offset = dt.strftime("%z")
        offset = f"{offset[:3]}:{offset[3:]}"
        return f"{timestamp}{offset} DST" if time.daylight else f"{timestamp}{offset}"


def change_to_readonly(file_name):
    current_permissions = os.stat(file_name).st_mode
    new_permissions = current_permissions & ~(stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
    os.chmod(file_name, new_permissions)


def create_log_file(log_file):
    mode = 0o640
    if not os.path.exists(log_file):
        with os.fdopen(os.open(log_file, os.O_CREAT, mode), "w"):
            pass
    else:
        clean_path = os.path.normpath(log_file)
        if os.path.islink(clean_path):
            raise ValueError(f"Path of log file is a soft link")
    os.chmod(log_file, mode)


class CustomRotatingFileHandler(RotatingFileHandler):
    def rotate(self, source, dest):
        super().rotate(source, dest)
        change_to_readonly(dest)
        create_log_file(source)


class Log(object):
    def __init__(self, logger=None, loglevel=logging.INFO):
        self.logger = logging.getLogger('client')
        self.logger.setLevel(loglevel)

        save_path = os.path.join(os.getcwd(), "log")
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        os.chmod(save_path, 0o750)
        file_name = "client_log.log"
        self.logname = os.path.join(save_path, file_name)
        create_log_file(self.logname)

        # 10485760 is 10 MB, 10 is the maximum number of files that can be saved
        fh = CustomRotatingFileHandler(self.logname, maxBytes=10485760, backupCount=10)
        fh.setLevel(logging.INFO)
        if not self.logger.handlers:
            ch = logging.StreamHandler()
            ch.setLevel(logging.INFO)
            formatter = NoNewlineFormatter(
                '[%(asctime)s] [%(process)d] [%(thread)d] [%(name)s] [%(levelname)s] '
                '[%(filename)s:%(lineno)s] %(message)s'
            )
            fh.setFormatter(formatter)
            ch.setFormatter(formatter)
            self.logger.addHandler(fh)
            self.logger.addHandler(ch)

    def getlog(self):
        return self.logger

    def set_log_file_permission(self, perm=0o440):
        # 结束后修改日志权限
        os.chmod(self.logname, perm)
