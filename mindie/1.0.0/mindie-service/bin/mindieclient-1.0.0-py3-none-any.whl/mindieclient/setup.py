#!/usr/bin/env python3
# coding=utf-8

# Copyright (c) 2024 Huawei Technologies Co., Ltd
# All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import argparse
from setuptools import setup, find_packages


os.environ["SOURCE_DATE_EPOCH"] = "0"
# 创建一个参数解析实例
parser = argparse.ArgumentParser(description="Setup Parameters")
parser.add_argument("--setup_cmd", type=str, default="bdist_wheel")
parser.add_argument("--version", type=str, default="1.0.RC1")

# 开始解析
args = parser.parse_args()
# 把路径参数从系统命令中移除，只保留setup需要的参数
sys.argv = [sys.argv[0], args.setup_cmd]
print(sys.argv)

mindie_service_version = args.version

setup(
    name="mindieclient",
    version=mindie_service_version,
    author="ascend",
    description="build wheel for mindie client",
    setup_requires=[],
    zip_safe=False,
    python_requires=">=3.9",
    install_requires=[],
    include_package_data=True,
    packages=find_packages(),
)
