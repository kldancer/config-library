# coding=utf-8
# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.


from functools import reduce
import os
import argparse
import stat

MAX_PATH_LENGTH = 4096
MAX_FILE_SIZE = 10 * 1024 * 1024
MAX_LINENUM_PER_FILE = 10 * 1024 * 1024

FLAG_OS_MAP = {
    'r': os.O_RDONLY, 'r+': os.O_RDWR,
    'w': os.O_CREAT | os.O_TRUNC | os.O_WRONLY,
    'w+': os.O_CREAT | os.O_TRUNC | os.O_RDWR,
    'a': os.O_CREAT | os.O_APPEND | os.O_WRONLY,
    'a+': os.O_CREAT | os.O_APPEND | os.O_RDWR,
    'x': os.O_CREAT | os.O_EXCL,
    "b": getattr(os, "O_BINARY", 0)
}


def safe_open(file_path: str, mode='r', encoding=None, permission_mode=0o600, is_exist_ok=True, **kwargs):
    """
    :param file_path: 文件路径
    :param mode: 文件打开模式
    :param encoding: 文件编码方式
    :param permission_mode: 文件权限模式
    :param is_exist_ok: 是否允许文件存在
    :param max_path_length: 文件路径最大长度
    :param max_file_size: 文件最大大小，单位: 字节, 默认值10MB
    :param check_link: 是否校验软链接
    :param kwargs:
    :return:
    """
    max_path_length = kwargs.get('max_path_length', MAX_PATH_LENGTH)
    max_file_size = kwargs.get('max_file_size', MAX_FILE_SIZE)
    check_link = kwargs.get('check_link', True)

    file_path = standardize_path(file_path, max_path_length, check_link)
    check_file_safety(file_path, mode, is_exist_ok, max_file_size)

    flags = []
    for item in list(mode):
        if item == "+" and flags:
            flags[-1] = f"{flags[-1]}+"
            continue
        flags.append(item)
    flags = [FLAG_OS_MAP.get(mode, os.O_RDONLY) for mode in flags]
    total_flag = reduce(lambda a, b: a | b, flags)

    return os.fdopen(os.open(file_path, total_flag, permission_mode),
                     mode, encoding=encoding)


def standardize_path(path: str, max_path_length=MAX_PATH_LENGTH, check_link=True):
    """
    check path
    param: path
    return: data real path after check
    """
    check_path_is_none(path)
    check_path_length_lt(path, max_path_length)
    if check_link:
        check_path_is_link(path)
    path = os.path.realpath(path)
    return path


def is_path_exists(path: str):
    return os.path.exists(path)


def check_path_is_none(path: str):
    if path is None:
        raise argparse.ArgumentTypeError("The file path should not be None.")


def check_path_is_link(path: str):
    if os.path.islink(os.path.normpath(path)):
        raise argparse.ArgumentTypeError("The path should not be a symbolic link file.")


def check_path_length_lt(path: str, max_path_length=MAX_PATH_LENGTH):
    if path.__len__() > max_path_length:
        raise argparse.ArgumentTypeError(f"The length of path should not be greater than {max_path_length}.")


def check_file_size_lt(path: str, max_file_size=MAX_FILE_SIZE):
    if os.path.getsize(path) > max_file_size:
        raise argparse.ArgumentTypeError(f"The size of path should not be greater than {max_file_size}.")


def check_owner(path: str):
    """
    check the path owner
    param: the input path
    """
    path_stat = os.stat(path)
    path_owner, path_gid = path_stat.st_uid, path_stat.st_gid
    user_check = path_owner == os.getuid() and path_owner == os.geteuid()
    if not (path_owner == 0 or path_gid in os.getgroups() or user_check):
        raise argparse.ArgumentTypeError("The path is not owned by current user or root")


def check_other_write_permission(file_path: str):
    """
    check if the specified file is writable by others who are neither the owner nor in the group
    param: the path to the file to be checked
    """
    # Get the status of the file
    file_stat = os.stat(file_path)
    # Get the mode (permission) of the file
    mode = file_stat.st_mode
    # check the write permission for others
    if mode & stat.S_IWOTH:
        raise argparse.ArgumentTypeError("The file should not be writable by others "
                                         "who are neither the owner nor in the group")


def check_path_permission(file_path: str):
    check_owner(file_path)
    check_other_write_permission(file_path)


def check_file_safety(file_path: str, mode='r', is_exist_ok=True, max_file_size=MAX_FILE_SIZE):
    if is_path_exists(file_path):
        if not is_exist_ok:
            raise argparse.ArgumentTypeError("The file already exists.")
        check_file_size_lt(file_path, max_file_size)
        file_dir = file_path
    else:
        if mode == 'r' or mode == 'r+':
            raise argparse.ArgumentTypeError("The file doesn't exist.")
        file_dir = os.path.dirname(file_path)

    check_path_permission(file_dir)


def safe_chmod(file_path: str, permission_mode):
    standard_path = standardize_path(file_path)
    check_path_permission(standard_path)
    os.chmod(file_path, permission_mode)


def has_owner_write_permission(file_path: str):
    st = os.stat(file_path)
    return st.st_mode & stat.S_IWUSR


def safe_readlines(file_obj, max_line_num=MAX_LINENUM_PER_FILE):
    lines = file_obj.readlines()
    if len(lines) > max_line_num:
        raise argparse.ArgumentTypeError(f"The file line num is {len(lines)}, "
                                         f"which exceeds the limit {max_line_num}.")
    return lines
