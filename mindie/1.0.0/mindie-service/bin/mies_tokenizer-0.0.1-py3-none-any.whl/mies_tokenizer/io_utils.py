# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import os
import shutil
import base64
import binascii
import logging
from io import BytesIO
from multiprocessing import shared_memory
import requests
from PIL import Image
from . import file_utils

logger = logging.getLogger(f"tokenizer-{os.getpid()}")


def fetch_media_url(image_url, input_type: str, ext: str, 
                    media_type_dict:dict[str, list[str]], size_limit_dict: dict[str, int]):
    if ext.lower() not in media_type_dict.get(input_type):
        raise ValueError(f"The media type is {input_type}, url must end with one of {media_type_dict.get(input_type)}.")
    
    size_limit = size_limit_dict.get(input_type, 0)
    if size_limit <= 0:
        raise ValueError(f'Invalid size limit for input type: {input_type}.')
    
    try:
        with requests.get(image_url, stream=True, timeout=5, verify=True) as response:
            response.raise_for_status()

            media_content = bytearray()
            total_size = 0
            for chunk in response.iter_content(chunk_size=size_limit):
                if chunk:
                    total_size += len(chunk)
                    if total_size > size_limit:
                        raise ValueError(f'The size of {input_type} exceeds the limit '
                                         f'of {size_limit / (1024 * 1024):.2f} MB.')
                    media_content.extend(chunk)
            return bytes(media_content), total_size
    except requests.RequestException as e:  
        raise RuntimeError("Download error") from e
    

def save_image(image_byte_data, image_save_path):
    single_image_limit = 20 * 1024 * 1024  # 20 MB
    if len(image_byte_data) > single_image_limit:
        raise ValueError(f'The size of image cannot exceed 20MB')
    try:
        # Image.open will check whether the binary content is a valid picture content.
        # verify() can check the integrity of content.
        # Both are used here to validate content.
        with Image.open(BytesIO(image_byte_data)) as img:
            img.verify()
        with file_utils.safe_open(image_save_path, mode='wb') as f:
            f.write(image_byte_data)
    except IOError as e:
        raise RuntimeError("Invalid image content, check the input image") from e
    except Exception as e:
        raise RuntimeError("Error when saving img") from e


def decode_base64_content(url: str):
    try:
        decoded_bytes = base64.b64decode(url, validate=True)
        return decoded_bytes
    except binascii.Error as e:
        raise ValueError("Invalid base64 url") from e
    
    
def copy_media(ori_path, save_dir, ext):
    file_utils.standardize_path(save_dir)
    file_utils.check_path_permission(save_dir)
    file_count = len(os.listdir(save_dir))
    new_filename = f"{file_count + 1}{ext}"
    save_path = os.path.join(save_dir, new_filename)
    try:
        shutil.copy(ori_path, save_path)
    except Exception as e:
        raise IOError(f"Error when copy media to the cache dir.") from e
    

def save_media(content, cache_dir, ext):
    file_utils.standardize_path(cache_dir)
    file_utils.check_path_permission(cache_dir)
    file_count = len(os.listdir(cache_dir))
    new_filename = f"{file_count + 1}{ext}"
    save_path = os.path.join(cache_dir, new_filename)
    try:
        fd = file_utils.safe_open(save_path, mode='wb', permission_mode=0o640)
        fd.write(content)
    except Exception as e:
        raise IOError(f"Error when save media.") from e
    

def create_cache_dir(dir_path):
    cache_dir_paths = [dir_path]
    cache_dir_paths.append(os.path.join(dir_path, "image"))
    cache_dir_paths.append(os.path.join(dir_path, "video"))
    cache_dir_paths.append(os.path.join(dir_path, "audio"))
    shm_save_path = os.path.join(dir_path, "shm_name.txt")

    try:
        for single_dir in cache_dir_paths:
            os.makedirs(single_dir, exist_ok=True)
        file_utils.safe_open(shm_save_path, mode='wb', permission_mode=0o640)
    except Exception as e:
        raise IOError(f"Error when create cache dir.") from e
    

def release_shared_memory(file_path):
    if not file_utils.is_path_exists(file_path):
        return
    
    file_utils.standardize_path(file_path)
    file_utils.check_path_permission(file_path)
    file = file_utils.safe_open(file_path, mode='r', permission_mode=0o640)
    shm_names = [line.strip() for line in file_utils.safe_readlines(file)]
    for name in shm_names:
        try:
            shm = shared_memory.SharedMemory(name=name)
            shm.close()  
            shm.unlink() 
        except Exception as e:
            logger.info(f"share memory may have been released.")


def remove_cache_dir(dir_path):
    if not file_utils.is_path_exists(dir_path):
        return
    
    shm_save_path = os.path.join(dir_path, "shm_name.txt")
    release_shared_memory(shm_save_path)

    try:
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        if os.path.isdir(dir_path):
            shutil.rmtree(dir_path)
        else:
            raise ValueError(f"remove cache dir error.")
    except Exception as e:
        raise IOError(f"remove cache dir error.") from e


def clear_meida_cache(dir_path: str):
    if not file_utils.is_path_exists(dir_path):
        return
    try:
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        for media_type in ['image', 'video', 'audio']:
            media_dir = os.path.join(dir_path, media_type)
            if not file_utils.is_path_exists(media_dir):
                continue
            media_dir = file_utils.standardize_path(media_dir)
            file_utils.check_path_permission(media_dir)
            if os.path.isdir(media_dir):
                shutil.rmtree(media_dir)
    except Exception as e:
        raise IOError(f"Clear cache media failed.") from e
