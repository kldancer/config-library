# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from typing import List
import json
import logging
import os
import multiprocessing
import time
from urllib.parse import urlparse

import numpy as np

from mindie_llm.modeling.model_wrapper import get_tokenizer_wrapper
from . import io_utils
from . import file_utils


logger = logging.getLogger(f"tokenizer-{os.getpid()}")

_DURATION = 30  # check undeleted cache dir pre 30 seconds
_DELET_DURATION = 300  # delete dirs in the cache that are older than 300 seconds
_SINGLE_IMAGE_LIMIT = 20 * 1024 * 1024  # 20 MB
_SINGLE_AUDIO_LIMIT = 20 * 1024 * 1024  # 20 MB
_SINGLE_VIDEO_LIMIT = 512 * 1024 * 1024  # 512 MB
_MEDIA_SIZE_LIMIT = 1000 * 1024 * 1024 # 1 GB

_TEXT_KEY = "text"
_CONTENT_KEY = "content"
_IMAGE_KEY = "image_url"
_VIDEO_KEY = "video_url"
_AUDIO_KEY = "audio_url"

_MEDIA_TYPE = {
    _IMAGE_KEY: ['.jpg', '.jpeg', '.png'],
    _VIDEO_KEY: ['.mp4', '.avi', '.wmv'],
    _AUDIO_KEY: ['.mp3', '.wav', '.flac'],
}

_SIZE_LIMITS = {
    _IMAGE_KEY: _SINGLE_IMAGE_LIMIT,
    _AUDIO_KEY: _SINGLE_AUDIO_LIMIT,
    _VIDEO_KEY: _SINGLE_VIDEO_LIMIT,
}


class IbisTokenizer:
    def __init__(self, path: str, bakend_type: str, trust_remote_code: bool):
        self.parent_pid_cache_prefix = 'cache_' + str(os.getppid())
        self.cache_prefix = str(os.getpid()) + '_'

        dir_path = os.getenv("LOCAL_CACHE_DIR", '')
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        self.local_cache_dir = dir_path

        cache_path = os.path.join(dir_path, self.parent_pid_cache_prefix)
        if not os.path.exists(cache_path):
            os.makedirs(cache_path, exist_ok=True)
            self.release_thread = multiprocessing.Process(target=self.release_cache, args=(_DURATION,), daemon=True)
            self.release_thread.start()

        wrapper = get_tokenizer_wrapper(path, bakend_type, trust_remote_code=trust_remote_code)
        self.tokenizer = wrapper.tokenizer
        self.input_builder = wrapper.input_builder
        self.tokenize = wrapper.tokenize
        self.media_cache_dirs = None
        self.timestamp = None
        self.toolscallprocessor = wrapper.toolscallprocessor       

    def __del__(self):
        dir_path = os.path.join(self.local_cache_dir, self.parent_pid_cache_prefix)
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        all_request = os.listdir(dir_path)
        for request in all_request:
            if request.startswith(self.cache_prefix):
                self.delete_multimodal_cache(int(request), self.cache_prefix)

    @staticmethod
    def is_mm(prompt):
        try:
            prompt_obj = json.loads(prompt)
        except Exception as e:
            # adapt to the old input format.
            logger.info("non-multimodal inputs.")
            return False
        if isinstance(prompt_obj, list):
            if isinstance(prompt_obj[0], dict):
                if "content" not in prompt_obj[0].keys() or isinstance(prompt_obj[0]["content"], list):
                    return True
        return False

    @staticmethod
    def _process_url_path(media_url, ext, input_type, cache_dir):
        parsed_url = urlparse(media_url)
        if parsed_url.scheme not in ("http", "https"):
            raise ValueError("Invalid HTTP URL.")
        
        media_content, media_size = io_utils.fetch_media_url(media_url, input_type, ext, _MEDIA_TYPE, _SIZE_LIMITS)
        if input_type == _IMAGE_KEY:
            image_count = len(os.listdir(cache_dir))
            image_save_path = os.path.join(cache_dir, f"{image_count + 1}.jpg")
            io_utils.save_image(media_content, image_save_path)
        else:
            io_utils.save_media(media_content, cache_dir, ext)
        return media_size

    @staticmethod
    def _process_local_path(media_url, ext, input_type, cache_dir):
        if not os.path.exists(media_url):
            raise FileNotFoundError(f"Can not find the input media file.")
        media_size = os.path.getsize(media_url)
        if media_size > _SIZE_LIMITS.get(input_type):
            raise ValueError(f'The size of {input_type} cannot exceed '
                            f'{_SIZE_LIMITS.get(input_type) / (1024 * 1024)} MB')
        io_utils.copy_media(media_url, cache_dir, ext)
        return media_size

    @staticmethod
    def _process_base64_path(media_url, input_type, cache_dir):
        image_content = io_utils.decode_base64_content(media_url)
        media_size = len(image_content)
        if media_size > _SIZE_LIMITS.get(input_type):
            raise ValueError(f'The size of {input_type} cannot exceed '
                            f'{_SIZE_LIMITS.get(input_type) / (1024 * 1024)} MB')
        image_count = len(os.listdir(cache_dir))
        image_save_path = os.path.join(cache_dir, f"{image_count + 1}.jpg")
        io_utils.save_image(image_content, image_save_path)
        return media_size
    
    def delete_multimodal_cache(self, timestamp: int, cache_prefix=None):
        dir_path = os.path.join(self.local_cache_dir, self.parent_pid_cache_prefix)
        if cache_prefix is not None:
            dir_path = os.path.join(dir_path, cache_prefix + f'{timestamp}')
            io_utils.remove_cache_dir(dir_path)
            return

        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        child_dirs = os.listdir(dir_path)
        for elem_dir in child_dirs:
            if elem_dir.endswith(str(timestamp)):
                release_path = os.path.join(dir_path, elem_dir)
                io_utils.remove_cache_dir(release_path)
                return

    def release_cache(self, duration):
        dir_path = os.path.join(self.local_cache_dir, self.parent_pid_cache_prefix)
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        while True:
            time.sleep(duration) 
            all_request = os.listdir(dir_path)
            for request in all_request:
                split_text = request.split('_')
                if len(split_text) != 2 or len(split_text[0]) < 1 or len(split_text[1]) < 1:
                    continue
                req_time = int(split_text[1])
                if time.time() - (req_time / 1_000_000_000) > _DELET_DURATION:
                    self.delete_multimodal_cache(req_time, split_text[0] + '_')
            
    def download_url(self, prompt: str, timestamp: int):
        if not self.is_mm(prompt):
            return
        self.timestamp = timestamp
        self._creat_cache_dir(timestamp)
        prompt_obj = json.loads(prompt)
        
        meida_size = 0
        try:
            if "content" in prompt_obj[0].keys():
                for single in prompt_obj:
                    for elem in single["content"]:
                        meida_size += self._download(elem)
                        if meida_size > _MEDIA_SIZE_LIMIT:
                            raise ValueError(f'The total media input cannot exceed '
                                             f'{_MEDIA_SIZE_LIMIT / (1024 * 1024)} MB.')
            else:
                for elem in prompt_obj:
                    meida_size += self._download(elem)
                    if meida_size > _MEDIA_SIZE_LIMIT:
                        raise ValueError(f'The total media input cannot exceed '
                                         f'{_MEDIA_SIZE_LIMIT / (1024 * 1024)} MB.')
        except Exception as e:
            logger.error("Download url failed: %s", e)
            self.delete_multimodal_cache(timestamp, self.cache_prefix)
            raise e
        
    def encode(self, prompt):
        try:
            if self.is_mm(prompt):
                mm_inputs = self.process_mm_inputs(prompt)
                token_list = self.tokenize(mm_inputs)
                self._clear_media_cache(self.timestamp)
                if isinstance(token_list, np.ndarray):
                    token_list = token_list.tolist()
                else:
                    token_list = token_list.numpy().tolist()
                
            else:
                tokens = self.tokenizer([prompt], return_tensors="np")
                out_0 = tokens["input_ids"]
                token_list = out_0[0].tolist()

            for elem in token_list:
                if isinstance(elem, list):
                    logger.error("[Tokenizer encode]\t>>> tokenizer encode result is not 1 Dimension")
                    return elem
            return token_list
        except Exception as e:
            self.delete_multimodal_cache(self.timestamp, self.cache_prefix)
            raise RuntimeError(f'IbisTokenizer encode error: {e}') from e

    def encode_chat(self, prompt):
        try:
            if self.is_mm(prompt):
                inputs = self.process_mm_inputs(prompt)
                token_list = self.input_builder.make_context(0, inputs)
                self._clear_media_cache(self.timestamp)
            else:
                inputs = json.loads(prompt)
                token_list = self.input_builder.make_context(0, inputs)

            return token_list
        except Exception as e:
            self.delete_multimodal_cache(self.timestamp, self.cache_prefix)
            logger.warning("[Tokenizer]\t>>> Exception:%s", e)
            raise RuntimeError(f"[Tokenizer] encode chat template failed.") from e

    def decode(self, input_tokens: List[int], use_tools_call: bool = False, skip_special_tokens: bool = True):
        if len(input_tokens) > 0 and input_tokens[-1] == -1:
            input_tokens = input_tokens[:-1]
        if len(input_tokens) <= 0:
            return ""
        in_tensor = np.array(input_tokens, copy=False)
        new_text = self.tokenizer.decode(in_tensor, skip_special_tokens=skip_special_tokens)
        if use_tools_call: 
            if self.toolscallprocessor is None:
                return json.dumps({"origintext": new_text})
            tool_call_info = self.toolscallprocessor.decode(new_text)
            if isinstance(tool_call_info, dict):
                return json.dumps(tool_call_info)
            else:
                return json.dumps({"origintext": new_text})
        return new_text

    def decode_one(self, input_tokens: List[int], pre_index: int, current_index: int, skip_special_tokens: bool = True):
        if pre_index < 0 or pre_index > len(input_tokens):
            logger.error("pre_index %d is invalid.", pre_index)
            raise ValueError("pre_index is invalid.")
        if current_index < 0 or current_index > len(input_tokens):
            logger.error("current_index %d is invalid.", current_index)
            raise ValueError("current_index is invalid.")
        if input_tokens[-1] == -1:
            return ""
        
        input_tensor = np.array(input_tokens, copy=False)
        start_index = pre_index
        full_text = self.tokenizer.decode(input_tensor[start_index:], skip_special_tokens=skip_special_tokens)
        pre_text = self.tokenizer.decode(input_tensor[start_index:current_index],
                                         skip_special_tokens=skip_special_tokens)
        pretext_no_empty_starts_with_space = pre_text != "" and pre_text[0] == " "
        fulltext_no_empty_starts_without_space = full_text != "" and full_text[0] != " "
        if len(full_text) > len(pre_text) and not full_text.endswith("�"):
            if pretext_no_empty_starts_with_space and fulltext_no_empty_starts_without_space:
                full_text = " " + full_text
            return full_text[len(pre_text):]
        else:
            return ""
        
    def decode_token(self, input_tokens: List[int]):
        if len(input_tokens) > 0 and input_tokens[-1] == -1:
            input_tokens = input_tokens[:-1]
        if len(input_tokens) <= 0:
            return ""

        decode_token_ls = [self.tokenizer.decode(tokenId) for tokenId in input_tokens]
        return json.dumps({"tokens": decode_token_ls})

    def process_mm_inputs(self, prompt):
        logger.info("Process multimodal inputs.")

        if isinstance(prompt, str):
            prompt_obj = json.loads(prompt)
        else:
            prompt_obj = prompt

        images = sorted(os.listdir(self.media_cache_dirs.get(_IMAGE_KEY)))
        videos = sorted(os.listdir(self.media_cache_dirs.get(_VIDEO_KEY)))
        audios = sorted(os.listdir(self.media_cache_dirs.get(_AUDIO_KEY)))
        medias = {
            _IMAGE_KEY: images,
            _VIDEO_KEY: videos,
            _AUDIO_KEY: audios
        }
        media_idx = {
            _IMAGE_KEY: 0,
            _VIDEO_KEY: 0,
            _AUDIO_KEY: 0
        }
        
        mm_inputs = []
        if _CONTENT_KEY not in prompt_obj[0].keys():
            media_idx, mm_inputs = self._process_single_input(prompt_obj, medias, media_idx)
        else:
            for i, message in enumerate(prompt_obj):
                media_idx, single_content = self._process_single_input(message[_CONTENT_KEY], medias, media_idx)
                prompt_obj[i][_CONTENT_KEY] = single_content
            mm_inputs = prompt_obj

        return mm_inputs

    def finalize(self):
        del self.tokenizer
        return 0
    
    def _creat_cache_dir(self, timestamp):
        dir_path = os.path.join(self.local_cache_dir, self.parent_pid_cache_prefix, 
                                self.cache_prefix + f"{timestamp}")

        io_utils.create_cache_dir(dir_path)
        self.media_cache_dirs = {
            _IMAGE_KEY: os.path.join(dir_path, "image"),
            _VIDEO_KEY: os.path.join(dir_path, "video"),
            _AUDIO_KEY: os.path.join(dir_path, "audio"),
        }

    def _download(self, info):
        media_size = 0
        input_type = info['type']
        if input_type == 'text':
            return media_size
        elif input_type not in _MEDIA_TYPE.keys():
            raise ValueError(f"Input type {input_type} does not match the mm type.")

        media_url:str = info[input_type]
        _, ext = os.path.splitext(media_url)
        cache_dir = self.media_cache_dirs.get(input_type)
        if media_url.startswith("http"):
            # http 或 https
            media_size = self._process_url_path(media_url, ext, input_type, cache_dir)
        elif ext.lower() in _MEDIA_TYPE.get(input_type):
            # 本地路径
            media_size = self._process_local_path(media_url, ext, input_type, cache_dir)
        elif input_type == _IMAGE_KEY: # base64
            media_size = self._process_base64_path(media_url, input_type, cache_dir)
        else:
            raise ValueError(f"Input type {input_type} does not match the mm type.")
        return media_size

    def _process_single_input(self, prompt_obj, medias, media_idx):
        media_keys = {
            _IMAGE_KEY: "image",
            _VIDEO_KEY: "video",
            _AUDIO_KEY: "audio"
        }
        mm_inputs = []
        for elem in prompt_obj:
            input_type = elem['type']
            path_idx = media_idx.get(input_type)
            media_list = medias.get(input_type)
            if input_type == _TEXT_KEY:
                mm_inputs.append({_TEXT_KEY: elem[_TEXT_KEY]})
            elif input_type in media_keys.keys():
                if path_idx > len(media_list):
                    raise ValueError(f"Requested {path_idx} {input_type} \
                        but only downloaded {len(media_list)}")
                media_path = os.path.join(self.media_cache_dirs.get(input_type), 
                    media_list[path_idx])
                mm_inputs.append({media_keys[input_type]: media_path})
                media_idx[input_type] += 1
            else:
                raise ValueError(f"Input type: {input_type} does not match the mm type.")
        return media_idx, mm_inputs
    
    def _clear_media_cache(self, timestamp: int):
        dir_path = os.getenv("LOCAL_CACHE_DIR", '')
        dir_path = file_utils.standardize_path(dir_path)
        file_utils.check_path_permission(dir_path)
        dir_path = os.path.join(dir_path, self.parent_pid_cache_prefix, self.cache_prefix + f"{timestamp}")
        io_utils.clear_meida_cache(dir_path)